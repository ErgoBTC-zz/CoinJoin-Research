package com.samourai.boltzmann.linker;

enum PackType {
  INPUTS
}
