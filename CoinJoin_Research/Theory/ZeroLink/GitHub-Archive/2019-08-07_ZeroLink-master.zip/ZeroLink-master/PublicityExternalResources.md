# English



[2017-09-10 Breaking Bitcoin Paris Conference Presentation: ZeroLink: Roadmap To Anonymous Bitcoin](https://www.youtube.com/watch?v=RY-QQOjycgI&t=0m51s)

[2017-09-10 Breaking Bitcoin Paris Conference Presentation Slides: ZeroLink: Roadmap To Anonymous Bitcoin](https://prezi.com/view/4biN62sLkyS0w7muL2w4/)

[2017-08-22 TheMerkle.com - What is Zerolink?](https://themerkle.com/what-is-zerolink/)

[2017-08-19 Bitcoin.com - Zerolink Claims to Have Developed Fully Anonymous Bitcoin Payments](https://news.bitcoin.com/zerolink-claims-to-successfully-have-developed-fully-anonymous-bitcoin-payments/)

[2017-08-18 BtcManager.com - ZeroLink: Anonymous Bitcoin At Last](https://btcmanager.com/zerolink-anonymous-bitcoin-last/)

[2017-08-18 BitcoinMagazine.com - HiddenWallet and Samourai Wallet Join Forces to Make Bitcoin Private With ZeroLink](https://bitcoinmagazine.com/articles/hiddenwallet-and-samourai-wallet-join-forces-make-bitcoin-private-zerolink/)

[2017-08-18 Nasdaq.com - HiddenWallet and Samourai Wallet Join Forces to Make Bitcoin Private With ZeroLink](http://www.nasdaq.com/article/hiddenwallet-and-samourai-wallet-join-forces-to-make-bitcoin-private-with-zerolink-cm834136)

[2017-08-16 CryptoInsider.com - DAILY ROUNDUP](https://cryptoinsider.com/daily-roundup-august-16-2017/)

[2017-08-14 Medium.com - nopara73: Introducing ZeroLink — The Bitcoin Fungibility Framework](https://medium.com/@nopara73/introducing-zerolink-the-bitcoin-fungibility-framework-dc5338086198)

# Spanish

[2017-08-29 EntornoInteligente.com - VENEZUELA: Mecanismo Zerolink aumentará privacidad en carteras de bitcoin](http://www.entornointeligente.com/articulo/20070/VENEZUELA-Mecanismo-Zerolink-aumentara-privacidad-en-carteras-de-bitcoin-29082017)

[2017-08-27 CriptoNoticias.com - Mecanismo Zerolink aumentará privacidad en carteras de bitcoin](https://criptonoticias.com/carteras/mecanismo-zerolink-aumentara-privacidad-carteras-bitcoin/#axzz4s0FjCUih)

# Portuguese

[2017-08-20 PortalDoBitcoin.com - Zerolink Alega Ter Desenvolvido Transações Totalmente Anônimas de Bitcoin](https://portaldobitcoin.com/zerolink-alega-ter-desenvolvido-transacoes-totalmente-anonimas-de-bitcoin/)

# Russian

[2017-08.15 ForkLog.com - Протокол ZeroLink обещает полную анонимность биткоин-транзакций](http://forklog.com/protokol-zerolink-obeshhaet-polnuyu-anonimnost-bitkoin-tranzaktsij/)
