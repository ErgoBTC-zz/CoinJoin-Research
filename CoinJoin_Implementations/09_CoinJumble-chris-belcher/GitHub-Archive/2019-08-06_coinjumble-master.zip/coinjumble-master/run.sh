#! /bin/sh
python coin-jumble.py
