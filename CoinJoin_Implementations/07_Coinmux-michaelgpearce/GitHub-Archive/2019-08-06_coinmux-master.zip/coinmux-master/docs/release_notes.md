## Coinmux Release Notes

### v0.2.1

* Connect to mainnet when selected in preferences.

### v0.2.0

* Initial Grapical User Interface

### v0.1.3

* Participant checks for director changing status to 'failed'.
* Use webbtc for posting transactions instead of connecting to the Bitcoin network.

### v0.1.2.1

* Ignore errors disabling crypto restrictions.

### v0.1.2

* Fix bug with making directories with root_mkdir_p.
* Disable crypto restrictions.

### v0.1.1

* Fix missing jline.console.ConsoleReader dependency in Jar.
* Improve error handling of invalid private key.

### v0.1.0

* Initial release.

