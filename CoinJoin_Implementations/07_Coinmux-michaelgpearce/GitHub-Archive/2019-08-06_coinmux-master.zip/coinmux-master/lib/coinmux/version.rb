module Coinmux
  VERSION = "0.2.1"

  BANNER = "Coinmux - Decentralized, Trustless, Anonymous and Open Bitcoin Mixer"
end