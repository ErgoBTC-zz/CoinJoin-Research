class Coinmux::Error < StandardError
end
