export const environment = {
  production: true,
  silent: false
};
