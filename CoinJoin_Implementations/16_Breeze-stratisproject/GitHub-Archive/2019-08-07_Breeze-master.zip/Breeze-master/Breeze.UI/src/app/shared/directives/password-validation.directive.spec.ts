import { PasswordValidationDirective } from './password-validation.directive';

describe('PasswordValidationDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordValidationDirective();
    expect(directive).toBeTruthy();
  });
});
