export class TransactionSending {

  constructor(hex: string) {
    this.hex = hex;
  }

  hex: string;
}
