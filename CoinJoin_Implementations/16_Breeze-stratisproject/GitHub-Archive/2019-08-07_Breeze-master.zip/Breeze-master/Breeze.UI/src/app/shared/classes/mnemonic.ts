export class Mnemonic {
  mnemonic: string;
}
