# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

setup(
    name='tumblebit',
    version='0.0.1',
    packages=find_packages(exclude=('tests', 'docs'))
)
