$(document).ready(function() {
    $('.date').datepicker();
});