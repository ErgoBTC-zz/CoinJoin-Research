function doRedirect() {
    window.location = 'https://blockchain.info' + window.location.pathname + window.location.hash;
}