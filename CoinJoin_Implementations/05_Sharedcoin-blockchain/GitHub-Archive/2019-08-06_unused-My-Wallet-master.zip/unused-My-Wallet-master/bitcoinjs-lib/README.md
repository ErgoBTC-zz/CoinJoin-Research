# bitcoinjs-lib

A library containing Bitcoin client-side functionality in JavaScript,
most notably ECDSA signing and verification.

# Status

This is currently pretty raw code. We're planning to clean it up,
convert everything into CommonJS modules and put a flexible build
system in place.

Prototype software, use at your own peril.

# License

This library is free and open-source software released under the MIT
license.
