$(document).ready(function () {
    prettyPrint();
});