Charts are generated from Markdown 
using https://mermaidjs.github.io/mermaid-live-editor/
