Assume that any attacker will have full access to the source code and documentation, including this threat model which is effectively an attack manual for the software.

#### Attackers goals:
* **A** Linking Bitcoin addresses with a high probability of single owner
* **B** Linking Bitcoin address with an IP address
* **C** Linking an IP address with use of the software
* **D** Stealing bitcoins
* **E** DOSing the user from trading or spending coins

#### Attacker's special powers to acheive the goals:
1. MITM - control of a relevant internet router e.g. the ISP
2. Control of Bitcoin relay nodes or miners.
3. Control of bitprivacy peers

It is assumed that the attacker has a computer with an internet connection, and can watch the blockchain. This model does not address an attacker controlling a majority of the mining capacity.

### Attack classes

#### A1. Bulletproof DOS attack

Attacker uses powers 2 or 3 to reach goal E. If the attacker controls enough nodes, they can entirely obstruct joining or transactions relaying. There is no way to eliminate this entirely.

The software will minimise trade DOSing by using fidelity bonds and blacklists for misbehaving nodes. Aggressive trading strategies can make joining still effective with only a small number of honest participents, but it must be carefully balanced against A3 goal A so join parties are reasonably unique.

#### A2. Generic / physical access hack attack

The attacker gains control of the software via some other software on the users computer, or via physical access.

This attack leads to all goals. If the software isn't running, password protected wallets are a good defence. Otherwise, there is no defence.
    
#### A3. Exploiting joining

Attacker uses power 3.

To defend against goal A:
* The join transaction must have a reasonable number of unique parties in it.  To acheive this, the software must select parties to join with on a random basis. Fidelity bonds will stop the attacker spamming trade requests and dictate that peerIds are random.
* It must not be possible to connect inputs with corresponding outputs. To acheive this, outputs are sent over a new connection (fidelity bond not required here due to use of blind signatures).
* Ouputs from different addresses must use new connections, peerIds and fidelity bonds.
* The software must not avoid joining coins that both belong to the same person, as that could be detected. To address this and keep the number of unique parties high, it may be necessary to delay joining some coins.

(Note: Some reuse of fidelity bonds may be possible with more blind signatures or for large N)

To defend against goals B or C, the DHT must only be accessed over Tor.

To defend against goal D, the mixing protocol must be secure, and all network data must be verified before being acted on - especially before the transaction is signed. Attack surface is the DHT library, protocol buffers library, and bitprivacy library data verification routines.

#### A4. Exploiting bitcoin syncing and relaying

Attacker uses power 2.

To defend against goals A, B & C, the software must connect to the Bitcoin network over Tor. After spending coins, the software must make a new Tor circuit. We assume the bloom filtering provides a reasonable level of security for receiving coins.

To defend against D, the bitcoinj library must be secure. That is outside the scope of this project.
    
#### A5. Exploiting Tor information leakage

Attacker uses power 2 or 3 to reach goals A, B or C.

The software must avoid leaking IP address or other identifying information over Tor. See [TorifyHOWTO](https://trac.torproject.org/projects/tor/wiki/doc/TorifyHOWTO) for details.
The DHT library must be checked to address this - things like firewall testing are particularly dangerous. The [Tor Bitcoin page](https://en.bitcoin.it/wiki/Tor) suggests that the Bitcoin protocol is secure over Tor.


