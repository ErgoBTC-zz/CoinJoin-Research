Bitprivacy is built on the p2p library TomP2P [http://tomp2p.net/](http://tomp2p.net/)  
It provides a distributed hash table (DHT) which can be viewed as a simple `(key, value)` store.

This is the process for a single join. Multiple joins must use fresh connections with fresh peerIds - not yet implemented.

### 1. Peer decides what kind of transaction they want to participate in

Peer creates a 'transaction schema'. The current scheme looks like this:

  * Each party signs one input of v btc
  * Each party provides one blind output of (v - (0.0005/n)) btc
  * Num parties must equal n
  
Peer generates a schema key (hash of the schema)

### 2. Peer lists their trade on the network

Peer creates a new 'peerId' (hash of a new DSA public key) and connects to the network by connecting to a well known peer.

It creates a blind trade listing:

    {
        peerId
        party data {
            input details (blockId, txId, outputIndex) of v btc
            promise to later provide output of (v - (0.0005/n)) btc
        }
    }
    
signs the listing with it's peerId (not yet implemented)  
and generates a trade listing key (hash of the trade listing)

Peer puts `(trade listing key, signed trade listing)` to the DHT and adds their trade listing key to `(schema key, list of keys)` on DHT


### 3. Peer looks for other parties to make a 'full trade'

Peer gets `(schema key, list of trade listing keys)` from DHT and the corresponding `(trade listing key, signed trade listing)`.
It discards those listings which don't validate against the schema or the signature.

definition: a 'full trade' is:

    {
        trade listing key
        trade listing key
        ...
        trade listing key
        - where keys are listed in sorted order
    } 
    
and a full trade key is the hash of a full trade.

Peer gets `(hash(schema key), list of full trade keys)` and the corresponding `(full trade key, full trade)`.  
It verifies these full trades are legit, and discards those that don't include it's own trade listing key.
    
Peer tries additional combinations of trade listings to see if it can make a full trade in any new ways.  
For each new way it finds, it puts `(full trade key, full trade)` and adds the key to `(hash(schema key), list of full trade keys)`.

Peer now has a good list of full trades.

### 4. Peers supply blinded outputs

The first member of the sorted full trade is chosen as the blinding server. They put `(hash(hash(full trade key)), new blinding public key)`  
This should be signed with it's peerId (not yet implemented).  

Everyone gets `(hash(hash(full trade key)), blinding public key)`,
does the blinding operation with a newly generated output address
and puts `(blinded key, blinded output)` to DHT.  
This should be signed with it's peerId (not yet implemented).  
blinded key is hash(full trade key, trade listing key)

Blinding server gets all the blinded outputs from the DHT, signs them with their private blinding key,
and puts them to `(hash(blinded key), signed blinded output)`  

Once all the signed blinded outputs are on the DHT, each peer provides their signed unblinded output.  
This *should* use a new network connection and peerId and have a random delay to thwart timing analysis - not yet implemented.

Peer adds their signed unblinded output to `(hash(full trade key), list of signed unblinded outputs)`

Everyone waits for the full list of signed unblinded outputs, and verifies it matches the promises in the original trade listings.

Everyone now constructs an unsigned bitcoin transaction with all the inputs and outputs.

### 5. Peers sign the transaction

Everyone signs the transaction in the order listed in the full trade and puts their signed tx to the DHT. Before signing they verify the previous signed tx is legit.

They must also check none of the members have deleted their trade listing, so we don't generate double spends - not yet implemented.

Each signed tx is stored at `(hash(full trade key, trade listing key))`, so peers can poll for the last signer, and retreive the fully signed tx.  
Each signed tx message should also be signed with it's peerId (not yet implemented).  

Once they have verified the last tx, they must delete all their trade data - not yet implemented.

Then they broadcast the completed tx to the bitcoin network.


