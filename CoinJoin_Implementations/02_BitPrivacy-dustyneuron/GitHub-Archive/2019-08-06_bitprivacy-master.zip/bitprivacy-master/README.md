Bitprivacy
----------

Bitprivacy is an MIT-licensed fully decentralized Bitcoin privacy library that could be integrated into personal Bitcoin wallets like MultiBit and the Android Bitcoin Wallet.

Bitprivacy will be for casual Bitcoin users who don't want people spying on them. It does not protect against government-level ("global adversary") monitoring, and as such is not suitable for those looking for strong anonymity.

Privacy is achieved with special complicated transactions similar to coin-joining: for full details read DETAILS.md.

The transaction matching is generic enough that it could also be used for crowdfunding.

Current status is working prototype, DO NOT USE ON THE MAIN BITCOIN NETWORK.

Download: [http://bitprivacy.org/files/bitprivacy-0.2-jar-with-dependencies.jar](http://bitprivacy.org/files/bitprivacy-0.2-jar-with-dependencies.jar)

Discuss at [https://bitcointalk.org/index.php?topic=200952.0](https://bitcointalk.org/index.php?topic=200952.0)


### Usage Instructions

Bitprivacy is currently testnet only, and only has a command-line interface.  
To do a 2-party transaction, simultaneously run 2 instances of the program, each with a different command-line argument giving the name of a wallet to create:

    java -jar bitprivacy-0.2-jar-with-dependencies.jar client1wallet
    java -jar bitprivacy-0.2-jar-with-dependencies.jar client2wallet

On each client you'll need to load the wallet with some testnet coins. Do `wallet` then `addresses` to show your new address, and sent both clients exactly the same amount from somewhere, e.g. [a testnet faucet](http://testnet.mojocoin.com/)  
Type `sync` to get the wallet to pick up your new coins.  
Now `exit` the wallet shell, and do `client`.

Client #1: do `connect`  
Client #2: do `connect localhost`

Client #1: do `mix [inputaddress] 2` for a 2-party transaction
Client #2: do `mix [inputaddress] 2`

You'll get lots of scrolling output. When it stops scrolling, and mentions the broadcast is complete, then you're done. The output Bitcoin will be in a new address in your wallet.

### Compiling & Hacking

This is a Java project, built with the bitcoinj library, using Maven for building.  
You'll also need protoc, the Google Protocol Buffers Compiler:  

    sudo apt-get install git maven protobuf-compiler libprotobuf-java && sudo apt-get remove maven2
    git clone https://github.com/dustyneuron/bitprivacy.git
    cd bitprivacy
    mvn -DskipTests verify
    # And to run:
    java -jar target/bitprivacy-0.3-SNAPSHOT-jar-with-dependencies.jar [walletName]
    
