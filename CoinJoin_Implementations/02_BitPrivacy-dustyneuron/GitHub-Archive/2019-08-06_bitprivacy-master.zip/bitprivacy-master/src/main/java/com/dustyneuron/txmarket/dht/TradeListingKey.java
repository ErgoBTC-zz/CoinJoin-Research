package com.dustyneuron.txmarket.dht;

public interface TradeListingKey extends TradeKey {
}
