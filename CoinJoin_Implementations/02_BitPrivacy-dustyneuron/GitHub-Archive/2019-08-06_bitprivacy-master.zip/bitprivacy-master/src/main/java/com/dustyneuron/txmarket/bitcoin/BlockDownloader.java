package com.dustyneuron.txmarket.bitcoin;

import com.google.bitcoin.core.Block;
import com.google.bitcoin.core.Sha256Hash;

public interface BlockDownloader {
    public Block downloadBlock(Sha256Hash block) throws Exception;
}
