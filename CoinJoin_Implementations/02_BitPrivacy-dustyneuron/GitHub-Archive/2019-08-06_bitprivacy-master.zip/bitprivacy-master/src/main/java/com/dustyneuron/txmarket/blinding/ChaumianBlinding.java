package com.dustyneuron.txmarket.blinding;

import java.math.BigInteger;
import java.security.SecureRandom;

import org.spongycastle.crypto.AsymmetricCipherKeyPair;
import org.spongycastle.crypto.CryptoException;
import org.spongycastle.crypto.digests.SHA1Digest;
import org.spongycastle.crypto.engines.RSABlindingEngine;
import org.spongycastle.crypto.engines.RSAEngine;
import org.spongycastle.crypto.generators.RSABlindingFactorGenerator;
import org.spongycastle.crypto.generators.RSAKeyPairGenerator;
import org.spongycastle.crypto.params.RSABlindingParameters;
import org.spongycastle.crypto.params.RSAKeyGenerationParameters;
import org.spongycastle.crypto.params.RSAKeyParameters;
import org.spongycastle.crypto.signers.PSSSigner;
import org.spongycastle.util.Arrays;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Blinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItemContent;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedBlinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedUnblinded;
import com.dustyneuron.txmarket.schema.SchemaUtils;
import com.google.protobuf.ByteString;

public class ChaumianBlinding implements Blinding {

    private final RSABlindingFactorGenerator blindFactorGen;
    private final RSABlindingEngine blindingEngine;
    private final PSSSigner blindSigner;
    private final PSSSigner signer;
    private final KeyGen keyGenType;

    public enum KeyGen {
        SECURE, FASTINSECURE
    };

    public ChaumianBlinding(KeyGen keyGen) {
        blindFactorGen = new RSABlindingFactorGenerator();
        blindingEngine = new RSABlindingEngine();
        blindSigner = new PSSSigner(blindingEngine, new SHA1Digest(), 20);
        signer = new PSSSigner(new RSAEngine(), new SHA1Digest(), 20);
        keyGenType = keyGen;
    }

    @Override
    public AsymmetricCipherKeyPair generateKeyPair() {
        RSAKeyPairGenerator gen = new RSAKeyPairGenerator();
        RSAKeyGenerationParameters params;
        if (keyGenType == KeyGen.SECURE) {
            params = new RSAKeyGenerationParameters(
                    BigInteger.valueOf(0x10001), new SecureRandom(), 2048, 12);
            System.out
                    .print("Generating secure 2048-bit RSA key for blinding...");
        } else {
            params = new RSAKeyGenerationParameters(
                    BigInteger.valueOf(0x10001), new SecureRandom(), 512, 1);
            System.out
                    .print("Generating *INSECURE* 256-bit RSA key for blinding...");
        }
        gen.init(params);
        AsymmetricCipherKeyPair keyPair = gen.generateKeyPair();
        System.out.println("...done");
        return keyPair;
    }

    @Override
    public BigInteger generateBlindingFactor(RSAKeyParameters publicKey) {

        blindFactorGen.init(publicKey);
        return blindFactorGen.generateBlindingFactor();
    }

    @Override
    public Blinded blind(DataItem privateData, BigInteger blindingFactor,
            RSAKeyParameters publicKey) throws CryptoException {
        byte[] msg = privateData.getContent().toByteArray();

        RSABlindingParameters params = new RSABlindingParameters(publicKey,
                blindingFactor);
        blindSigner.init(true, params);

        blindSigner.update(msg, 0, msg.length);
        byte[] blindedData = blindSigner.generateSignature();

        return Blinded.newBuilder().setHeader(privateData.getHeader())
                .setData(ByteString.copyFrom(blindedData)).build();
    }

    @Override
    public SignedBlinded sign(Blinded a, AsymmetricCipherKeyPair keyPair) {
        byte[] blindedMsg = a.getData().toByteArray();

        RSAEngine signerEngine = new RSAEngine();

        signerEngine.init(true, keyPair.getPrivate());
        byte[] blindedSignature = signerEngine.processBlock(blindedMsg, 0,
                blindedMsg.length);

        return SignedBlinded.newBuilder().setHeader(a.getHeader())
                .setData(ByteString.copyFrom(blindedSignature)).build();
    }

    @Override
    public SignedUnblinded unblind(SignedBlinded s, DataItem privateData,
            BigInteger blindingFactor, RSAKeyParameters publicKey) {
        byte[] blindedSignature = s.getData().toByteArray();

        RSABlindingParameters params = new RSABlindingParameters(publicKey,
                blindingFactor);
        blindingEngine.init(false, params);
        byte[] signature = blindingEngine.processBlock(blindedSignature, 0,
                blindedSignature.length);

        if (!SchemaUtils.areIdentical(s.getHeader(), privateData.getHeader())) {
            return null;
        }

        return SignedUnblinded.newBuilder().setHeader(s.getHeader())
                .setContent(privateData.getContent())
                .setSignature(ByteString.copyFrom(signature)).build();
    }

    @Override
    public boolean verify(SignedUnblinded s, DataItemContent privateData,
            RSAKeyParameters publicKey) {
        byte[] msg = s.getContent().toByteArray();
        if (privateData != null) {
            byte[] original = privateData.toByteArray();
            if (!Arrays.areEqual(msg, original)) {
                return false;
            }
        }

        signer.init(false, publicKey);
        signer.update(msg, 0, msg.length);
        return signer.verifySignature(s.getSignature().toByteArray());
    }
}
