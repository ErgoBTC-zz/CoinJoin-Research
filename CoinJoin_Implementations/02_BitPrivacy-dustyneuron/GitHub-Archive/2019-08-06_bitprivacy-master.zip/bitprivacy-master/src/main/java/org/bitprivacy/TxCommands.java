package org.bitprivacy;

import java.io.IOException;
import java.math.BigInteger;

import org.apache.commons.codec.binary.Hex;

import asg.cliche.Command;
import asg.cliche.Param;

import com.dustyneuron.txmarket.bitcoin.WalletUtils;
import com.dustyneuron.txmarket.schema.PartialSigner;
import com.google.bitcoin.core.Address;
import com.google.bitcoin.core.Sha256Hash;
import com.google.bitcoin.core.Transaction;
import com.google.bitcoin.core.TransactionConfidence;
import com.google.bitcoin.core.TransactionOutput;
import com.google.bitcoin.core.Utils;
import com.google.bitcoin.core.VerificationException;
import com.google.bitcoin.core.Wallet;

public class TxCommands {

    private WalletMgr walletMgr;
    private Wallet wallet;
    private Transaction tx;

    public TxCommands(WalletMgr w) {
        walletMgr = w;
        wallet = w.getWallet();
        tx = null;
    }

    void addInput(Transaction t, int txOutputIdx) throws Exception {
        if (t == null) {
            throw new Exception("couldn't find transaction");
        }

        TransactionOutput txOutput = t.getOutput(txOutputIdx);
        if (txOutput == null) {
            throw new Exception("Could not find output idx " + txOutputIdx
                    + " in tx " + t.toString(null));
        }
        System.out.println("Adding input of "
                + Utils.bitcoinValueToFriendlyString(txOutput.getValue()));

        if (!txOutput.isAvailableForSpending()) {
            throw new Exception("output idx " + txOutputIdx + " in tx "
                    + t.toString(null) + " not available for spending");
        }
        if (!txOutput.isMine(wallet)) {
            System.out.println("Warning: output idx " + txOutputIdx + " in tx "
                    + t.toString(null) + " not mine (no key in wallet?)");
            // throw new Exception("output idx " + txOutputIdx + " in tx " +
            // t.toString(null) + " not mine (no key in wallet?)");
        }

        if (tx == null) {
            tx = new Transaction(wallet.getNetworkParameters());
            tx.getConfidence().setSource(TransactionConfidence.Source.SELF);
        }
        tx.addInput(txOutput);
        print();
    }

    @Command
    public void addInput(
            @Param(name = "blockId", description = "Block Id contatining transaction") String blockId,
            @Param(name = "txId", description = "Transaction Id with unspent output") String txId,
            @Param(name = "txOutputIdx", description = "Idx of unspent output") int txOutputIdx)
            throws Exception {
        Sha256Hash block = new Sha256Hash(blockId);
        Sha256Hash txHash = new Sha256Hash(txId);
        Transaction t = walletMgr.getExternalTransaction(block, txHash);
        addInput(t, txOutputIdx);
    }

    @Command
    public void addInput(
            @Param(name = "txId", description = "Transaction Id with unspent output") String txId,
            @Param(name = "txOutputIdx", description = "Idx of unspent output") int txOutputIdx)
            throws Exception {
        Sha256Hash txHash = new Sha256Hash(txId);
        Transaction t = wallet.getTransaction(txHash);
        addInput(t, txOutputIdx);
    }

    @Command
    public void addOutput(
            @Param(name = "address", description = "Output bitcoind address") String address,
            @Param(name = "btc", description = "Amount of BTC") double btc)
            throws Exception {

        if (tx == null) {
            tx = new Transaction(wallet.getNetworkParameters());
            tx.getConfidence().setSource(TransactionConfidence.Source.SELF);
        }

        Address toAddress = new Address(wallet.getNetworkParameters(), address);
        BigInteger amount = Utils.toNanoCoins(Double.toString(btc));

        tx.addOutput(amount, toAddress);
        print();
    }

    @Command
    public void sign() throws Exception {
        tx = PartialSigner.dangerousSignMany(tx, wallet);
        print();
    }

    @Command(description = "Print tx details & raw hex data")
    public void print() throws Exception {
        if (tx == null) {
            return;
        }
        System.out.print(WalletUtils.transactionToString(tx, wallet));
    }

    @Command(description = "Load tx from raw hex data")
    public void load(
            @Param(name = "hexData", description = "Raw hex data") String hexData)
            throws Exception {
        tx = new Transaction(wallet.getNetworkParameters(),
                Hex.decodeHex(hexData.toCharArray()));
        print();
    }

    @Command(description = "Load tx from tx hash")
    public void loadFromHash(
            @Param(name = "txHash", description = "Tx hash") String txHash)
            throws Exception {
        tx = wallet.getTransaction(new Sha256Hash(txHash));
        if (tx == null) {
            System.out.println("Transaction not found");
        } else {
            print();
        }
    }

    @Command(description = "Load tx from block hash and tx hash")
    public void loadFromBlock(
            @Param(name = "blockHash", description = "Block hash") String blockHash,
            @Param(name = "txHash", description = "Tx hash") String txHash)
            throws Exception {
        tx = walletMgr.getExternalTransaction(new Sha256Hash(blockHash),
                new Sha256Hash(txHash));
        if (tx == null) {
            System.out.println("Transaction not found");
        } else {
            print();
        }
    }

    @Command(description = "Commit transaction to wallet")
    public void commitToWallet() throws VerificationException, IOException {
        walletMgr.commitToWallet(tx);
    }

    @Command
    public void broadcast() throws Exception {
        walletMgr.commitToWallet(walletMgr.broadcast(tx));
    }

}
