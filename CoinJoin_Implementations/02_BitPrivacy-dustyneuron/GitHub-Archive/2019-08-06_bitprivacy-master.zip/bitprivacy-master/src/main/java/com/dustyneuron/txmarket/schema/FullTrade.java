package com.dustyneuron.txmarket.schema;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SinglePartyData;
import com.dustyneuron.txmarket.bitcoin.BlockDownloader;
import com.dustyneuron.txmarket.dht.FullTradeKey;
import com.dustyneuron.txmarket.dht.TradeDHT;
import com.dustyneuron.txmarket.dht.TradeListingKey;
import com.google.bitcoin.core.NetworkParameters;
import com.google.bitcoin.core.Transaction;
import com.google.protobuf.ByteString;
import com.google.protobuf.GeneratedMessage;

public class FullTrade {
    private TransactionSchemaProtos.FullTradeData data;
    private List<TradeListing> sorted;
    private List<TradeListing> sortedBlinded;
    private List<TradeListingKey> sortedKeys;
    private FullTradeKey key;
    private boolean blinded;

    public FullTrade(TradeDHT dht, List<TradeListingKey> unsortedKeys)
            throws Exception {
        sortedKeys = sortTradeListings(unsortedKeys);
        TransactionSchemaProtos.FullTradeData.Builder cb = TransactionSchemaProtos.FullTradeData
                .newBuilder();
        for (TradeListingKey k : sortedKeys) {
            cb.addTradeListingKey(ByteString.copyFrom(k.toByteArray()));
        }
        data = cb.build();
        key = dht.getKey(this);
    }

    public boolean loadTradeListings(TradeDHT dht,
            List<TradeListing> allTradeListings) {
        assert (sortedBlinded == null);
        blinded = false;
        List<TradeListing> results = new ArrayList<TradeListing>();
        for (TradeListingKey k : sortedKeys) {
            TradeListing found = null;
            for (TradeListing l : allTradeListings) {
                if (dht.getKey(l).equals(k)) {
                    found = l;
                    if (!blinded && l.usingBlinding()) {
                        blinded = true;
                    }
                    break;
                }
            }
            if (found == null) {
                return false;
            }
            results.add(found);
        }
        sortedBlinded = results;
        if (!blinded) {
            sorted = sortedBlinded;
        }
        return true;
    }

    public void loadUnblindedData(List<DataItem> privateData) throws Exception {
        assert (sorted == null);
        assert (blinded);
        assert (sortedBlinded != null);

        List<DataItem> sortedPrivateData = SchemaUtils.sortItems(privateData);

        List<TradeListing> results = new ArrayList<TradeListing>();
        for (TradeListing listing : sortedBlinded) {
            List<SinglePartyData> newPartyData = new ArrayList<SinglePartyData>();

            for (SinglePartyData p : listing.getData().getAllPartiesDataList()) {
                SinglePartyData.Builder newP = SinglePartyData.newBuilder(p);
                newP.clearData();

                for (DataItem d : p.getDataList()) {
                    if (SchemaUtils.usingBlinding(d)) {
                        int idx = SchemaUtils.findMatchingPrivateData(d,
                                sortedPrivateData);
                        if (idx == -1) {
                            throw new Exception(
                                    "no matching private data for blinded data:\n\t"
                                            + d);
                        }
                        DataItem match = sortedPrivateData.remove(idx);
                        if (match == null) {
                            throw new Exception(
                                    "internal error - matched data did not exist in list");
                        }
                        newP.addData(match);
                    } else {
                        newP.addData(d);
                    }
                }
                newPartyData.add(newP.build());
            }

            results.add(new TradeListing(newPartyData, listing));
        }

        if (sortedPrivateData.size() != 0) {
            throw new Exception("unblinded data list wrong length");
        }

        sorted = results;
    }

    public FullTradeKey getKey() {
        return key;
    }

    public Transaction createInitialTransaction(NetworkParameters params,
            BlockDownloader blockDownloader) throws Exception {
        assert (sorted != null);
        List<SinglePartyData> allPartiesData = createPartiesList(sorted);
        Transaction t = TransactionVerifier.createTransaction(allPartiesData,
                blockDownloader, params);
        if (t == null) {
            throw new Exception("failed to create transaction");
        }
        return t;
    }

    private static List<SinglePartyData> createPartiesList(
            List<TradeListing> listing) {
        List<SinglePartyData> allParties = new ArrayList<SinglePartyData>();
        for (TradeListing l : listing) {
            allParties.addAll(l.getData().getAllPartiesDataList());
        }
        return allParties;
    }

    public static List<TradeListingKey> getKeys(TradeDHT dht,
            List<TradeListing> tradeListings) {
        List<TradeListingKey> list = new ArrayList<TradeListingKey>();
        for (TradeListing l : tradeListings) {
            list.add(dht.getKey(l));
        }
        return list;
    }

    private static List<TradeListingKey> sortTradeListings(
            List<TradeListingKey> keyList) throws Exception {
        TradeListingKey[] unsorted = keyList.toArray(new TradeListingKey[0]);
        Arrays.sort(unsorted);
        return Arrays.asList(unsorted);
    }

    public GeneratedMessage getRawGeneratedMessage() {
        return data;
    }

    public List<TradeListingKey> getSortedKeys() {
        return new ArrayList<TradeListingKey>(sortedKeys);
    }

    public List<TradeListing> getSortedBlindedListings() {
        assert (sortedBlinded != null);
        return new ArrayList<TradeListing>(sortedBlinded);
    }

    public List<TradeListing> getSortedListings() {
        assert (sorted != null);
        return new ArrayList<TradeListing>(sorted);
    }

    @Override
    public int hashCode() {
        return key.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        return this.key.equals(((FullTrade) obj).key);
    }

}
