package com.dustyneuron.txmarket.schema;

import java.util.ArrayList;
import java.util.List;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SinglePartyData;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TransactionSchema;

public class Trade {
    final private TransactionSchema schema;
    final private List<SinglePartyData> allPartiesData;

    public Trade(TransactionSchema schema) {
        this(schema, new ArrayList<SinglePartyData>());
    }

    public Trade(TransactionSchema schema, List<SinglePartyData> allPartiesData) {
        this.schema = schema;
        this.allPartiesData = allPartiesData;
    }

    public TransactionSchema getSchema() {
        return schema;
    }

    public List<SinglePartyData> getAllPartiesData() {
        return allPartiesData;
    }
}
