package org.bitprivacy;

import com.dustyneuron.txmarket.bitcoin.BlockDownloader;
import com.google.bitcoin.core.Transaction;

public interface BitcoinNetwork extends BlockDownloader {
    public Transaction broadcast(final Transaction t) throws Exception;
}
