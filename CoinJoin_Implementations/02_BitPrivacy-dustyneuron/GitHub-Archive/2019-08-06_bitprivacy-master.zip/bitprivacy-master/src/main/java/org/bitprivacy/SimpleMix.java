package org.bitprivacy;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ConstraintFormula;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ConstraintFormula.Comparator;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ConstraintFormula.ForEach;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItemHeader;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Element;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Element.ElementType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Expression;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.IOTypeReference;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.InputType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.OutputType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.PartyType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ReferenceType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SinglePartyData;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TransactionSchema;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Variable;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Variable.VariableType;
import com.dustyneuron.txmarket.schema.SchemaUtils;
import com.dustyneuron.txmarket.schema.Trade;
import com.google.bitcoin.core.Address;
import com.google.bitcoin.core.Transaction;
import com.google.bitcoin.core.Utils;

public class SimpleMix {
    public enum BlindingValues {
        NONE, INPUTS, OUTPUTS, BOTH
    };

    // private static Map<TransactionSchema, BigInteger> schemas = new
    // HashMap<TransactionSchema, BigInteger>();

    // TODO: this should match bitcoind, which calculates fees per kb of tx.
    private static final BigInteger fee = Utils.toNanoCoins("0.0005");

    public static Trade createTrade(Transaction tx, int unspentOutputIdx,
            BigInteger inputValue, Address dest, int numParties,
            BlindingValues blindingValues) {
        
        String blockId = tx.getAppearsInHashes().keySet().iterator().next().toString();
        String txId = tx.getHash().toString();
        
        return createTrade(blockId, txId, unspentOutputIdx, inputValue, dest,
                numParties, blindingValues);
    }

    public static Trade createTrade(String blockId, String txId,
            int unspentOutputIdx, BigInteger inputValue, Address dest,
            int numParties) {
        
        return createTrade(blockId, txId, unspentOutputIdx, inputValue, dest,
                numParties, BlindingValues.NONE);
    }

    public static Trade createTrade(String blockId, String txId,
            int unspentOutputIdx, BigInteger inputValue, Address dest,
            int numParties, BlindingValues blindingValues) {
        
        TransactionSchema schema = getSchema(inputValue, numParties,
                blindingValues);

        TransactionSchemaProtos.BigInteger inputBtc = SchemaUtils
                .writeBigInteger(inputValue);
        TransactionSchemaProtos.BigInteger outputBtc = SchemaUtils
                .writeBigInteger(inputValue.subtract(fee.divide(new BigInteger(
                        Integer.toString(numParties)))));
        
        boolean blindOut = ((blindingValues == BlindingValues.OUTPUTS)
                || (blindingValues == BlindingValues.BOTH));

        DataItem.Builder output = DataItem
            .newBuilder()
            .setHeader(
                DataItemHeader
                    .newBuilder()
                    .setReference(
                        IOTypeReference
                            .newBuilder()
                            .setRefType(ReferenceType.OUTPUT)
                            .setRefIdx(0).build())
                    .setValue(outputBtc)
                    .setBlinded(blindOut)
                    .build());
        
        if (blindOut && (dest == null)) {
            // dest address may be null
        } else {
            output.setContent(SchemaUtils.createDataItemContent(dest));
        }

        List<SinglePartyData> allPartiesData = new ArrayList<SinglePartyData>();
        allPartiesData.add(SinglePartyData
            .newBuilder()
            .setPartyIdx(0)
            .addData(DataItem.newBuilder()
                .setHeader(DataItemHeader.newBuilder()
                    .setReference(
                            IOTypeReference
                                    .newBuilder()
                                    .setRefType(
                                            ReferenceType.INPUT)
                                    .setRefIdx(
                                            0)
                                    .build())
                    .setValue(inputBtc)
                    .setBlinded(
                            (blindingValues == BlindingValues.INPUTS)
                                    || (blindingValues == BlindingValues.BOTH))
                    .build())
                .setContent(SchemaUtils.createDataItemContent(
                        blockId, txId, unspentOutputIdx))
                .build())
            .addData(output)
            .build());

        return new Trade(schema, allPartiesData);
    }

    public static TransactionSchema getSchema(BigInteger inputValue,
            int numParties) {
        
        return getSchema(inputValue, numParties, BlindingValues.NONE);
    }

    public static TransactionSchema getSchema(BigInteger inputValue,
            int numParties, BlindingValues blindingValues) {

        TransactionSchemaProtos.BigInteger inputBtc = SchemaUtils
                .writeBigInteger(inputValue);
        TransactionSchemaProtos.BigInteger outputBtc = SchemaUtils
                .writeBigInteger(inputValue.subtract(fee.divide(new BigInteger(
                        Integer.toString(numParties)))));

        TransactionSchema schema = TransactionSchema.newBuilder()
            .addInputTypes(InputType.newBuilder()
                .setBlinded((blindingValues == BlindingValues.INPUTS)
                            || (blindingValues == BlindingValues.BOTH))
                .build())
            .addOutputTypes(OutputType.newBuilder()
                .setBlinded((blindingValues == BlindingValues.OUTPUTS)
                            || (blindingValues == BlindingValues.BOTH))
                .build())
            .addPartyTypes(PartyType.newBuilder()
                .addSpecifiers(IOTypeReference.newBuilder()
                    .setRefType(ReferenceType.INPUT)
                    .setRefIdx(0)
                    .build())
                .addSpecifiers(IOTypeReference.newBuilder()
                    .setRefType(ReferenceType.OUTPUT)
                    .setRefIdx(0)
                    .build())
                .build())
            .addConstraints(ConstraintFormula.newBuilder()
                .setForEach(ForEach.TYPEREF)
                .setForEachRef(IOTypeReference.newBuilder()
                    .setRefType(ReferenceType.INPUT)
                    .setRefIdx(0)
                    .build())
                .setComparator(Comparator.EQ)
                .addLhs(Expression.newBuilder()
                    .setElement(Element.newBuilder()
                        .setElementType(ElementType.VARIABLE)
                        .setVariable(Variable.newBuilder()
                            .setVariableType(VariableType.FOREACH_BTCVALUE)
                            .build())
                        .build())
                    .build())
                .addRhs(Expression.newBuilder()
                    .setElement(Element.newBuilder()
                        .setElementType(ElementType.VALUE)
                        .setValue(inputBtc)
                        .build())
                    .build())
                .build())
            .addConstraints(ConstraintFormula.newBuilder()
                .setForEach(ForEach.TYPEREF)
                .setForEachRef(IOTypeReference.newBuilder()
                    .setRefType(ReferenceType.OUTPUT)
                    .setRefIdx(0)
                    .build())
                .setComparator(Comparator.EQ)
                .addLhs(Expression.newBuilder()
                    .setElement(Element.newBuilder()
                        .setElementType(ElementType.VARIABLE)
                        .setVariable(Variable.newBuilder()
                            .setVariableType(VariableType.FOREACH_BTCVALUE)
                            .build())
                        .build())
                    .build())
                .addRhs(Expression.newBuilder()
                    .setElement(Element.newBuilder()
                        .setElementType(ElementType.VALUE)
                        .setValue(outputBtc)
                        .build())
                    .build())
                .build())
            .addConstraints(ConstraintFormula.newBuilder()
                .setComparator(Comparator.EQ)
                .addLhs(Expression.newBuilder()
                    .setElement(Element.newBuilder()
                        .setElementType(ElementType.VARIABLE)
                        .setVariable(Variable.newBuilder()
                            .setVariableType(VariableType.SUM_TYPE)
                            .setRefType(ReferenceType.INPUT)
                            .build())
                        .build())
                    .build())
                .addRhs(Expression.newBuilder()
                    .setElement(Element.newBuilder()
                        .setElementType(ElementType.VARIABLE)
                        .setVariable(Variable.newBuilder()
                            .setVariableType(VariableType.SUM_TYPE)
                            .setRefType(ReferenceType.OUTPUT)
                            .build())
                        .build())
                    .build())
                .build())
            .addCompletionRequirements(ConstraintFormula.newBuilder()
                .setComparator(Comparator.EQ)
                .addLhs(Expression.newBuilder()
                    .setElement(Element.newBuilder()
                        .setElementType(ElementType.VARIABLE)
                        .setVariable(Variable.newBuilder()
                            .setVariableType(VariableType.SUM_PARTYTYPE)
                            .setPartyTypeIndex(0)
                            .build())
                        .build())
                    .build())
                .addRhs(Expression.newBuilder()
                    .setElement(Element.newBuilder()
                        .setElementType(ElementType.VALUE)
                        .setValue(SchemaUtils.writeBigInteger(
                                new BigInteger(Integer.toString(numParties))))
                        .build())
                    .build())
                .build())
            .build();

        // schemas.put(schema, inputValue);

        // System.out.println(Hex.encodeHex(schema.toByteArray()));
        // System.out.println();
        // System.out.println(schema.toString());
        return schema;
    }
}
