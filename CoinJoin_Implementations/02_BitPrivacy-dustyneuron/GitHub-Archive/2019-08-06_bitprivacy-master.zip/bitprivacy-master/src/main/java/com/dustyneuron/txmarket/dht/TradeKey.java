package com.dustyneuron.txmarket.dht;

public interface TradeKey extends Comparable<TradeKey> {
    public byte[] toByteArray();

    @Override
    public boolean equals(Object obj);

    @Override
    public int hashCode();
}
