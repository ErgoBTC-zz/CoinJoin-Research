package com.dustyneuron.txmarket.schema;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import org.apache.commons.codec.binary.Hex;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItemContent;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItemHeader;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.IOTypeReference;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.InputType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.OutputType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.PartyType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedUnblinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SinglePartyData;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TradeListing;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TransactionSchema;
import com.dustyneuron.txmarket.schema.ConstraintsVerifier.TradeConstraintsStatus;
import com.dustyneuron.txmarket.schema.ConstraintsVerifier.VariableValues;
import com.google.bitcoin.core.Address;
import com.google.bitcoin.core.AddressFormatException;
import com.google.bitcoin.core.NetworkParameters;
import com.google.bitcoin.core.Sha256Hash;
import com.google.bitcoin.core.WrongNetworkException;
import com.google.protobuf.ByteString;
import com.google.protobuf.GeneratedMessage;

public class SchemaUtils {

    public static Sha256Hash getSchemaKey(TransactionSchema schema) {
        return getKey(schema);
    }

    public static Sha256Hash getDoubleSchemaKey(TransactionSchema schema) {
        Sha256Hash h = getKey(schema);
        return Sha256Hash.create(h.getBytes());
    }

    public static Sha256Hash getKey(GeneratedMessage o) {
        return Sha256Hash.create(o.toByteArray());
    }

    public static DataItemContent createDataItemContent(Address dest) {
        return DataItemContent.newBuilder()
                .setAddress(ByteString.copyFrom(dest.getHash160())).build();
    }

    public static DataItemContent createDataItemContent(String blockId,
            String txId, int unspentOutputIdx) {
        return DataItemContent
                .newBuilder()
                .setBlockId(
                        ByteString.copyFrom(org.spongycastle.util.encoders.Hex
                                .decode(blockId)))
                .setTxId(
                        ByteString.copyFrom(org.spongycastle.util.encoders.Hex
                                .decode(txId)))
                .setOutputIndex(unspentOutputIdx).build();
    }

    public static Sha256Hash extractBlockId(DataItem d) {
        return new Sha256Hash(Hex.encodeHexString(d.getContent().getBlockId()
                .toByteArray()));
    }

    public static Sha256Hash extractTxId(DataItem d) {
        return new Sha256Hash(Hex.encodeHexString(d.getContent().getTxId()
                .toByteArray()));
    }

    public static Address extractAddress(DataItem d, NetworkParameters params)
            throws WrongNetworkException, AddressFormatException {
        Address a = new Address(params, d.getContent().getAddress()
                .toByteArray());
        return a;
    }

    public static DataItem getDataItem(SignedUnblinded s) {
        return DataItem.newBuilder().setHeader(s.getHeader())
                .setContent(s.getContent()).build();
    }

    public static List<DataItem> getDataForBlinding(TradeListing l) {
        List<DataItem> results = new ArrayList<DataItem>();
        for (SinglePartyData p : l.getAllPartiesDataList()) {
            for (DataItem d : p.getDataList()) {
                if (usingBlinding(d)) {
                    results.add(d);
                }
            }
        }
        return results;
    }

    public static boolean usingBlinding(DataItem d) {
        if (d.getHeader().hasBlinded() && d.getHeader().getBlinded()) {
            return true;
        }
        return false;
    }

    public static boolean usingBlinding(TradeListing l) {
        for (SinglePartyData p : l.getAllPartiesDataList()) {
            for (DataItem d : p.getDataList()) {
                if (usingBlinding(d)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean listingContainsPrivateData(TradeListing l) {
        for (SinglePartyData p : l.getAllPartiesDataList()) {
            for (DataItem d : p.getDataList()) {
                if (usingBlinding(d) && d.hasContent()) {
                    return true;
                }
            }
        }
        return false;
    }

    public static DataItem createBlindData(DataItem d) {
        if (usingBlinding(d)) {
            return DataItem.newBuilder(d).clearContent().build();
        }
        return d;
    }

    public static List<DataItem> createBlindData(List<DataItem> l) {
        List<DataItem> results = new ArrayList<DataItem>();
        for (DataItem d : l) {
            results.add(createBlindData(d));
        }
        return results;
    }

    public static TradeListing createBlindListing(TradeListing listing) {
        TradeListing.Builder results = TradeListing.newBuilder(listing);
        results.clearAllPartiesData();

        for (SinglePartyData p : listing.getAllPartiesDataList()) {
            SinglePartyData.Builder newP = SinglePartyData.newBuilder(p);
            newP.clearData();
            newP.addAllData(createBlindData(p.getDataList()));

            results.addAllPartiesData(newP.build());
        }

        return results.build();
    }

    public static int findMatchingPrivateData(DataItem publicData,
            List<DataItem> privateDataList) {
        for (int i = 0; i < privateDataList.size(); ++i) {
            DataItem d = createBlindData(privateDataList.get(i));
            if (areIdentical(d, publicData)) {
                return i;
            }
        }
        return -1;
    }

    public static class TradeCombinationResult {
        public Trade trade;
        public boolean passedConstraints;
        public boolean complete;
    }

    private static boolean isSchemaSensible(TransactionSchema schema) {
        // TODO: implement isSchemaSensible
        // System.out.println("isSchemaSensible not implemented yet");
        return true;
    }

    public static TradeCombinationResult getTradeStatus(
            TransactionSchema schema, List<SinglePartyData> data)
            throws Exception {
        if (!isSchemaSensible(schema)) {
            throw new Exception("Error: schema is not sensible");
        }
        Trade original = new Trade(schema);

        Trade newTrade = new Trade(schema, data);

        TradeCombinationResult r = tryAddTrade(original, newTrade);
        if (r == null) {
            throw new Exception("tryAddTrade returned null");
        }
        return r;
    }

    private static boolean isTradeValid(TransactionSchema schema,
            List<SinglePartyData> data, boolean needsComplete,
            boolean allowComplete) throws Exception {
        TradeCombinationResult result = getTradeStatus(schema, data);
        if (result == null) {
            return false;
        }
        if (!result.passedConstraints) {
            return false;
        }
        if (needsComplete) {
            if (!result.complete) {
                return false;
            }
        }
        if (!allowComplete) {
            if (result.complete) {
                return false;
            }
        }

        return true;
    }

    public static boolean isTradeValidAndComplete(TransactionSchema schema,
            List<SinglePartyData> data) throws Exception {
        return isTradeValid(schema, data, true, true);
    }

    public static boolean isInitialListingValid(TransactionSchema schema,
            List<SinglePartyData> data) throws Exception {
        return isTradeValid(schema, data, false, false);
    }

    public static TradeCombinationResult tryAddTrade(Trade original,
            Trade newTrade) throws Exception {

        // we assume that 'original' is valid, within func limits, etc

        if (!SchemaUtils.areIdentical(original.getSchema(),
                newTrade.getSchema())) {
            System.out.println("Cannot add trade, schemas differ");
            return null;
        }
        // System.out.println("schemas match, good");

        List<SinglePartyData> partiesData = newTrade.getAllPartiesData();
        for (SinglePartyData partyData : partiesData) {
            if (!isPartyDataValid(original.getSchema(), partyData)) {
                System.out
                        .println("Cannot add party data to trade as it doesn't validate against the schema");
                return null;
            }
        }
        // System.out.println("validated extra party data against the schema ok");

        List<SinglePartyData> newPartiesData = new ArrayList<SinglePartyData>();
        newPartiesData.addAll(original.getAllPartiesData());
        newPartiesData.addAll(partiesData);
        Trade provisionalTrade = new Trade(original.getSchema(), newPartiesData);

        TradeCombinationResult result = new TradeCombinationResult();
        result.trade = provisionalTrade;
        result.complete = false;
        result.passedConstraints = false;

        VariableValues variableValues = ConstraintsVerifier
                .evaluateVariables(provisionalTrade);

        // System.out.println("evaluated variables ok");

        TradeConstraintsStatus forEachStatus = ConstraintsVerifier
                .evaluateForEachConstraints(provisionalTrade, variableValues,
                        provisionalTrade.getSchema().getConstraintsList());
        if (forEachStatus == TradeConstraintsStatus.CONSTRAINTS_BROKEN) {
            System.out
                    .println("Cannot add party data to trade as it breaks foreach constraints limits");
            return result;
        }

        // System.out.println("passed foreach constraints ok");

        TradeConstraintsStatus constraintsStatus = ConstraintsVerifier
                .evaluateConstraints(variableValues, provisionalTrade
                        .getSchema().getConstraintsList());

        if (constraintsStatus == TradeConstraintsStatus.CONSTRAINTS_BROKEN) {
            System.out
                    .println("Cannot add party data to trade as it breaks standard constraints limits");
            return result;
        }
        // System.out.println("passed standard constraints ok");
        result.passedConstraints = true;

        TradeConstraintsStatus completeStatus = ConstraintsVerifier
                .evaluateConstraints(variableValues, provisionalTrade
                        .getSchema().getCompletionRequirementsList());

        result.complete = (completeStatus == TradeConstraintsStatus.CONSTRAINTS_OK);

        //System.out.println("tryAddTrade completion status = " + completeStatus);
        return result;
    }

    public static <T extends GeneratedMessage> boolean areIdentical(T a, T b) {
        return Arrays.equals(a.toByteArray(), b.toByteArray());
    }

    public static <T extends GeneratedMessage> List<T> sortItems(List<T> items)
            throws Exception {

        PriorityQueue<BigInteger> queue = new PriorityQueue<BigInteger>();

        Map<BigInteger, T> map = new HashMap<BigInteger, T>();
        for (T i : items) {
            BigInteger key = getKey(i).toBigInteger();
            map.put(key, i);
            queue.add(key);
        }

        List<T> results = new ArrayList<T>();
        BigInteger k;
        while ((k = queue.poll()) != null) {
            results.add(map.get(k));
        }
        return results;
    }

    private static boolean dataItemMatchesSpecifier(List<InputType> inputTypes,
            List<OutputType> outputTypes, DataItem item,
            IOTypeReference specifier) throws Exception {
        // System.out.println("dataItemMatchesSpecifier:");
        // System.out.println(item.toString())

        DataItemHeader header = item.getHeader();
        DataItemContent content = null;
        if (item.hasContent()) {
            content = item.getContent();
        }

        if (!areIdentical(header.getReference(), specifier)) {
            System.out.println("data item header does not match specifier");
            return false;
        }

        switch (specifier.getRefType()) {
        case INPUT:
            InputType inputType = inputTypes.get(specifier.getRefIdx());
            if (!inputType.getBlinded()) {
                if (!item.hasContent() || !content.hasTxId()
                        || !content.hasBlockId() || !content.hasOutputIndex()) {
                    System.out
                            .println("data item doesn't have required fields for unblind INPUT");
                    return false;
                }
            }
            break;
        case OUTPUT:
            OutputType outputType = outputTypes.get(specifier.getRefIdx());
            if (!outputType.getBlinded()) {
                if (!item.hasContent() || !content.hasAddress()) {
                    System.out
                            .println("data item doesn't have required fields for unblind OUTPUT");
                    return false;
                }
            }
            break;
        default:
            throw new Exception("unhandled ref type");
        }

        return true;
    }

    private static boolean isPartyDataValid(TransactionSchema schema,
            SinglePartyData data) throws Exception {

        // System.out.println("isPartyDataValid:");
        // System.out.println(data.toString());

        int partyTypeIdx = data.getPartyIdx();
        if (schema.getPartyTypesCount() <= partyTypeIdx) {
            System.out.println("party data type idx " + partyTypeIdx
                    + " is invalid");
            return false;
        }

        // This checks that there is a 1-1 match between DataItems and
        // Specifiers
        //
        List<DataItem> unvalidatedItems = new ArrayList<DataItem>(
                data.getDataList());
        PartyType partyType = schema.getPartyTypes(partyTypeIdx);
        for (IOTypeReference specifier : partyType.getSpecifiersList()) {
            DataItem match = null;
            for (DataItem item : unvalidatedItems) {
                if (dataItemMatchesSpecifier(schema.getInputTypesList(),
                        schema.getOutputTypesList(), item, specifier)) {
                    match = item;
                    break;
                }
            }
            if (match == null) {
                System.out.println("Specifier had no matching DataItem");
                System.out.println(specifier.toString());
                return false;
            } else {
                // System.out.println("Matched specifier to DataItem");
                // System.out.println(match.toString());
                unvalidatedItems.remove(match);
            }
        }
        if (unvalidatedItems.size() > 0) {
            System.out
                    .println("not all DataItems validated against the schema PartyType");
            for (DataItem i : unvalidatedItems) {
                System.out.println(i.toString());
            }
            return false;
        }

        return true;
    }

    public static BigInteger readBigInteger(
            TransactionSchemaProtos.BigInteger btcValue) {
        byte[] orig = btcValue.getData().toByteArray();
        byte[] list = orig;

        // System.out.println("readBigInteger " + new
        // String(Hex.encodeHex(orig)));
        return new BigInteger(list);
    }

    public static TransactionSchemaProtos.BigInteger writeBigInteger(
            BigInteger v) {
        // System.out.println("writeBigInteger " + new
        // String(Hex.encodeHex(v.toByteArray())));

        TransactionSchemaProtos.BigInteger btcValue = TransactionSchemaProtos.BigInteger
                .newBuilder().setData(ByteString.copyFrom(v.toByteArray()))
                .build();

        return btcValue;
    }
}
