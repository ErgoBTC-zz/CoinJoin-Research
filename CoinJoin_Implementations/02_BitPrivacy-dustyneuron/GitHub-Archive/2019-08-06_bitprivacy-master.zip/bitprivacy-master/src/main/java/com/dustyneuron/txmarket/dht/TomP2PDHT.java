package com.dustyneuron.txmarket.dht;

import java.math.BigInteger;
import java.net.InetAddress;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.tomp2p.futures.FutureBootstrap;
import net.tomp2p.futures.FutureDHT;
import net.tomp2p.futures.FutureDiscover;
import net.tomp2p.p2p.Peer;
import net.tomp2p.p2p.PeerMaker;
import net.tomp2p.peers.Number160;
import net.tomp2p.peers.PeerAddress;
import net.tomp2p.storage.Data;
import net.tomp2p.storage.StorageGeneric.ProtectionEnable;
import net.tomp2p.storage.StorageGeneric.ProtectionMode;
import net.tomp2p.utils.Utils;

import org.spongycastle.crypto.params.RSAKeyParameters;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Blinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.PubKey;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedBlinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedUnblinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TransactionSchema;
import com.dustyneuron.txmarket.schema.FullTrade;
import com.dustyneuron.txmarket.schema.SchemaUtils;
import com.dustyneuron.txmarket.schema.TradeListing;
import com.google.protobuf.ByteString;
import com.google.protobuf.GeneratedMessage;

public class TomP2PDHT implements TradeDHT {

    public static final int wellKnownPortNumber = 9000;

    private Peer peer;
    private Number160 domainKey;

    private static Number160 getDHTKey(GeneratedMessage o) {
        assert (o != null);
        return Utils.makeSHAHash(o.toByteArray());
    }

    private static Number160 getDoubleDHTKey(GeneratedMessage o) {
        assert (o != null);
        Number160 n = Utils.makeSHAHash(o.toByteArray());
        return Utils.makeSHAHash(n.toByteArray());
    }

    private class TomP2PKey implements TradeKey {
        Number160 d;
        Number160 n;

        @Override
        public int hashCode() {
            return d.hashCode() + n.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            return this.compareTo((TradeKey) obj) == 0;
        }

        @Override
        public int compareTo(TradeKey o) {
            int c = n.compareTo(((TomP2PKey) o).n);
            if (c == 0) {
                c = d.compareTo(((TomP2PKey) o).d);
            }
            return c;
        }

        @Override
        public byte[] toByteArray() {
            byte[] data = new byte[40];
            byte[] nData = n.toByteArray();
            byte[] dData = d.toByteArray();
            for (int i = 0; i < 20; ++i) {
                data[i] = nData[i];
                data[i + 20] = dData[i];
            }
            return data;
        }

        public TomP2PKey(byte[] data) throws Exception {
            if (data.length != 40) {
                throw new Exception(
                        "Cannot parse byte[] into TomP2PTradeListingKey, length should be 40, got "
                                + data.length);
            }
            n = new Number160(Arrays.copyOfRange(data, 0, 20));
            d = new Number160(Arrays.copyOfRange(data, 20, 40));
        }

        public TomP2PKey(Number160 n, Number160 d) {
            this.n = n;
            this.d = d;
        }

        @Override
        public String toString() {
            return n.xor(d).toString();
        }
    }

    private class TomP2PTradeListingKey extends TomP2PKey implements
            TradeListingKey {
        Number160 contentKey;

        public TomP2PTradeListingKey(byte[] data) throws Exception {
            super(data);
        }

        public TomP2PTradeListingKey(byte[] data, Number160 contentKey)
                throws Exception {
            this(data);
            this.contentKey = contentKey;
        }

        public TomP2PTradeListingKey(Number160 n, Number160 d) {
            super(n, d);
        }
    }

    private class TomP2PSingleKey implements TradeKey {
        Number160 n;

        @Override
        public int hashCode() {
            return n.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            return this.compareTo((TradeKey) obj) == 0;
        }

        @Override
        public int compareTo(TradeKey o) {
            return n.compareTo(((TomP2PSingleKey) o).n);
        }

        @Override
        public byte[] toByteArray() {
            return n.toByteArray();
        }

        public TomP2PSingleKey(byte[] data) throws Exception {
            if (data.length != 20) {
                throw new Exception(
                        "Cannot parse byte[] into TomP2PCombinedTradeKey, length should be 20, got "
                                + data.length);
            }
            n = new Number160(data);
        }

        public TomP2PSingleKey(Number160 n) {
            this.n = n;
        }

        @Override
        public String toString() {
            return n.toString();
        }
    }

    private class TomP2PCombinedTradeKey extends TomP2PSingleKey implements
            FullTradeKey {
        Number160 contentKey;

        public TomP2PCombinedTradeKey(byte[] data, Number160 contentKey)
                throws Exception {
            super(data);
            this.contentKey = contentKey;
        }

        public TomP2PCombinedTradeKey(Number160 n) {
            super(n);
        }
    }

    private class TomP2PBlindedKey extends TomP2PSingleKey implements
            BlindedKey {
        TomP2PTradeListingKey individualKey;
        Number160 signedBlindedKey;

        public TomP2PBlindedKey(byte[] data, TomP2PTradeListingKey individualKey)
                throws Exception {
            super(data);
            this.individualKey = individualKey;
            this.signedBlindedKey = Utils.makeSHAHash(this.toByteArray());
        }

        public TomP2PBlindedKey(Number160 n, TomP2PTradeListingKey individualKey) {
            super(n);
            this.individualKey = individualKey;
            this.signedBlindedKey = Utils.makeSHAHash(this.toByteArray());
        }
    }

    private class TomP2PSignedUnblindedKey extends TomP2PSingleKey implements
            SignedUnblindedKey {
        Number160 contentKey;

        public TomP2PSignedUnblindedKey(byte[] data, Number160 contentKey)
                throws Exception {
            super(data);
            this.contentKey = contentKey;
        }

        public TomP2PSignedUnblindedKey(FullTradeKey k) {
            super(Utils.makeSHAHash(k.toByteArray()));
        }
    }

    private Number160 combineKey(byte[][] buffers) {
        int newKeyLength = 0;
        for (int i = 0; i < buffers.length; ++i) {
            newKeyLength += buffers[i].length;
        }
        byte[] newKey = new byte[newKeyLength];
        int pos = 0;
        for (int i = 0; i < buffers.length; ++i) {
            System.arraycopy(buffers[i], 0, newKey, pos, buffers[i].length);
            pos += buffers[i].length;
        }
        return Utils.makeSHAHash(newKey);
    }

    private Number160 add(Number160 key, Number160 domain, Data d)
            throws Exception {
        // System.out.println("add(" + key + ", " + domain + ", data)");
        FutureDHT f = peer.add(key).setData(d).setDomainKey(domain)
                .setProtectDomain().start().awaitUninterruptibly();
                //.setProtectDomain().setSignMessage().start().awaitUninterruptibly();
        if (f.isFailed()) {
            throw new Exception("TomP2P failed to add data: "
                    + f.getFailedReason());
        }
        if ((f.getEvalKeys() == null)
                || (f.getEvalKeys().iterator().next() == null)) {
            throw new Exception("TomP2P add data didn't set a content key - "
                    + f);
        }
        return f.getEvalKeys().iterator().next().getContentKey();
    }

    private void put(Number160 key, Number160 domain, Data d) throws Exception {
        // System.out.println("put(" + key + ", " + domain + ", data)");
        FutureDHT f = peer.put(key).setData(d).setDomainKey(domain)
                .setProtectDomain().start().awaitUninterruptibly();
                //.setProtectDomain().setSignMessage().start().awaitUninterruptibly();
        if (f.isFailed()) {
            throw new Exception("TomP2P failed to put data: "
                    + f.getFailedReason());
        }
    }

    private byte[] get(Number160 key, Number160 domain) throws Exception {
        // System.out.println("get(" + key + ", " + domain + ")");
        FutureDHT f = peer.get(key).setDomainKey(domain).start()
                .awaitUninterruptibly();
        if (!f.isCompleted()) {
            throw new Exception("TomP2P get data did not complete: "
                    + f.getFailedReason());
        }
        Data d = f.getData();
        if (d == null) {
            return null;
        }
        /*
        if (!d.isProtectedEntry()) {
            throw new Exception("TomP2P get data was not a protected entry");
        }
        */
        return d.getData();
    }

    private boolean del(Number160 key, Number160 domain) throws Exception {
        // System.out.println("del(" + key + ", " + domain + ")");
        FutureDHT f = peer.remove(key).setAll().setSignMessage()
                .setDomainKey(domain).start().awaitUninterruptibly();
        if (!f.isCompleted()) {
            throw new Exception("TomP2P del data did not complete: "
                    + f.getFailedReason());
        }
        return f.isSuccess();
    }

    private boolean del(Number160 key, Number160 domain, Number160 content)
            throws Exception {
        // System.out.println("del(" + key + ", " + domain + ", " + content +
        // ")");
        assert (content != null);
        FutureDHT f = peer.remove(key).setContentKey(content).setSignMessage()
                .setDomainKey(domain).start().awaitUninterruptibly();
        if (!f.isCompleted()) {
            throw new Exception("TomP2P del data did not complete: "
                    + f.getFailedReason());
        }
        return f.isSuccess();
    }

    private Map<Number160, Data> getAll(Number160 key, Number160 domain)
            throws Exception {
        // System.out.println("getAll(" + key + ", " + domain + ")");
        FutureDHT f = peer.get(key).setDomainKey(domain).setAll().start()
                .awaitUninterruptibly();
        if (!f.isCompleted()) {
            throw new Exception("TomP2P get all data did not complete: "
                    + f.getFailedReason());
        }
        if (f.isFailed() || (f.getDataMap() == null)) {
            return new HashMap<Number160, Data>();
        }
        return f.getDataMap();
    }

    private Number160 getDomainKey(TradeListing listing) {
        return new Number160(listing.getPeerId());
    }

    // ////////////////////////////////////////////////////////////////////////

    public TomP2PDHT() {
    }

    @Override
    public void connect(String host, boolean deterministic) throws Exception {
        if (peer != null) {
            throw new Exception("already connected");
        }
        /*
         * // TomP2P only supports DSA atm :-( Security.addProvider(new
         * BouncyCastleProvider()); KeyPairGenerator gen =
         * KeyPairGenerator.getInstance("ECDSA"); gen.initialize(new
         * ECGenParameterSpec("secp521r1"));
         */
        KeyPairGenerator gen = KeyPairGenerator.getInstance("DSA");
        if (deterministic) {
            SecureRandom random = SecureRandom.getInstance("InsecureRandom");
            gen.initialize(1024, random);
            random.nextInt();
        }
        KeyPair keyPair = gen.generateKeyPair();
        domainKey = Utils.makeSHAHash(keyPair.getPublic().getEncoded());

        if (host == null) {
            System.out.println("Listening on port " + wellKnownPortNumber);

            peer = new PeerMaker(keyPair).setPorts(wellKnownPortNumber)
                    .makeAndListen();
            peer.getPeerBean()
                    .getStorage()
                    .setProtection(ProtectionEnable.NONE,
                            ProtectionMode.MASTER_PUBLIC_KEY,
                            ProtectionEnable.NONE,
                            ProtectionMode.MASTER_PUBLIC_KEY);
            peer.getConfiguration().setBehindFirewall(false);

        } else {
            InetAddress wellKnownHost = InetAddress.getByName(host);

            System.out.println("Connecting to " + wellKnownHost + ", port "
                    + wellKnownPortNumber);

            int listenPort;
            if (deterministic) {
                listenPort = wellKnownPortNumber
                        + 1
                        + (SecureRandom.getInstance("InsecureRandom").nextInt() % 1000);
            } else {
                listenPort = wellKnownPortNumber + 1
                        + (int) Math.floor(Math.random() * 1000);
            }
            peer = new PeerMaker(keyPair).setPorts(listenPort).makeAndListen();
            peer.getPeerBean()
                    .getStorage()
                    .setProtection(ProtectionEnable.NONE,
                            ProtectionMode.MASTER_PUBLIC_KEY,
                            ProtectionEnable.NONE,
                            ProtectionMode.MASTER_PUBLIC_KEY);
            peer.getConfiguration().setBehindFirewall(true);

            FutureDiscover discover = peer.discover()
                    .setInetAddress(wellKnownHost)
                    .setPorts(wellKnownPortNumber).start();
            if (!discover.await(5000) || discover.isFailed()) {
                throw new Exception("Failed discovery via well known host: "
                        + discover.getFailedReason());
            }
            FutureBootstrap bootstrap = peer.bootstrap()
                    .setInetAddress(wellKnownHost)
                    .setPorts(wellKnownPortNumber).start();
            if (!bootstrap.await(5000) || bootstrap.isFailed()) {
                throw new Exception("Failed to bootstrap to well known host: "
                        + bootstrap.getFailedReason());
            }
            PeerAddress wellKnown = bootstrap.getBootstrapTo().iterator()
                    .next();
            System.out.println("Connected to " + wellKnown);
        }

        // client = new ClientHandler(this);
        // peer.setRawDataReply(client);
    }

    @Override
    public byte[] getPeerId() {
        return domainKey.toByteArray();
    }

    @Override
    public String peerIdToString(byte[] peerId) {
        return new Number160(peerId).toString();
    }

    @Override
    public void disconnect() {
        if (peer != null) {
            peer.shutdown();
            peer = null;
        }
    }

    // //////////////////////////////////////////////////////////////////////

    @Override
    public TradeListingKey getKey(TradeListing l) {
        return new TomP2PTradeListingKey(
                getDHTKey(l.createBlindListing().getData()), getDomainKey(l));
    }

    @Override
    public TradeListingKey addTradeListing(TransactionSchema schema,
            TradeListing listing) throws Exception {
        if (listing.containsPrivateData()) {
            throw new Exception("listing contains private data");
        }
        TomP2PTradeListingKey key = (TomP2PTradeListingKey) getKey(listing);
        put(key.n, key.d, new Data(listing.getData().toByteArray()));
        key.contentKey = add(getDHTKey(schema), getDHTKey(schema),
                new Data(key.toByteArray()));
        return key;
    }

    @Override
    public TradeListing getTradeListing(TradeListingKey key) throws Exception {
        TomP2PTradeListingKey k = (TomP2PTradeListingKey) key;
        byte[] d = get(k.n, k.d);
        if (d == null) {
            return null;
        }
        return TradeListing.parseFrom(d, k.d.toByteArray());
    }

    @Override
    public boolean delTradeListing(TradeListingKey key) throws Exception {
        TomP2PTradeListingKey k = (TomP2PTradeListingKey) key;
        return del(k.n, k.d);
    }

    @Override
    public List<TradeListingKey> getTradeListingKeys(TransactionSchema schema)
            throws Exception {
        Map<Number160, Data> results = getAll(getDHTKey(schema),
                getDHTKey(schema));
        List<TradeListingKey> list = new ArrayList<TradeListingKey>();
        for (Number160 k : results.keySet()) {
            Data d = results.get(k);
            TomP2PTradeListingKey key = new TomP2PTradeListingKey(d.getData(),
                    k);
            list.add(key);
        }
        return list;
    }

    @Override
    public boolean delTradeListingKey(TransactionSchema schema,
            TradeListingKey key) throws Exception {
        TomP2PTradeListingKey k = (TomP2PTradeListingKey) key;
        return del(getDHTKey(schema), getDHTKey(schema), k.contentKey);
    }

    @Override
    public FullTradeKey getKey(FullTrade combined) {
        return new TomP2PCombinedTradeKey(
                getDHTKey(combined.getRawGeneratedMessage()));
    }

    @Override
    public FullTradeKey putCombinedTrade(FullTrade combined) throws Exception {
        TomP2PCombinedTradeKey key = (TomP2PCombinedTradeKey) getKey(combined);
        put(key.n, key.n, new Data(combined.getRawGeneratedMessage()
                .toByteArray()));
        return key;
    }

    @Override
    public boolean delCombinedTrade(FullTradeKey k) throws Exception {
        TomP2PCombinedTradeKey key = (TomP2PCombinedTradeKey) k;
        return del(key.n, key.n);
    }

    @Override
    public FullTrade getCombinedTrade(FullTradeKey key) throws Exception {
        TomP2PCombinedTradeKey k = (TomP2PCombinedTradeKey) key;
        byte[] d = get(k.n, k.n);
        if (d == null) {
            return null;
        }
        List<TradeListingKey> results = new ArrayList<TradeListingKey>();
        TransactionSchemaProtos.FullTradeData c = TransactionSchemaProtos.FullTradeData
                .parseFrom(d);
        for (ByteString b : c.getTradeListingKeyList()) {
            results.add(new TomP2PTradeListingKey(b.toByteArray()));
        }
        return new FullTrade(this, results);
    }

    @Override
    public List<FullTradeKey> getCombinedTradeKeys(TransactionSchema schema)
            throws Exception {
        Map<Number160, Data> results = getAll(getDoubleDHTKey(schema),
                getDoubleDHTKey(schema));
        List<FullTradeKey> list = new ArrayList<FullTradeKey>();
        for (Number160 k : results.keySet()) {
            Data d = results.get(k);
            TomP2PCombinedTradeKey key = new TomP2PCombinedTradeKey(
                    d.getData(), k);
            list.add(key);
        }
        return list;
    }

    @Override
    public FullTradeKey addCombinedTradeKey(TransactionSchema schema,
            FullTradeKey k) throws Exception {
        TomP2PCombinedTradeKey key = (TomP2PCombinedTradeKey) k;
        key.contentKey = add(getDoubleDHTKey(schema), getDoubleDHTKey(schema),
                new Data(key.toByteArray()));
        return key;
    }

    @Override
    public boolean delCombinedTradeKey(TransactionSchema schema,
            FullTradeKey key) throws Exception {
        TomP2PCombinedTradeKey k = (TomP2PCombinedTradeKey) key;
        return del(getDoubleDHTKey(schema), getDoubleDHTKey(schema),
                k.contentKey);
    }

    @Override
    public void putBlindingPubKey(FullTradeKey combinedKey,
            TradeListingKey individualKey, RSAKeyParameters pubKey)
            throws Exception {
        Number160 key = Utils.makeSHAHash(getSignedTxKey(combinedKey,
                individualKey).toByteArray());

        PubKey pk = PubKey
                .newBuilder()
                .setModulus(
                        ByteString.copyFrom(pubKey.getModulus().toByteArray()))
                .setExponent(
                        ByteString.copyFrom(pubKey.getExponent().toByteArray()))
                .build();

        put(key, ((TomP2PTradeListingKey) individualKey).d,
                new Data(pk.toByteArray()));
    }

    @Override
    public RSAKeyParameters getBlindingPubKey(FullTradeKey combinedKey,
            TradeListingKey individualKey) throws Exception {
        Number160 key = Utils.makeSHAHash(getSignedTxKey(combinedKey,
                individualKey).toByteArray());

        byte[] data = get(key, ((TomP2PTradeListingKey) individualKey).d);
        if (data == null) {
            return null;
        }
        PubKey pk = PubKey.parseFrom(data);

        return new RSAKeyParameters(false, new BigInteger(pk.getModulus()
                .toByteArray()), new BigInteger(pk.getExponent().toByteArray()));
    }

    @Override
    public BlindedKey getKey(DataItem data, FullTradeKey combinedKey,
            TradeListingKey individualKey, int dataIdx) throws Exception {

        byte[][] buffers = new byte[4][];
        buffers[0] = getDHTKey(SchemaUtils.createBlindData(data)).toByteArray();
        buffers[1] = combinedKey.toByteArray();
        buffers[2] = individualKey.toByteArray();
        buffers[3] = BigInteger.valueOf(dataIdx).toByteArray();

        Number160 key = combineKey(buffers);
        return new TomP2PBlindedKey(key, (TomP2PTradeListingKey) individualKey);
    }

    @Override
    public void putBlinded(BlindedKey key, Blinded blinded) throws Exception {
        TomP2PBlindedKey k = (TomP2PBlindedKey) key;
        put(k.n, k.individualKey.d, new Data(blinded.toByteArray()));
    }

    @Override
    public Blinded getBlinded(BlindedKey key) throws Exception {
        TomP2PBlindedKey k = (TomP2PBlindedKey) key;
        byte[] d = get(k.n, k.individualKey.d);
        if (d == null) {
            return null;
        }
        return Blinded.parseFrom(d);
    }

    @Override
    public boolean delBlinded(BlindedKey key) throws Exception {
        TomP2PBlindedKey k = (TomP2PBlindedKey) key;
        return del(k.n, k.individualKey.d);
    }

    @Override
    public void putSignedBlinded(BlindedKey key, SignedBlinded signed)
            throws Exception {
        TomP2PBlindedKey k = (TomP2PBlindedKey) key;
        put(k.signedBlindedKey, k.individualKey.d,
                new Data(signed.toByteArray()));
    }

    @Override
    public SignedBlinded getSignedBlinded(BlindedKey key) throws Exception {
        TomP2PBlindedKey k = (TomP2PBlindedKey) key;
        byte[] d = get(k.signedBlindedKey, k.individualKey.d);
        if (d == null) {
            return null;
        }
        return SignedBlinded.parseFrom(d);
    }

    @Override
    public boolean delSignedBlinded(BlindedKey key) throws Exception {
        TomP2PBlindedKey k = (TomP2PBlindedKey) key;
        return del(k.signedBlindedKey, k.individualKey.d);
    }

    @Override
    public SignedUnblindedKey addSignedUnblinded(SignedUnblinded signed,
            FullTradeKey combined) throws Exception {
        TomP2PSignedUnblindedKey k = new TomP2PSignedUnblindedKey(combined);
        k.contentKey = add(k.n, k.n, new Data(signed.toByteArray()));
        return k;
    }

    @Override
    public List<SignedUnblinded> getSignedUnblindeds(FullTradeKey combined)
            throws Exception {
        TomP2PSignedUnblindedKey k = new TomP2PSignedUnblindedKey(combined);
        Map<Number160, Data> results = getAll(k.n, k.n);
        List<SignedUnblinded> list = new ArrayList<SignedUnblinded>();
        for (Number160 n : results.keySet()) {
            Data d = results.get(n);
            SignedUnblinded s = SignedUnblinded.parseFrom(d.getData());
            list.add(s);
        }
        return list;

    }

    @Override
    public boolean delSignedUnblinded(SignedUnblindedKey key) throws Exception {
        TomP2PSignedUnblindedKey k = (TomP2PSignedUnblindedKey) key;
        return del(k.n, k.n, k.contentKey);
    }

    private Number160 getSignedTxKey(FullTradeKey combinedKey,
            TradeListingKey individualKey) {
        byte[][] buffers = new byte[2][];
        buffers[0] = combinedKey.toByteArray();
        buffers[1] = individualKey.toByteArray();
        return combineKey(buffers);
    }

    @Override
    public void putSignedTx(FullTradeKey combinedKey,
            TradeListingKey individualKey, byte[] txData) throws Exception {
        Number160 key = getSignedTxKey(combinedKey, individualKey);
        put(key, ((TomP2PTradeListingKey) individualKey).d, new Data(txData));
    }

    @Override
    public byte[] getSignedTx(FullTradeKey combinedKey,
            TradeListingKey individualKey) throws Exception {
        Number160 key = getSignedTxKey(combinedKey, individualKey);
        return get(key, ((TomP2PTradeListingKey) individualKey).d);
    }

    @Override
    public boolean delSignedTx(FullTradeKey combinedKey,
            TradeListingKey individualKey) throws Exception {
        Number160 key = getSignedTxKey(combinedKey, individualKey);
        return del(key, ((TomP2PTradeListingKey) individualKey).d);
    }
}
