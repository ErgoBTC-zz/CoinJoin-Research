package com.dustyneuron.txmarket;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Hex;
import org.spongycastle.crypto.AsymmetricCipherKeyPair;
import org.spongycastle.crypto.params.RSAKeyParameters;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Blinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ReferenceType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedBlinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedUnblinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SinglePartyData;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TransactionSchema;
import com.dustyneuron.txmarket.bitcoin.BlockDownloader;
import com.dustyneuron.txmarket.bitcoin.WalletUtils;
import com.dustyneuron.txmarket.blinding.Blinding;
import com.dustyneuron.txmarket.dht.BlindedKey;
import com.dustyneuron.txmarket.dht.FullTradeKey;
import com.dustyneuron.txmarket.dht.TradeDHT;
import com.dustyneuron.txmarket.dht.TradeListingKey;
import com.dustyneuron.txmarket.schema.FullTrade;
import com.dustyneuron.txmarket.schema.PartialSigner;
import com.dustyneuron.txmarket.schema.SchemaUtils;
import com.dustyneuron.txmarket.schema.SchemaUtils.TradeCombinationResult;
import com.dustyneuron.txmarket.schema.TradeListing;
import com.dustyneuron.txmarket.schema.TransactionVerifier;
import com.google.bitcoin.core.Address;
import com.google.bitcoin.core.ECKey;
import com.google.bitcoin.core.NetworkParameters;
import com.google.bitcoin.core.Sha256Hash;
import com.google.bitcoin.core.Transaction;
import com.google.bitcoin.core.Wallet;

public class Trader {
    private Sha256Hash schemaHash;
    private TransactionSchema schema;

    public int clientTradeId;

    private TradeListing listing;
    // contains unblinded data
    private TradeListing privateListing;
    private TradeListingKey listingKey;

    private boolean usingBlinding;
    private Blinding blinding;

    private enum Status {
        GETBLINDPUBKEY, BLINDINGSERVER, GETSIGNEDBLINDED, GETUNBLINDED, PRESIGNED, POSTSIGNED, FINISHED, INVALID
    };

    public class PotentialTrade {
        Status status;

        final FullTrade combinedTrade;
        private final boolean putCombinedTrade;

        AsymmetricCipherKeyPair blindingKeyPair;
        RSAKeyParameters blindingPubKey;

        Transaction unsignedTx;
        Transaction presignedTx;
        Transaction postsignedTx;
        Transaction completedTx;

        private Map<BlindedKey, DataItem> blindedPrivateData;
        private Map<BlindedKey, BigInteger> blindedFactors;
        private Map<BlindedKey, DataItem> blindedPublicData;
        private Map<BlindedKey, SignedBlinded> signedBlinded;
        private List<SignedUnblinded> signedUnblinded;

        public PotentialTrade(FullTrade c, NetworkParameters params,
                BlockDownloader blockDownloader, boolean putCombinedTrade,
                TradeDHT dht) throws Exception {
            combinedTrade = c;
            if (usingBlinding) {
                status = Status.GETBLINDPUBKEY;
                unsignedTx = null;
                blindedPrivateData = new HashMap<BlindedKey, DataItem>();
                blindedFactors = new HashMap<BlindedKey, BigInteger>();
                blindedPublicData = new HashMap<BlindedKey, DataItem>();
                signedBlinded = new HashMap<BlindedKey, SignedBlinded>();
                signedUnblinded = new ArrayList<SignedUnblinded>();
            } else {
                status = Status.PRESIGNED;
                unsignedTx = combinedTrade.createInitialTransaction(params,
                        blockDownloader);
            }

            this.putCombinedTrade = putCombinedTrade;
            if (putCombinedTrade) {
                System.out
                        .println("PotentialTrade() - putting combined trade to dht:\n\t"
                                + combinedTrade.getKey());
                dht.putCombinedTrade(combinedTrade);
                dht.addCombinedTradeKey(schema, combinedTrade.getKey());
            }
        }

        public void cleanup(TradeDHT dht) throws Exception {
            if (putCombinedTrade) {
                if (!dht.delCombinedTradeKey(schema, combinedTrade.getKey())) {
                    throw new Exception(
                            "couldn't delete combined trade key on cleanup of\n\t"
                                    + combinedTrade.getKey());
                }
                if (!dht.delCombinedTrade(combinedTrade.getKey())) {
                    throw new Exception(
                            "couldn't delete combined trade on cleanup of\n\t"
                                    + combinedTrade.getKey());
                }
            }

            List<TradeListingKey> keys = combinedTrade.getSortedKeys();
            if (!keys.get(keys.size() - 1).equals(listingKey)) {
                if (status == Status.POSTSIGNED) {
                    if (!dht.delSignedTx(combinedTrade.getKey(), listingKey)) {
                        throw new Exception(
                                "Failed to delete our signed tx after trade completed");
                    }
                }
            }
        }

        private Transaction getPreviousSigner(TradeDHT dht,
                NetworkParameters params, BlockDownloader blockDownloader)
                throws Exception {
            assert (unsignedTx != null);
            int index = combinedTrade.getSortedKeys().indexOf(listingKey);
            if (index == -1) {
                throw new Exception("listing key not found");
            }
            if (index == 0) {
                presignedTx = unsignedTx;
                return presignedTx;
            }
            TradeListingKey prev = combinedTrade.getSortedKeys().get(index - 1);

            System.out.println("Checking if prev signer has signed\n\t" + prev);

            List<TradeListing> expectedSigned = new ArrayList<TradeListing>(
                    combinedTrade.getSortedListings().subList(0, index));

            return haveSigned(dht, prev, combinedTrade, expectedSigned, params,
                    blockDownloader);
        }

        public TradeListingKey getBlindingServer() {
            return combinedTrade.getSortedKeys().get(0);
        }

        public boolean checkTurnToSign(TradeDHT dht, NetworkParameters params,
                BlockDownloader blockDownloader) throws Exception {
            assert (status == Status.PRESIGNED);

            presignedTx = getPreviousSigner(dht, params, blockDownloader);
            return presignedTx != null;
        }

        public void sign(TradeDHT dht, Wallet wallet) throws Exception {
            System.out.println("Signing tx!");

            assert (status == Status.PRESIGNED);
            assert (presignedTx != null);
            System.out.println("Raw tx data:");
            System.out.println(new String(Hex.encodeHex(presignedTx
                    .bitcoinSerialize())));
            System.out.println(WalletUtils.transactionToString(presignedTx,
                    wallet));
            System.out.println("Auto-signing:");
            postsignedTx = PartialSigner.doSignRequest(presignedTx,
                    listing.getData().getAllPartiesDataList(), wallet);
            System.out.println(WalletUtils.transactionToString(postsignedTx,
                    wallet));

            dht.putSignedTx(combinedTrade.getKey(), listingKey,
                    postsignedTx.bitcoinSerialize());
        }

        public boolean checkFinished(TradeDHT dht, NetworkParameters params,
                BlockDownloader blockDownloader) throws Exception {
            assert (status == Status.POSTSIGNED);
            List<TradeListingKey> keys = combinedTrade.getSortedKeys();
            TradeListingKey lastSigner = keys.get(keys.size() - 1);
            System.out.println("Checking if last signer has signed\n\t"
                    + lastSigner);

            completedTx = haveSigned(dht, lastSigner, combinedTrade,
                    combinedTrade.getSortedListings(), params, blockDownloader);
            if (completedTx == null) {
                return false;
            }
            return true;
        }

        public boolean checkAllBlindedSigned(TradeDHT dht) throws Exception {
            boolean complete = true;
            for (BlindedKey key : blindedPublicData.keySet()) {
                SignedBlinded s = dht.getSignedBlinded(key);
                if (s == null) {
                    complete = false;
                } else {
                    signedBlinded.put(key, s);

                    BigInteger blindingFactor = blindedFactors.get(key);
                    // If this is one of ours, verify it
                    if (blindingFactor != null) {
                        SignedUnblinded u = blinding.unblind(s,
                                blindedPrivateData.get(key), blindingFactor,
                                blindingPubKey);
                        if ((u == null)
                                || !blinding.verify(u,
                                        blindedPrivateData.get(key).getContent(),
                                        blindingPubKey)) {
                            throw new Exception(
                                    "Signed blinded address did not verify for BlindedKey "
                                            + key);
                        }
                    }
                }
            }
            return complete;
        }

        public boolean signBlindedOutputs(TradeDHT dht) throws Exception {
            boolean complete = true;
            for (BlindedKey key : blindedPublicData.keySet()) {
                Blinded b = dht.getBlinded(key);
                if (b == null) {
                    complete = false;
                } else {
                    SignedBlinded s = blinding.sign(b, blindingKeyPair);
                    dht.putSignedBlinded(key, s);
                }
            }
            return complete;
        }

        public boolean checkAllUnblinded(TradeDHT dht,
                NetworkParameters params, BlockDownloader blockDownloader)
                throws Exception {
            List<SignedUnblinded> list = dht.getSignedUnblindeds(combinedTrade
                    .getKey());
            if (list.size() < blindedPublicData.keySet().size()) {
                return false;
            }
            if (list.size() > blindedPublicData.keySet().size()) {
                throw new Exception(
                        "Too many signed unblinded outputs listed, aborting");
            }

            List<DataItem> privateData = new ArrayList<DataItem>();
            for (SignedUnblinded u : list) {
                if (!blinding.verify(u, null, blindingPubKey)) {
                    throw new Exception("signed unblinded sig did not verify against blinding server pub key");
                }
                privateData.add(SchemaUtils.getDataItem(u));
            }

            List<DataItem> privateDataCopy = new ArrayList<DataItem>(
                    privateData);
            for (DataItem myData : privateListing.getDataForBlinding()) {
                DataItem found = null;
                for (DataItem d : privateDataCopy) {
                    if (SchemaUtils.areIdentical(d, myData)) {
                        found = d;
                        break;
                    }
                }
                if (found == null) {
                    throw new Exception(
                            "Security error - our private data was not in the unblinded data in the dht");
                }
                privateDataCopy.remove(found);
            }

            combinedTrade.loadUnblindedData(privateData);

            unsignedTx = combinedTrade.createInitialTransaction(params,
                    blockDownloader);
            if (unsignedTx == null) {
                throw new Exception(
                        "failed to create unsignedTx after loading unblinded data");
            }

            return true;
        }
    }

    private List<PotentialTrade> potentialTrades;
    private PotentialTrade finished;

    static int clientIdCounter = 0;

    private final boolean generateBlindOutputs;

    public Trader(TransactionSchema s, TradeListing t, boolean deterministic,
            Blinding blinding, boolean generateBlindOutputs) {
        schema = s;
        privateListing = t;
        this.blinding = blinding;
        usingBlinding = t.usingBlinding();
        if (usingBlinding) {
            listing = t.createBlindListing();
        } else {
            listing = t;
        }
        schemaHash = SchemaUtils.getSchemaKey(s);
        if (deterministic) {
            clientTradeId = ++clientIdCounter;
        } else {
            clientTradeId = (int) Math.floor(Math.random()
                    * (double) Integer.MAX_VALUE);
        }
        finished = null;
        potentialTrades = new ArrayList<PotentialTrade>();
        this.generateBlindOutputs = generateBlindOutputs;
    }

    public boolean isFinished() {
        return finished != null;
    }

    public void putTradeListing(TradeDHT dht) throws Exception {
        listingKey = dht.addTradeListing(schema, listing);
        System.out.println("\nputTradeListing()\n\tpeerId\t"
                + dht.peerIdToString(dht.getPeerId()) + "\n\tkey\t"
                + listingKey);
    }

    public static List<List<TradeListing>> tryMakeCompleteTrade(TradeDHT dht,
            TransactionSchema schema, List<TradeListing> listings,
            TradeListing required) throws Exception {
        // System.out.println("tryFindCompleteTrade - generating permutations...");
        assert (required != null);
        List<TradeListing> list = new ArrayList<TradeListing>(listings);
        TradeListingKey requiredKey = dht.getKey(required);
        int requiredIndex = -1;
        for (int i = 0; i < list.size(); ++i) {
            assert (list.get(i) != null);
            if (dht.getKey(list.get(i)).compareTo(requiredKey) == 0) {
                requiredIndex = i;
                break;
            }
        }
        if (requiredIndex == -1) {
            throw new Exception("failed to find required element");
        }
        list.remove(requiredIndex);
        list.add(0, required);

        // brute force: generate all possible permutations of 'listings'

        List<List<TradeListing>> perms = GeneralUtils
                .permutationsWithFirstElement(list);

        for (List<TradeListing> combination : perms) {
            @SuppressWarnings("unused")
            String s = "[\t";
            for (TradeListing l : combination) {
                s += dht.getKey(l).toString() + "\n\t";
            }
            s += "]\n";
            // System.out.print(s);
        }

        System.out
                .println("tryFindCompleteTrade - bruteforcing permutations...");

        // brute force: test all possible permutations for trade completion
        List<List<TradeListing>> results = new ArrayList<List<TradeListing>>();
        for (List<TradeListing> combination : perms) {
            String s = "[";
            List<SinglePartyData> allParties = new ArrayList<SinglePartyData>();
            for (TradeListing l : combination) {
                allParties.addAll(l.getData().getAllPartiesDataList());
                s += "\t" + dht.getKey(l).toString() + "\n";
            }

            TradeCombinationResult r = SchemaUtils.getTradeStatus(schema,
                    allParties);
            if (r.passedConstraints && r.complete) {
                System.out.println(s + "] found match!");
                results.add(combination);
            } else {
                System.out.println(s + "] not a match");
            }
        }

        return results;
    }

    private Transaction haveSigned(TradeDHT dht, TradeListingKey individualKey,
            FullTrade combined, List<TradeListing> expectedSigned,
            NetworkParameters params, BlockDownloader blockDownloader)
            throws Exception {

        byte[] signedTxData = dht.getSignedTx(dht.getKey(combined),
                individualKey);
        if (signedTxData == null) {
            return null;
        }
        if (signedTxData.length == 0) {
            throw new Exception("signed tx data has length 0");
        }

        List<SinglePartyData> allParties = new ArrayList<SinglePartyData>();
        for (TradeListing l : combined.getSortedListings()) {
            allParties.addAll(l.getData().getAllPartiesDataList());
        }

        Transaction tx = TransactionVerifier.isSignedTxValid(signedTxData,
                schema, allParties, expectedSigned, params, blockDownloader);

        if (tx == null) {
            throw new Exception(
                    "Server is misbehaving - sign request is invalid");
        }

        return tx;
    }

    private List<TradeListing> getValidTradeListings(List<TradeListingKey> keys,
            TradeDHT dht) throws Exception {
        List<TradeListing> listings = new ArrayList<TradeListing>();

        System.out.println("getValidTradeListings()");
        List<TradeListingKey> keysToRemove = new ArrayList<TradeListingKey>();
        for (TradeListingKey k : keys) {
            TradeListing l = dht.getTradeListing(k);
            if (l == null) {
                keysToRemove.add(k);
                System.out.println("\trem'd\t" + k
                        + "\n\t\t(no matching trade listing in dht)");
            } else if (SchemaUtils.isInitialListingValid(schema, l.getData().getAllPartiesDataList())) {
                listings.add(l);
                System.out.println("\tkey\t" + k);
            } else {
                keysToRemove.add(k);
                System.out.println("\trem'd\t" + k
                        + "\n\t\t(trade listing didn't validate against schema)");
            }
        }
        // System.out.println("getValidTradeListings[" + s + "], removed keys ["
        // + r + "]");
        keys.removeAll(keysToRemove);
        return listings;
    }

    public static boolean tryDisruptTrade(TransactionSchema schema, TradeDHT dht)
            throws Exception {
        System.out.println("tryDisruptTrade()\n\tpeerId\t"
                + dht.peerIdToString(dht.getPeerId()));

        List<TradeListingKey> allTradeListingKeys = dht
                .getTradeListingKeys(schema);
        boolean gotAny = false;
        for (TradeListingKey k : allTradeListingKeys) {
            if (dht.delTradeListingKey(schema, k)) {
                gotAny = true;
                System.out.println("\t del'd key " + k);
            }
            if (dht.delTradeListing(k)) {
                gotAny = true;
                System.out.println("\t del'd listing " + k);
            }
        }
        return gotAny;
    }

    private static List<FullTrade> readCombinedTrades(TransactionSchema schema,
            TradeDHT dht, TradeListingKey required,
            List<TradeListing> allTradeListings) throws Exception {
        List<FullTrade> list = new ArrayList<FullTrade>();

        List<FullTradeKey> keys = dht.getCombinedTradeKeys(schema);
        for (FullTradeKey k : keys) {
            FullTrade c = dht.getCombinedTrade(k);
            if (c.getSortedKeys().contains(required)) {
                if (c.loadTradeListings(dht, allTradeListings)) {
                    list.add(c);
                }
            }
        }
        return list;
    }

    private void addPotentialTrades(List<FullTrade> newTrades,
            boolean putCombinedTrade, TradeDHT dht, NetworkParameters params,
            BlockDownloader blockDownloader) throws Exception {
        for (FullTrade c : newTrades) {
            boolean isNew = true;
            for (PotentialTrade p : potentialTrades) {
                if (p.combinedTrade.equals(c)) {
                    isNew = false;
                    break;
                }
            }
            if (isNew) {
                PotentialTrade p = new PotentialTrade(c, params,
                        blockDownloader, putCombinedTrade, dht);
                potentialTrades.add(p);
            }
        }
    }

    private List<FullTrade> makeNewTrades(TradeDHT dht,
            List<TradeListing> allTradeListings) throws Exception {

        List<List<TradeListing>> newTrades = tryMakeCompleteTrade(dht, schema,
                allTradeListings, listing);

        List<FullTrade> list = new ArrayList<FullTrade>();
        for (List<TradeListing> trade : newTrades) {
            FullTrade c = new FullTrade(dht, FullTrade.getKeys(dht, trade));
            if (!c.loadTradeListings(dht, allTradeListings)) {
                throw new Exception(
                        "internal error - made new trade but we don't have all trade listings for it");
            }
            list.add(c);
        }
        return list;
    }

    private static boolean checkCombinedTradeMembers(PotentialTrade p,
            List<TradeListingKey> allTradeListingKeys) {
        for (TradeListingKey key : p.combinedTrade.getSortedKeys()) {
            if (!allTradeListingKeys.contains(key)) {
                System.out
                        .println("checkCombinedTradeMembers - key not found in allTradeListingKeys:\n\t"
                                + key);
                return false;
            }
        }
        return true;
    }

    private Address generateNewAddress(Wallet wallet) {
        ECKey key = new ECKey();
        wallet.addKey(key);
        return new Address(wallet.getNetworkParameters(), key.getPubKeyHash());
    }

    private TradeListing generateBlindOutputs(PotentialTrade p, TradeDHT dht,
            Wallet wallet) throws Exception {

        List<SinglePartyData> newPartiesData = new ArrayList<SinglePartyData>();
        for (SinglePartyData partyData : privateListing.getData().getAllPartiesDataList()) {

            SinglePartyData.Builder newPartyData = SinglePartyData.newBuilder(
                    partyData).clearData();

            for (DataItem privateData : partyData.getDataList()) {
                if (SchemaUtils.usingBlinding(privateData)
                        && privateData.getHeader().getReference().getRefType() == ReferenceType.OUTPUT) {

                    DataItem.Builder newData = DataItem.newBuilder(privateData);
                    newData.clearContent();
                    newData.setContent(SchemaUtils
                            .createDataItemContent(generateNewAddress(wallet)));
                    newPartyData.addData(newData);
                } else {
                    newPartyData.addData(privateData);
                }
            }

            newPartiesData.add(newPartyData.build());
        }

        TradeListing newPrivateListing = new TradeListing(newPartiesData, privateListing);

        if (!dht.getKey(newPrivateListing).equals(listingKey)) {
            throw new Exception(
                    "We updated our blinded private data and it changed the listing key - should not happen!");
        }
        return newPrivateListing;
    }

    private void putBlinded(PotentialTrade p, TradeDHT dht, Wallet wallet)
            throws Exception {
        if (generateBlindOutputs) {
            privateListing = generateBlindOutputs(p, dht, wallet);
        }

        for (TradeListing l : p.combinedTrade.getSortedBlindedListings()) {
            TradeListingKey tlk = dht.getKey(l);
            if (tlk.equals(listingKey)) {
                l = privateListing;
            }
            int dataIdx = 0;
            for (SinglePartyData partyData : l.getData().getAllPartiesDataList()) {
                for (DataItem publicData : partyData.getDataList()) {
                    if (SchemaUtils.usingBlinding(publicData)) {
                        BlindedKey blindedKey = dht.getKey(publicData,
                                p.combinedTrade.getKey(), tlk, dataIdx);
                        p.blindedPublicData.put(blindedKey, publicData);

                        if (tlk.equals(listingKey)) {
                            DataItem privateData = publicData;

                            p.blindedPrivateData.put(blindedKey, privateData);

                            BigInteger factor = blinding
                                    .generateBlindingFactor(p.blindingPubKey);
                            p.blindedFactors.put(blindedKey, factor);

                            Blinded b = blinding.blind(privateData, factor,
                                    p.blindingPubKey);
                            dht.putBlinded(blindedKey, b);
                        }
                    }
                    ++dataIdx;
                }
            }
        }
    }

    private void putUnblinded(PotentialTrade p, TradeDHT dht) throws Exception {
        // Must be some 'securely' random time between GETSIGNEDBLINDED &
        // PUTUNBLINDED
        // TODO: PUTUNBLINDED ops should be run at a secure random time in new
        // threads with new p2p connection
        for (BlindedKey k : p.signedBlinded.keySet()) {
            BigInteger factor = p.blindedFactors.get(k);
            if (factor != null) {
                SignedUnblinded u = blinding.unblind(p.signedBlinded.get(k),
                        p.blindedPrivateData.get(k), factor, p.blindingPubKey);

                p.signedUnblinded.add(u);
                dht.addSignedUnblinded(u, p.combinedTrade.getKey());
            }
        }
    }

    public Transaction tryCompleteTrade(Wallet wallet, TradeDHT dht,
            BlockDownloader blockDownloader) throws Exception {
        System.out.println("\ntryCompleteTrade()\n\tpeerId\t"
                + dht.peerIdToString(dht.getPeerId()) + "\n\tkey\t"
                + listingKey);
        if (isFinished()) {
            throw new Exception("trade already finished");
        }
        NetworkParameters params = wallet.getNetworkParameters();

        List<TradeListingKey> allTradeListingKeys = dht
                .getTradeListingKeys(schema);
        if (!allTradeListingKeys.contains(listingKey)) {
            System.out
                    .println("tryCompleteTrade - our trade listing key has been removed, abort!");
            return null;
        }
        List<TradeListing> allTradeListings = getValidTradeListings(
                allTradeListingKeys, dht);
        if (allTradeListings.size() == 0) {
            System.out
                    .println("tryCompleteTrade - no listings found at all! (where has ours gone?)");
            return null;
        }

        List<FullTrade> tradesToCheck = readCombinedTrades(schema, dht,
                listingKey, allTradeListings);
        addPotentialTrades(tradesToCheck, false, dht, params, blockDownloader);

        addPotentialTrades(makeNewTrades(dht, allTradeListings), true, dht,
                params, blockDownloader);

        PotentialTrade finishedPotentialTrade = null;
        for (PotentialTrade p : potentialTrades) {
            System.out
                    .println("tryCompleteTrade - checking potential combined trade:\n\t"
                            + p.combinedTrade.getKey() + "\n\t" + p.status);

            switch (p.status) {
            case GETBLINDPUBKEY:
                if (p.getBlindingServer().equals(listingKey)) {
                    p.blindingKeyPair = blinding.generateKeyPair();
                    p.blindingPubKey = (RSAKeyParameters) p.blindingKeyPair
                            .getPublic();
                    dht.putBlindingPubKey(p.combinedTrade.getKey(), listingKey,
                            p.blindingPubKey);

                    putBlinded(p, dht, wallet);
                    p.status = Status.BLINDINGSERVER;

                } else {
                    RSAKeyParameters pk = dht.getBlindingPubKey(
                            p.combinedTrade.getKey(), p.getBlindingServer());
                    if (pk != null) {
                        p.blindingPubKey = pk;

                        putBlinded(p, dht, wallet);
                        p.status = Status.GETSIGNEDBLINDED;
                    }
                }
                break;

            case BLINDINGSERVER:
                assert (p.getBlindingServer().equals(listingKey));
                if (p.signBlindedOutputs(dht)) {
                    p.status = Status.GETSIGNEDBLINDED;
                }
                break;

            case GETSIGNEDBLINDED:
                if (p.checkAllBlindedSigned(dht)) {
                    putUnblinded(p, dht);
                    p.status = Status.GETUNBLINDED;
                }
                break;

            case GETUNBLINDED:
                if (p.checkAllUnblinded(dht, params, blockDownloader)) {
                    p.status = Status.PRESIGNED;
                }
                break;

            case PRESIGNED:
                // We do not check for combined trade / combined trade key in
                // dht as anyone could delete it
                if (!checkCombinedTradeMembers(p, allTradeListingKeys)) {
                    System.out
                            .println("tryCompleteTrade - removing potential trade as not all member trade listings are present:\n\t"
                                    + p.combinedTrade.getKey());
                    p.status = Status.INVALID;
                    break;
                }

                if (p.checkTurnToSign(dht, params, blockDownloader)) {
                    p.sign(dht, wallet);
                    p.status = Status.POSTSIGNED;
                }
                break;

            case POSTSIGNED:
                if (p.checkFinished(dht, params, blockDownloader)) {
                    System.out
                            .println("tryCompleteTrade - potential trade is complete");
                    finishedPotentialTrade = p;
                    p.status = Status.FINISHED;
                    break;
                }
                if (!checkCombinedTradeMembers(p, allTradeListingKeys)) {
                    System.out
                            .println("tryCompleteTrade - removing potential trade as not all member trade listings are present:\n\t"
                                    + p.combinedTrade.getKey());
                    p.status = Status.INVALID;
                    break;
                }
                break;

            case INVALID:
                break;

            default:
                throw new Exception("Unhandled potential trade status "
                        + p.status);
            }

            if (finishedPotentialTrade != null) {
                break;
            }
        }

        for (int i = 0; i < potentialTrades.size(); ++i) {
            if (potentialTrades.get(i).status == Status.INVALID) {
                potentialTrades.remove(i);
                --i;
            }
        }
        if (finishedPotentialTrade == null) {
            return null;
        }

        if (!dht.delTradeListingKey(schema, listingKey)) {
            throw new Exception(
                    "Failed to delete our trade listing key after trade completed");
        }
        if (!dht.delTradeListing(listingKey)) {
            throw new Exception(
                    "Failed to delete our trade listing after trade completed");
        }
        for (PotentialTrade p : potentialTrades) {
            p.cleanup(dht);
        }
        finished = finishedPotentialTrade;
        return finished.completedTx;
    }

    public String toString(Wallet wallet) throws Exception {
        String s = "TradeInProgress " + schemaHash + ", clientTradeId #"
                + clientTradeId + "\n";
        s += "Finished = " + isFinished() + "\n";
        s += schema.toString() + "\n";
        s += listing.toString();

        if (finished != null) {
            s += WalletUtils.transactionToString(finished.completedTx, wallet);
        }
        s += "\n\n";
        return s;
    }

}
