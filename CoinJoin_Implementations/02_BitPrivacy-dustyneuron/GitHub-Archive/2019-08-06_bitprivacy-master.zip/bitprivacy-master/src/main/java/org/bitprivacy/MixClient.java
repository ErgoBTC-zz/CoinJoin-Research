package org.bitprivacy;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.bitprivacy.SimpleMix.BlindingValues;

import asg.cliche.Command;
import asg.cliche.Param;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TransactionSchema;
import com.dustyneuron.txmarket.Trader;
import com.dustyneuron.txmarket.bitcoin.WalletUtils;
import com.dustyneuron.txmarket.blinding.Blinding;
import com.dustyneuron.txmarket.dht.TradeDHT;
import com.dustyneuron.txmarket.schema.Trade;
import com.dustyneuron.txmarket.schema.TradeListing;
import com.google.bitcoin.core.Address;
import com.google.bitcoin.core.Transaction;
import com.google.bitcoin.core.Wallet;

public class MixClient implements Runnable {

    private TradeDHT dht;

    private Wallet wallet;
    private BitcoinNetwork bitcoinNetwork;
    private boolean broadcastResults;

    private List<Trader> trades;

    private boolean deterministic;
    private final Blinding blinding;

    private boolean useWorkerThread;
    private Thread workerThread;
    private Date lastPolledTime;

    public MixClient(TradeDHT dht, Wallet w, BitcoinNetwork bn,
            boolean broadcastResults, boolean deterministic, Blinding blinding,
            boolean useWorkerThread) {
        bitcoinNetwork = bn;
        wallet = w;
        this.broadcastResults = broadcastResults;

        trades = new ArrayList<Trader>();
        this.dht = dht;
        this.deterministic = deterministic;
        this.blinding = blinding;
        this.useWorkerThread = useWorkerThread;
    }

    public String peerIdToString() {
        return dht.peerIdToString(dht.getPeerId());
    }

    @Command
    public void connect() throws Exception {
        connect(null);
    }

    @Command
    public void connect(
            @Param(name = "server", description = "Server hostname or IP address") String host)
            throws Exception {

        dht.connect(host, deterministic);

        System.out.println("MixClient.connect(" + host
                + ") finished for peerId "
                + dht.peerIdToString(dht.getPeerId()));

        if (useWorkerThread) {
            workerThread = new Thread(this);
            workerThread.start();
            lastPolledTime = new Date();
        }

        final MixClient mixClient = this;
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                try {
                    mixClient.disconnect();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void run() {
        while (useWorkerThread) {
            Date now = new Date();
            long secs = TimeUnit.MILLISECONDS.toSeconds(now.getTime()
                    - lastPolledTime.getTime());

            if (secs >= 10) {
                lastPolledTime = now;

                try {
                    pollTrades();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Command(description = "Register a new mix on the server")
    public void mix(
            @Param(name = "inputAddress", description = "Address from your wallet. Will use largest unspent output.") String inputAddress,
            @Param(name = "numParties", description = "How many people you'd like to mix with (inc. yourself)") int numParties)
            throws Exception {

        Address input = new Address(wallet.getNetworkParameters(), inputAddress);
        Transaction t = WalletUtils.getLargestSpendableOutput(input, wallet);
        if (t == null) {
            throw new Exception("couldn't find transaction");
        }
        int unspentOutputIdx = WalletUtils.getLargestSpendableOutput(t, input);
        if (unspentOutputIdx < 0) {
            throw new Exception("couldn't find spendable output");
        }

        BigInteger value = t.getOutput(unspentOutputIdx).getValue();

        Trade trade = SimpleMix.createTrade(t, unspentOutputIdx, value, null,
                numParties, BlindingValues.OUTPUTS);
        Trader inProgress = putTradeRequest(trade);
        tryCompleteTrade(inProgress);
    }

    public synchronized Trader putTradeRequest(Trade trade) throws Exception {

        Trader inProgress = new Trader(
                trade.getSchema(),
                new TradeListing(trade.getAllPartiesData(), dht.getPeerId()),
                deterministic, blinding, true);

        trades.add(inProgress);

        inProgress.putTradeListing(dht);

        return inProgress;
    }

    synchronized Transaction tryCompleteTrade(Trader inProgress)
            throws Exception {
        Transaction tx = inProgress.tryCompleteTrade(wallet, dht,
                bitcoinNetwork);
        if (tx != null) {
            if (broadcastResults) {
                bitcoinNetwork.broadcast(tx);
            }
        }
        return tx;
    }

    public synchronized void tryDisrupt(TransactionSchema schema)
            throws Exception {
        Trader.tryDisruptTrade(schema, dht);
    }

    @Command
    public synchronized void pollTrades() throws Exception {
        for (Trader inProgress : trades) {
            if (!inProgress.isFinished()) {
                tryCompleteTrade(inProgress);
            }
        }
    }

    @Command
    public synchronized boolean areAllTradesComplete() {
        for (Trader inProgress : trades) {
            if (!inProgress.isFinished()) {
                return false;
            }
        }
        return true;
    }

    @Command
    public void disconnect() throws Exception {
        useWorkerThread = false;
        dht.disconnect();
    }

    @Command
    public synchronized void listTrades() throws Exception {
        for (Trader t : trades) {
            System.out.println(t.toString(wallet));
        }
    }

    @Command
    public synchronized boolean deleteTrade(
            @Param(name = "tradeId", description = "tradeId as shown by 'list-trades'/'lt'") int tradeId)
            throws Exception {

        Trader found = null;
        for (Trader t : trades) {
            if (t.clientTradeId == tradeId) {
                found = t;
                break;
            }
        }
        if (found != null) {
            trades.remove(found);
            return true;
        }
        return false;
    }
}
