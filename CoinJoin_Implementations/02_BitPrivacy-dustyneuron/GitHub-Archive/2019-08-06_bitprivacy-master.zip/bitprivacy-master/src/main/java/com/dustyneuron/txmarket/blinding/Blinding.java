package com.dustyneuron.txmarket.blinding;

import java.math.BigInteger;

import org.spongycastle.crypto.AsymmetricCipherKeyPair;
import org.spongycastle.crypto.CryptoException;
import org.spongycastle.crypto.params.RSAKeyParameters;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Blinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItemContent;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedBlinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedUnblinded;

public interface Blinding {
    public AsymmetricCipherKeyPair generateKeyPair();

    public BigInteger generateBlindingFactor(RSAKeyParameters publicKey);

    public Blinded blind(DataItem privateData, BigInteger blindingFactor,
            RSAKeyParameters publicKey) throws CryptoException;

    public SignedBlinded sign(Blinded a, AsymmetricCipherKeyPair keyPair);

    public SignedUnblinded unblind(SignedBlinded s, DataItem privateData,
            BigInteger blindingFactor, RSAKeyParameters publicKey);

    public boolean verify(SignedUnblinded s, DataItemContent privateData,
            RSAKeyParameters publicKey);
}
