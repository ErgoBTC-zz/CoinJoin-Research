package com.dustyneuron.txmarket.dht;

public interface SignedUnblindedKey extends TradeKey {

}
