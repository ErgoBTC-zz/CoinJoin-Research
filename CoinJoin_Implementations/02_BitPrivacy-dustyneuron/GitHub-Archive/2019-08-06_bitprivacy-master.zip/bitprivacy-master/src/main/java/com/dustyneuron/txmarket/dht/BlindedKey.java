package com.dustyneuron.txmarket.dht;

public interface BlindedKey extends TradeKey {
}
