package com.dustyneuron.txmarket.schema;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ConstraintFormula;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ConstraintFormula.ForEach;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Element;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Element.ElementType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Expression;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.IOTypeReference;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SinglePartyData;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Variable;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Variable.VariableType;

public class ConstraintsVerifier {
    public static class VariableValues {
        private Map<Variable, BigInteger> values = new HashMap<Variable, BigInteger>();

        public void put(Variable getV, BigInteger b) {
            byte[] getVBytes = getV.toByteArray();
            for (Variable v : values.keySet()) {
                byte[] vBytes = v.toByteArray();
                if (Arrays.equals(vBytes, getVBytes)) {
                    values.put(v, b);
                    return;
                }
            }

            values.put(getV, b);
        }

        public BigInteger get(Variable getV) {
            byte[] getVBytes = getV.toByteArray();
            for (Variable v : values.keySet()) {
                byte[] vBytes = v.toByteArray();
                if (Arrays.equals(vBytes, getVBytes)) {
                    return values.get(v);
                }
            }
            return null;
        }

        public VariableValues copy() {
            VariableValues result = new VariableValues();
            for (Variable v : values.keySet()) {
                result.values.put(v, values.get(v));
            }
            return result;
        }
    }

    private static BigInteger evaluateVariable(
            List<SinglePartyData> allParties, List<DataItem> allData, Variable v)
            throws Exception {

        BigInteger result = new BigInteger("0");

        switch (v.getVariableType()) {
        case SUM_BTCVALUES_TYPE:
            for (DataItem d : allData) {
                if ((d.getHeader().getReference().getRefType() == v
                        .getRefType()) && (d.getHeader().hasValue())) {
                    result = result.add(SchemaUtils.readBigInteger(d
                            .getHeader().getValue()));
                }
            }
            return result;

        case SUM_BTCVALUES_TYPEINDEX:
            for (DataItem d : allData) {
                if ((d.getHeader().getReference().getRefType() == v
                        .getRefType())
                        && (d.getHeader().getReference().getRefIdx() == v
                                .getRefTypeIndex())
                        && (d.getHeader().hasValue())) {
                    result = result.add(SchemaUtils.readBigInteger(d
                            .getHeader().getValue()));
                }
            }
            return result;

        case SUM_TYPE:
            for (DataItem d : allData) {
                if (d.getHeader().getReference().getRefType() == v.getRefType()) {
                    result = result.add(new BigInteger("1"));
                }
            }
            return result;

        case SUM_TYPEINDEX:
            for (DataItem d : allData) {
                if ((d.getHeader().getReference().getRefType() == v
                        .getRefType())
                        && (d.getHeader().getReference().getRefIdx() == v
                                .getRefTypeIndex())) {
                    result = result.add(new BigInteger("1"));
                }
            }
            return result;

        case SUM_PARTYTYPE:
            for (SinglePartyData party : allParties) {
                if (party.getPartyIdx() == v.getPartyTypeIndex()) {
                    result = result.add(new BigInteger("1"));
                }
            }
            return result;

        case FOREACH_BTCVALUE:
            // Silently ignore, will deal with this later
            return result;

        default:
            throw new Exception("unhandled variable type "
                    + v.getVariableType());
        }
    }

    public static VariableValues evaluateVariables(Trade trade)
            throws Exception {
        List<DataItem> allData = new ArrayList<DataItem>();
        for (SinglePartyData s : trade.getAllPartiesData()) {
            allData.addAll(s.getDataList());
        }

        return evaluateVariables(trade.getSchema().getConstraintsList(), trade
                .getSchema().getCompletionRequirementsList(), allData,
                trade.getAllPartiesData());
    }

    // This ignores foreach vars
    public static VariableValues evaluateVariables(
            List<ConstraintFormula> constraints,
            List<ConstraintFormula> completionRequirements,
            List<DataItem> allData, List<SinglePartyData> allParties)
            throws Exception {
        VariableValues variableValues = new VariableValues();

        List<Expression> expressions = new ArrayList<Expression>();
        for (ConstraintFormula constraint : constraints) {
            expressions.addAll(constraint.getLhsList());
            expressions.addAll(constraint.getRhsList());
        }
        for (ConstraintFormula constraint : completionRequirements) {
            expressions.addAll(constraint.getLhsList());
            expressions.addAll(constraint.getRhsList());
        }

        for (Expression e : expressions) {
            if (e.getElement().getElementType() == ElementType.VARIABLE) {
                Variable v = e.getElement().getVariable();
                variableValues.put(v, evaluateVariable(allParties, allData, v));
            }
        }

        return variableValues;
    }

    public enum TradeConstraintsStatus {
        CONSTRAINTS_OK, CONSTRAINTS_BROKEN
    };

    private static BigInteger evaluateConstraintElement(
            VariableValues variableValues, Element element) throws Exception {

        if (element.getElementType() == ElementType.VALUE) {
            return SchemaUtils.readBigInteger(element.getValue());
        }

        BigInteger b = variableValues.get(element.getVariable());
        if (b == null) {
            throw new Exception("couldn't find value for variable " + element);
        }
        return b;
    }

    private static BigInteger evaluateConstraintExpression(
            VariableValues variableValues, Expression expression)
            throws Exception {

        BigInteger value = evaluateConstraintElement(variableValues,
                expression.getElement());

        if (expression.getMinus()) {
            value = new BigInteger("0").subtract(value);
        }
        if (expression.hasMultiplier()) {
            value = value.multiply(SchemaUtils.readBigInteger(expression
                    .getMultiplier()));
        }
        if (expression.hasDivisor()) {
            value = value.divide(SchemaUtils.readBigInteger(expression
                    .getDivisor()));
        }

        return value;
    }

    private static TradeConstraintsStatus evaluateConstraint(
            VariableValues variableValues, ConstraintFormula constraint)
            throws Exception {

        TradeConstraintsStatus status;

        BigInteger lhs = new BigInteger("0");
        for (Expression e : constraint.getLhsList()) {
            lhs = lhs.add(evaluateConstraintExpression(variableValues, e));
        }
        BigInteger rhs = new BigInteger("0");
        for (Expression e : constraint.getRhsList()) {
            rhs = rhs.add(evaluateConstraintExpression(variableValues, e));
        }

        int compareTo = lhs.compareTo(rhs);

        switch (constraint.getComparator()) {
        case EQ:
            if (compareTo == 0) {
                status = TradeConstraintsStatus.CONSTRAINTS_OK;
            } else {
                status = TradeConstraintsStatus.CONSTRAINTS_BROKEN;
            }
            break;
        case NEQ:
            if (compareTo != 0) {
                status = TradeConstraintsStatus.CONSTRAINTS_OK;
            } else {
                status = TradeConstraintsStatus.CONSTRAINTS_BROKEN;
            }
            break;
        case GT:
            if (compareTo == 1) {
                status = TradeConstraintsStatus.CONSTRAINTS_OK;
            } else {
                status = TradeConstraintsStatus.CONSTRAINTS_BROKEN;
            }
            break;
        case LT:
            if (compareTo == -1) {
                status = TradeConstraintsStatus.CONSTRAINTS_OK;
            } else {
                status = TradeConstraintsStatus.CONSTRAINTS_BROKEN;
            }
            break;
        case GTE:
            if ((compareTo == 1) || (compareTo == 0)) {
                status = TradeConstraintsStatus.CONSTRAINTS_OK;
            } else {
                status = TradeConstraintsStatus.CONSTRAINTS_BROKEN;
            }
            break;
        case LTE:
            if ((compareTo == -1) || (compareTo == 0)) {
                status = TradeConstraintsStatus.CONSTRAINTS_OK;
            } else {
                status = TradeConstraintsStatus.CONSTRAINTS_BROKEN;
            }
            break;
        default:
            throw new Exception("unhandled comparator "
                    + constraint.getComparator());
        }
        return status;
    }

    public static TradeConstraintsStatus evaluateConstraints(
            VariableValues variableValues, List<ConstraintFormula> constraints)
            throws Exception {

        for (ConstraintFormula constraint : constraints) {
            if (constraint.getForEach() == ForEach.NONE) {
                TradeConstraintsStatus status = evaluateConstraint(
                        variableValues, constraint);
                if (status == TradeConstraintsStatus.CONSTRAINTS_BROKEN) {
                    return TradeConstraintsStatus.CONSTRAINTS_BROKEN;
                }
            }
        }

        return TradeConstraintsStatus.CONSTRAINTS_OK;
    }

    public static TradeConstraintsStatus evaluateForEachConstraints(
            Trade trade, VariableValues variableValues,
            List<ConstraintFormula> constraints) throws Exception {
        List<DataItem> allData = new ArrayList<DataItem>();
        for (SinglePartyData s : trade.getAllPartiesData()) {
            allData.addAll(s.getDataList());
        }

        return evaluateForEachConstraints(allData, variableValues, constraints);
    }

    public static TradeConstraintsStatus evaluateForEachConstraints(
            List<DataItem> allData, VariableValues variableValues,
            List<ConstraintFormula> constraints) throws Exception {

        for (ConstraintFormula constraint : constraints) {
            if (constraint.getForEach() == ForEach.TYPEREF) {

                IOTypeReference r = constraint.getForEachRef();
                for (DataItem d : allData) {
                    if (SchemaUtils.areIdentical(d.getHeader().getReference(),
                            r) && d.getHeader().hasValue()) {

                        VariableValues variables = variableValues.copy();
                        variables.put(
                                Variable.newBuilder()
                                        .setVariableType(
                                                VariableType.FOREACH_BTCVALUE)
                                        .build(), SchemaUtils.readBigInteger(d
                                        .getHeader().getValue()));

                        TradeConstraintsStatus status = evaluateConstraint(
                                variables, constraint);
                        if (status == TradeConstraintsStatus.CONSTRAINTS_BROKEN) {
                            return TradeConstraintsStatus.CONSTRAINTS_BROKEN;
                        }
                    }
                }

            }
        }

        return TradeConstraintsStatus.CONSTRAINTS_OK;
    }
}
