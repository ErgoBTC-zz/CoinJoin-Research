package com.dustyneuron.txmarket.bitcoin;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.codec.binary.Hex;

import com.google.bitcoin.core.Address;
import com.google.bitcoin.core.Block;
import com.google.bitcoin.core.ECKey;
import com.google.bitcoin.core.Sha256Hash;
import com.google.bitcoin.core.Transaction;
import com.google.bitcoin.core.TransactionInput;
import com.google.bitcoin.core.TransactionOutPoint;
import com.google.bitcoin.core.TransactionOutput;
import com.google.bitcoin.core.Utils;
import com.google.bitcoin.core.Wallet;

public class WalletUtils {

    public static Transaction findTransaction(Block b, Sha256Hash tx) {
        Transaction foundTx = null;
        for (Transaction t : b.getTransactions()) {
            if (t.getHash().equals(tx)) {
                foundTx = t;
            }
        }
        return foundTx;
    }

    public static TransactionOutPoint getConnectedOutPoint(
            TransactionInput input, Wallet wallet) {
        Sha256Hash id = input.getOutpoint().getHash();
        Transaction t = wallet.getTransaction(id);
        if (t == null) {
            System.out.println("tx " + id + " not found in wallet");
            return null;
        }
        return new TransactionOutPoint(wallet.getNetworkParameters(),
                (int) input.getOutpoint().getIndex(), t);
    }

    public static TransactionOutput getConnectedOutput(TransactionInput input,
            Wallet wallet) {
        int idx = (int) input.getOutpoint().getIndex();
        Sha256Hash txId = input.getOutpoint().getHash();
        return wallet.getTransaction(txId).getOutput(idx);
    }

    public static String transactionToString(Transaction tx, Wallet wallet)
            throws Exception {
        if (tx == null) {
            throw new Exception("given a null transaction object");
        }
        String output = tx.toString(null) + "\n";
        BigInteger totalInput = new BigInteger("0");
        boolean inputAmountsUnknown = false;
        int numSigned = 0;
        for (TransactionInput i : tx.getInputs()) {
            if (i.getScriptBytes().length > 0) {
                ++numSigned;
            }
            Sha256Hash prevTxId = i.getOutpoint().getHash();
            Transaction prevTx = wallet.getTransaction(prevTxId);
            if (prevTx == null) {
                inputAmountsUnknown = true;
            } else {
                totalInput = totalInput.add(prevTx.getOutput(
                        (int) i.getOutpoint().getIndex()).getValue());
            }
        }
        BigInteger totalOutput = new BigInteger("0");
        for (TransactionOutput o : tx.getOutputs()) {
            totalOutput = totalOutput.add(o.getValue());
        }
        output += "   Inputs: "
                + Utils.bitcoinValueToFriendlyString(totalInput)
                + (inputAmountsUnknown ? "???" : "")
                + " Outputs: "
                + Utils.bitcoinValueToFriendlyString(totalOutput)
                + " Fee: "
                + Utils.bitcoinValueToFriendlyString(totalInput
                        .subtract(totalOutput))
                + (inputAmountsUnknown ? "???" : "") + "\n";
        output += "   " + Integer.toString(numSigned) + "/"
                + tx.getInputs().size() + " inputs have been signed\n";
        output += "   Confidence " + tx.getConfidence() + "\n";
        output += "   Raw tx hex data\n";
        output += "   " + new String(Hex.encodeHex(tx.bitcoinSerialize()))
                + "\n";
        return output;
    }

    public static int getLargestSpendableOutput(Transaction t, Address a)
            throws Exception {

        BigInteger largestOutputSize = new BigInteger("0");
        int largestOutput = -1;

        for (int i = 0; i < t.getOutputs().size(); ++i) {
            TransactionOutput o = t.getOutput(i);
            if (o.isAvailableForSpending()) {
                if (Arrays.equals(o.getScriptPubKey().getPubKeyHash(), a.getHash160())) {
                    if (o.getValue().compareTo(largestOutputSize) > 0) {
                        largestOutputSize = o.getValue();
                        largestOutput = i;
                    }
                }
            }
        }

        return largestOutput;
    }

    public static Transaction getLargestSpendableOutput(Address a, Wallet wallet)
            throws Exception {
        boolean foundKey = false;
        Iterator<ECKey> it = wallet.getKeys().iterator();
        while (it.hasNext()) {
            ECKey key = it.next();
            byte[] pubKeyHash = key.getPubKeyHash();
            Address address = new Address(wallet.getNetworkParameters(),
                    pubKeyHash);
            if (address.toString().equals(a.toString())) {
                foundKey = true;
                break;
            }
        }
        if (!foundKey) {
            throw new Exception("address not in wallet");
        }

        List<Transaction> transactions = wallet.getTransactionsByTime();
        BigInteger largestOutputSize = new BigInteger("0");
        Transaction largestOutput = null;

        for (Transaction t : transactions) {
            for (TransactionOutput o : t.getOutputs()) {
                if (o.isAvailableForSpending()) {
                    if (Arrays.equals(o.getScriptPubKey().getPubKeyHash(), a.getHash160())) {
                        if (o.getValue().compareTo(largestOutputSize) > 0) {
                            largestOutputSize = o.getValue();
                            largestOutput = t;
                        }
                    }
                }
            }
        }

        return largestOutput;
    }
}
