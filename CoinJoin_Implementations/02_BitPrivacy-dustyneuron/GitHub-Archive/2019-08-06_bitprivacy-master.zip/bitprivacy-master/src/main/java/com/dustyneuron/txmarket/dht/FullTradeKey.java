package com.dustyneuron.txmarket.dht;

public interface FullTradeKey extends TradeKey {
}
