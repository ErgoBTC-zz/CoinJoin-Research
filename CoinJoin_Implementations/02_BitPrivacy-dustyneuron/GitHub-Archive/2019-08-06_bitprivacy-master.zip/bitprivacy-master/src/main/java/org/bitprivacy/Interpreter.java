package org.bitprivacy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import asg.cliche.Command;
import asg.cliche.Shell;
import asg.cliche.ShellDependent;
import asg.cliche.ShellFactory;

import com.dustyneuron.txmarket.blinding.ChaumianBlinding;
import com.dustyneuron.txmarket.blinding.ChaumianBlinding.KeyGen;
import com.dustyneuron.txmarket.dht.TomP2PDHT;
import com.dustyneuron.txmarket.dht.TradeDHT;

public class Interpreter implements ShellDependent {

    WalletMgr walletMgr;
    MixClient mixClient;

    @Command
    public void wallet() throws Exception {
        ShellFactory
                .createSubshell(
                        "wallet",
                        theShell,
                        "Wallet Shell - Type '?l' for available commands, 'exit' to exit shell",
                        walletMgr).commandLoop();
    }

    @Command
    public void client() throws Exception {
        ShellFactory
                .createSubshell(
                        "client",
                        theShell,
                        "Mix Client Shell - Type '?l' for available commands, 'exit' to exit shell",
                        mixClient).commandLoop();
    }

    public Interpreter(String file, boolean broadcastResults) throws Exception {
        TradeDHT dht = new TomP2PDHT();
        walletMgr = new WalletMgr(file);
        mixClient = new MixClient(dht, walletMgr.getWallet(), walletMgr,
                broadcastResults, false, new ChaumianBlinding(KeyGen.SECURE),
                true);

        ShellFactory
                .createConsoleShell(
                        "bitprivacy",
                        "bitprivacy Shell - Type '?l' for available commands, 'exit' to exit shell",
                        this).commandLoop();
    }

    static void usage() {
        System.err.println("Usage: bitprivacy [walletName] [--nobroadcast]\n"
                + "Will load/create wallet from file walletName.wallet\n"
                + "Will load/create svpchain from file walletName.svpchain");
    }

    public static void main(String[] args) throws Exception {
        LogManager logManager = LogManager.getLogManager();
        Enumeration<String> loggerNames = logManager.getLoggerNames();
        while (loggerNames.hasMoreElements()) {
            Logger logger = logManager.getLogger(loggerNames.nextElement());
            logger.setLevel(Level.WARNING);
        }

        List<String> argList = new ArrayList<String>(Arrays.asList(args));
        if (argList.contains("--help") || argList.contains("-h")
                || argList.isEmpty()) {
            usage();
            return;
        }

        String walletFile = argList.get(0);
        boolean broadcastResults = true;

        if (argList.contains("--nobroadcast")) {
            broadcastResults = false;
            System.out.println("--nobroadcast is set");
        }

        new Interpreter(walletFile, broadcastResults);
    }

    private Shell theShell;

    public void cliSetShell(Shell theShell) {
        this.theShell = theShell;
    }
}
