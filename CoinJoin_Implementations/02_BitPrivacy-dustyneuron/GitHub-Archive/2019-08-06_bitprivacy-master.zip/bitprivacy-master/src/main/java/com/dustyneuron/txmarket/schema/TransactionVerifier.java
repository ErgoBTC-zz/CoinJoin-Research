package com.dustyneuron.txmarket.schema;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItemContent;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ReferenceType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SinglePartyData;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TransactionSchema;
import com.dustyneuron.txmarket.bitcoin.BlockDownloader;
import com.dustyneuron.txmarket.bitcoin.WalletUtils;
import com.google.bitcoin.core.AddressFormatException;
import com.google.bitcoin.core.Block;
import com.google.bitcoin.core.NetworkParameters;
import com.google.bitcoin.core.ScriptException;
import com.google.bitcoin.core.Transaction;
import com.google.bitcoin.core.TransactionInput;
import com.google.bitcoin.core.TransactionOutPoint;
import com.google.bitcoin.core.TransactionOutput;
import com.google.bitcoin.core.Wallet;
import com.google.bitcoin.core.WrongNetworkException;

public class TransactionVerifier {

    public static Transaction createTransaction(List<SinglePartyData> allData,
            BlockDownloader blockDownloader, NetworkParameters params)
            throws Exception {

        Transaction transaction = new Transaction(params);
        for (SinglePartyData party : allData) {
            for (DataItem d : party.getDataList()) {
                if (d.getHeader().getReference().getRefType() == ReferenceType.INPUT) {
                    Block b = blockDownloader.downloadBlock(SchemaUtils
                            .extractBlockId(d));
                    Transaction prevTx = WalletUtils.findTransaction(b,
                            SchemaUtils.extractTxId(d));
                    transaction.addInput(prevTx.getOutput(d.getContent()
                            .getOutputIndex()));
                } else {
                    BigInteger outputValue = SchemaUtils.readBigInteger(d
                            .getHeader().getValue());
                    transaction.addOutput(outputValue,
                            SchemaUtils.extractAddress(d, params));
                }
            }
        }
        return transaction;
    }

    private static boolean doesTxMatchPartyData(Transaction signRequest,
            List<SinglePartyData> partyData, Wallet wallet)
            throws ScriptException, WrongNetworkException,
            AddressFormatException {

        List<DataItem> unmatchedInputs = new ArrayList<DataItem>();
        List<DataItem> unmatchedOutputs = new ArrayList<DataItem>();
        for (SinglePartyData party : partyData) {
            for (DataItem d : party.getDataList()) {
                if (d.getHeader().getReference().getRefType() == ReferenceType.INPUT) {
                    unmatchedInputs.add(d);
                } else if (d.getHeader().getReference().getRefType() == ReferenceType.OUTPUT) {
                    unmatchedOutputs.add(d);
                }
            }
        }
        for (TransactionInput input : signRequest.getInputs()) {
            TransactionOutPoint outpoint = WalletUtils.getConnectedOutPoint(
                    input, wallet);
            if (outpoint != null) {
                DataItem matchingItem = null;
                for (DataItem d : unmatchedInputs) {
                    DataItemContent content = d.getContent();
                    if (outpoint.getHash().equals(SchemaUtils.extractTxId(d))
                            && (outpoint.getIndex() == content.getOutputIndex())) {
                        matchingItem = d;
                        break;
                    }
                }
                if (matchingItem != null) {
                    unmatchedInputs.remove(matchingItem);
                }
            }
        }
        if (unmatchedInputs.size() != 0) {
            System.err
                    .println("Transaction didn't contain all the inputs we were going to sign");
            return false;
        }
        for (TransactionOutput output : signRequest.getOutputs()) {
            DataItem matchingItem = null;
            for (DataItem d : unmatchedOutputs) {
                if (Arrays.equals(
                        output.getScriptPubKey().getPubKeyHash(),
                        SchemaUtils.extractAddress(d,
                                wallet.getNetworkParameters()).getHash160())
                    && (output.getValue().compareTo(
                            SchemaUtils.readBigInteger(d.getHeader()
                                    .getValue())) == 0)) {
                    matchingItem = d;
                    break;
                }
            }
            if (matchingItem != null) {
                unmatchedOutputs.remove(matchingItem);
            }
        }
        if (unmatchedOutputs.size() != 0) {
            System.err
                    .println("Transaction didn't contain all our specified outputs");
            return false;
        }

        return true;
    }

    public static boolean isSignRequestValid(Transaction signRequest,
            Trade serverTrade, Trade myTradeRequest, Wallet wallet,
            BlockDownloader blockDownloader) throws Exception {

        if (!SchemaUtils.areIdentical(serverTrade.getSchema(),
                myTradeRequest.getSchema())) {
            System.err
                    .println("Server sent us a trade schema different from our trade schema");
            return false;
        }

        if (!SchemaUtils.isTradeValidAndComplete(serverTrade.getSchema(),
                serverTrade.getAllPartiesData())) {
            System.err
                    .println("Server sent us trade data which isn't a finished trade or doesn't pass the schema");
            return false;
        }

        Transaction unsigned = createTransaction(
                serverTrade.getAllPartiesData(), blockDownloader,
                wallet.getNetworkParameters());

        Transaction signRequestCopy = new Transaction(
                wallet.getNetworkParameters());
        for (TransactionOutput o : signRequest.getOutputs()) {
            signRequestCopy.addOutput(o);
        }
        for (TransactionInput i : signRequest.getInputs()) {
            signRequestCopy.addInput(new TransactionInput(wallet
                    .getNetworkParameters(), signRequestCopy, new byte[0], i
                    .getOutpoint()));
        }

        if (!Arrays.equals(unsigned.bitcoinSerialize(),
                signRequestCopy.bitcoinSerialize())) {
            System.err
                    .println("Transaction didn't match our constructed version based on the server's party data");
            return false;
        }

        // if server also sent us all the party data, we could generate our own
        // transaction trivially,
        // and confirm the only thing that differed was the signing data.

        return doesTxMatchPartyData(signRequest,
                myTradeRequest.getAllPartiesData(), wallet);
    }

    public static Transaction isSignedTxValid(byte[] untrustedData,
            TransactionSchema schema, List<SinglePartyData> expectedData,
            List<TradeListing> expectedSigned, NetworkParameters params,
            BlockDownloader blockDownloader) throws Exception {

        // this is an internal check, not really needed
        if (!SchemaUtils.isTradeValidAndComplete(schema, expectedData)) {
            throw new Exception(
                    "Trade data isn't a finished trade or doesn't pass the schema");
        }

        if (untrustedData.length == 0) {
            throw new Exception(
                    "peer is misbehaving - 'signed' transaction is 0 bytes");
        }
        // System.out.println("Raw tx data:");
        // System.out.println(new String(Hex.encodeHex(untrustedData)));

        Transaction untrusted = new Transaction(params, untrustedData);

        Transaction trusted = createTransaction(expectedData, blockDownloader,
                params);

        Transaction signRequestCopy = new Transaction(params);
        for (TransactionOutput o : untrusted.getOutputs()) {
            signRequestCopy.addOutput(o);
        }
        for (TransactionInput i : untrusted.getInputs()) {
            signRequestCopy.addInput(new TransactionInput(params,
                    signRequestCopy, new byte[0], i.getOutpoint()));
        }

        if (!Arrays.equals(trusted.bitcoinSerialize(),
                signRequestCopy.bitcoinSerialize())) {
            System.err
                    .println("Transaction didn't match our constructed version based on the expected party data");
            return null;
        }

        // now check that the expected people have all signed
        // TODO: how??
        System.out
                .println("isSignedTxValid() TODO: check expected people have actually signed!");

        // return doesTxMatchPartyData(untrusted,
        // myTradeRequest.getAllPartiesDataList(), wallet);

        return untrusted;
    }
}
