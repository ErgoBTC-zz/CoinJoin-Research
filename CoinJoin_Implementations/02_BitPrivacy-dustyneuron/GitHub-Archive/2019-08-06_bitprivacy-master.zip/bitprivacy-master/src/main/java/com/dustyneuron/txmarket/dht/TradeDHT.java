package com.dustyneuron.txmarket.dht;

import java.util.List;

import org.spongycastle.crypto.params.RSAKeyParameters;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Blinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedBlinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedUnblinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TransactionSchema;
import com.dustyneuron.txmarket.schema.FullTrade;
import com.dustyneuron.txmarket.schema.TradeListing;

public interface TradeDHT {

    public void connect(String host, boolean deterministic) throws Exception;
    public void disconnect() throws Exception;

    public byte[] getPeerId();
    public String peerIdToString(byte[] peerId);

    
    public TradeListingKey getKey(TradeListing l);
    public TradeListingKey addTradeListing(TransactionSchema schema,
            TradeListing listing) throws Exception;
    public boolean delTradeListing(TradeListingKey key) throws Exception;
    public TradeListing getTradeListing(TradeListingKey key) throws Exception;
    public List<TradeListingKey> getTradeListingKeys(TransactionSchema schema)
            throws Exception;
    public boolean delTradeListingKey(TransactionSchema schema,
            TradeListingKey key) throws Exception;

    
    public FullTradeKey getKey(FullTrade l);
    public FullTradeKey putCombinedTrade(FullTrade combined) throws Exception;
    public FullTrade getCombinedTrade(FullTradeKey key) throws Exception;
    public boolean delCombinedTrade(FullTradeKey key) throws Exception;
    public List<FullTradeKey> getCombinedTradeKeys(TransactionSchema schema)
            throws Exception;
    public FullTradeKey addCombinedTradeKey(TransactionSchema schema,
            FullTradeKey key) throws Exception;
    public boolean delCombinedTradeKey(TransactionSchema schema,
            FullTradeKey key) throws Exception;

    
    public void putBlindingPubKey(FullTradeKey combinedKey,
            TradeListingKey individualKey, RSAKeyParameters pubKey)
            throws Exception;
    public RSAKeyParameters getBlindingPubKey(FullTradeKey combinedKey,
            TradeListingKey individualKey) throws Exception;

    public BlindedKey getKey(DataItem data, FullTradeKey combinedKey,
            TradeListingKey individualKey, int dataIdx) throws Exception;
    public void putBlinded(BlindedKey key, Blinded blinded) throws Exception;
    public Blinded getBlinded(BlindedKey key) throws Exception;
    public boolean delBlinded(BlindedKey key) throws Exception;

    
    public void putSignedBlinded(BlindedKey key, SignedBlinded signed)
            throws Exception;
    public SignedBlinded getSignedBlinded(BlindedKey key) throws Exception;
    public boolean delSignedBlinded(BlindedKey key) throws Exception;

    
    public SignedUnblindedKey addSignedUnblinded(SignedUnblinded signed,
            FullTradeKey key) throws Exception;
    public List<SignedUnblinded> getSignedUnblindeds(FullTradeKey key)
            throws Exception;
    public boolean delSignedUnblinded(SignedUnblindedKey key) throws Exception;

    
    public void putSignedTx(FullTradeKey combinedKey,
            TradeListingKey individualKey, byte[] txData) throws Exception;
    public byte[] getSignedTx(FullTradeKey combinedKey,
            TradeListingKey individualKey) throws Exception;
    public boolean delSignedTx(FullTradeKey combinedKey,
            TradeListingKey individualKey) throws Exception;
}
