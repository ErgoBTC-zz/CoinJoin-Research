package com.dustyneuron.txmarket;

import static org.junit.Assert.*;

import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Security;

import org.apache.commons.codec.binary.Hex;
import org.junit.Test;

public class InsecureRandomTest {

    public static void initInsecureRandom() {
        final class InsecureRandomProvider extends Provider {
            private static final long serialVersionUID = 1L;

            public InsecureRandomProvider() {
                super("InsecureRandomProvider", 1.0,
                        "Provider for InsecureRandom");
                put("SecureRandom.InsecureRandom",
                        "com.dustyneuron.txmarket.InsecureRandom");
            }
        }
        if (Security.getProvider("InsecureRandomProvider") == null) {
            Provider provider = new InsecureRandomProvider();
            Security.addProvider(provider);
            System.out
                    .println("Registered insecure security provider for testing");
        }
    }

    @Test
    public void gen() throws NoSuchAlgorithmException {
        initInsecureRandom();
        SecureRandom random = SecureRandom.getInstance("InsecureRandom");
        random.setSeed(1);
        byte[] data = new byte[20];
        random.nextBytes(data);
        String s = Hex.encodeHexString(data);
        System.out.println(s);
        assertTrue(s.equals("02030405060708090a0b0c0d0e0f101112131415"));
        random.nextDouble();
        random.nextFloat();
        random.nextInt();
        random.nextBytes(data);
        s = Hex.encodeHexString(data);
        System.out.println(s);
        assertTrue(s.equals("25262728292a2b2c2d2e2f303132333435363738"));
    }
}
