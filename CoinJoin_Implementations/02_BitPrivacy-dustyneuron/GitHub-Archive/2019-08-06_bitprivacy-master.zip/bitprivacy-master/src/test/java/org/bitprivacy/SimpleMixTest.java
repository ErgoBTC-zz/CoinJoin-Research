package org.bitprivacy;

import static org.junit.Assert.*;

import org.bitprivacy.SimpleMix;
import org.junit.Test;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TransactionSchema;
import com.dustyneuron.txmarket.WalletHarness;
import com.dustyneuron.txmarket.bitcoin.WalletUtils;
import com.dustyneuron.txmarket.schema.PartialSigner;
import com.dustyneuron.txmarket.schema.SchemaUtils;
import com.dustyneuron.txmarket.schema.Trade;
import com.dustyneuron.txmarket.schema.TransactionVerifier;
import com.dustyneuron.txmarket.schema.SchemaUtils.TradeCombinationResult;
import com.google.bitcoin.core.Address;
import com.google.bitcoin.core.NetworkParameters;
import com.google.bitcoin.core.Sha256Hash;
import com.google.bitcoin.core.Transaction;
import com.google.bitcoin.core.TransactionInput;
import com.google.bitcoin.core.Utils;

public class SimpleMixTest {
    final static NetworkParameters params = NetworkParameters.testNet();

    @Test
    public void createIdentical() throws Exception {
        TransactionSchema s = SimpleMix.getSchema(Utils.toNanoCoins("1.5"), 7);
        assertNotNull(s);

        Trade t1 = SimpleMix
                .createTrade(
                        "00000000a549cccaf3430859b606a327bc1c5f2a1f531aa9175f7bb1108ba191",
                        "9e2275d18c7853074fba9672db334d64d9cc3ae0428c1790f2839e7b44a6b146",
                        1, Utils.toNanoCoins("1.5"), new Address(params,
                                "mwfRTfPK8BaDN6vPvaT4SGgrj5fVjNBVv8"), 7);
        assertNotNull(t1);
        assertTrue(SchemaUtils.areIdentical(s, t1.getSchema()));
        Trade t2 = SimpleMix
                .createTrade(
                        "00000000a549cccaf3430859b606a327bc1c5f2a1f531aa9175f7bb1108ba191",
                        "9e2275d18c7853074fba9672db334d64d9cc3ae0428c1790f2839e7b44a6b146",
                        1, Utils.toNanoCoins("1.5"), new Address(params,
                                "mwfRTfPK8BaDN6vPvaT4SGgrj5fVjNBVv8"), 7);
        assertNotNull(t2);
        assertTrue(SchemaUtils.areIdentical(s, t2.getSchema()));
    }

    @Test
    public void createDifferent() throws Exception {
        TransactionSchema s = SimpleMix.getSchema(Utils.toNanoCoins("1.5"), 7);
        assertNotNull(s);

        Trade t1 = SimpleMix
                .createTrade(
                        "00000000a549cccaf3430859b606a327bc1c5f2a1f531aa9175f7bb1108ba191",
                        "9e2275d18c7853074fba9672db334d64d9cc3ae0428c1790f2839e7b44a6b146",
                        1, Utils.toNanoCoins("3.77"), new Address(params,
                                "mwfRTfPK8BaDN6vPvaT4SGgrj5fVjNBVv8"), 7);
        assertNotNull(t1);
        assertFalse(SchemaUtils.areIdentical(s, t1.getSchema()));
        Trade t2 = SimpleMix
                .createTrade(
                        "00000000a549cccaf3430859b606a327bc1c5f2a1f531aa9175f7bb1108ba191",
                        "9e2275d18c7853074fba9672db334d64d9cc3ae0428c1790f2839e7b44a6b146",
                        1, Utils.toNanoCoins("2.4"), new Address(params,
                                "mwfRTfPK8BaDN6vPvaT4SGgrj5fVjNBVv8"), 7);
        assertNotNull(t2);
        assertFalse(SchemaUtils.areIdentical(s, t2.getSchema()));
        assertFalse(SchemaUtils.areIdentical(t1.getSchema(), t2.getSchema()));
    }

    @Test
    public void initialListing() throws Exception {
        Trade t = SimpleMix
                .createTrade(
                        "00000000a549cccaf3430859b606a327bc1c5f2a1f531aa9175f7bb1108ba191",
                        "9e2275d18c7853074fba9672db334d64d9cc3ae0428c1790f2839e7b44a6b146",
                        1, Utils.toNanoCoins("1.5"), new Address(params,
                                "mwfRTfPK8BaDN6vPvaT4SGgrj5fVjNBVv8"), 7);
        assertNotNull(t);

        assertTrue(SchemaUtils.isInitialListingValid(t.getSchema(),
                t.getAllPartiesData()));
    }

    @Test
    public void completeTrade() throws Exception {
        Trade t1 = SimpleMix
                .createTrade(
                        "00000000a549cccaf3430859b606a327bc1c5f2a1f531aa9175f7bb1108ba191",
                        "9e2275d18c7853074fba9672db334d64d9cc3ae0428c1790f2839e7b44a6b146",
                        1, Utils.toNanoCoins("1.5"), new Address(params,
                                "mwfRTfPK8BaDN6vPvaT4SGgrj5fVjNBVv8"), 2);
        assertNotNull(t1);
        assertTrue(SchemaUtils.isInitialListingValid(t1.getSchema(),
                t1.getAllPartiesData()));

        Trade t2 = SimpleMix
                .createTrade(
                        "00000000a549cccaf3430859b606a327bc1c5f2a1f531aa9175f7bb1108ba191",
                        "9e2275d18c7853074fba9672db334d64d9cc3ae0428c1790f2839e7b44a6b146",
                        1, Utils.toNanoCoins("1.5"), new Address(params,
                                "mwfRTfPK8BaDN6vPvaT4SGgrj5fVjNBVv8"), 2);
        assertNotNull(t2);
        TradeCombinationResult result = SchemaUtils.tryAddTrade(t1, t2);
        assertNotNull(result);
        assertTrue(result.passedConstraints);
        assertTrue(result.complete);
    }

    @Test
    public void incompleteTrade() throws Exception {
        Trade t1 = SimpleMix
                .createTrade(
                        "00000000a549cccaf3430859b606a327bc1c5f2a1f531aa9175f7bb1108ba191",
                        "9e2275d18c7853074fba9672db334d64d9cc3ae0428c1790f2839e7b44a6b146",
                        1, Utils.toNanoCoins("1.5"), new Address(params,
                                "mwfRTfPK8BaDN6vPvaT4SGgrj5fVjNBVv8"), 3);
        assertNotNull(t1);
        assertTrue(SchemaUtils.isInitialListingValid(t1.getSchema(),
                t1.getAllPartiesData()));

        Trade t2 = SimpleMix
                .createTrade(
                        "00000000a549cccaf3430859b606a327bc1c5f2a1f531aa9175f7bb1108ba191",
                        "9e2275d18c7853074fba9672db334d64d9cc3ae0428c1790f2839e7b44a6b146",
                        1, Utils.toNanoCoins("1.5"), new Address(params,
                                "mwfRTfPK8BaDN6vPvaT4SGgrj5fVjNBVv8"), 3);
        assertNotNull(t2);
        TradeCombinationResult result = SchemaUtils.tryAddTrade(t1, t2);
        assertNotNull(result);
        assertTrue(result.passedConstraints);
        assertTrue(!result.complete);
    }

    @Test
    public void createAndSignTransaction() throws Exception {
        WalletHarness wallet1 = new WalletHarness(params);
        wallet1.importPrivateKey("cVWQR3kHXhfD7FX9ELAwzzjvwsihwekLTxKDH3VbDg7E883v99dD");
        String blockId1 = "0000000071762d682cbe381ce20203303dacc370126bc25b5abb025b47c34a2a";
        String txId1 = "2fdf5e1d94ae9e7d651938ff3902f2d917954a004a949398a8ef270300da64c4";
        wallet1.getWallet().commitTx(
                WalletUtils.findTransaction(
                        wallet1.downloadBlock(new Sha256Hash(blockId1)),
                        new Sha256Hash(txId1)));
        Address to1 = wallet1.generate();
        Trade trade1 = SimpleMix.createTrade(blockId1, txId1, 0,
                Utils.toNanoCoins("0.1"), to1, 2);
        assertNotNull(trade1);
        assertTrue(SchemaUtils.isInitialListingValid(trade1.getSchema(),
                trade1.getAllPartiesData()));

        WalletHarness wallet2 = new WalletHarness(params);
        wallet2.importPrivateKey("cVPw8hYiYg3Kb5duYYNK7oEjT1SFB9J7nAC5fBo8hifHZCKQfEn2");
        String blockId2 = "0000000000a1317058ae8c8730fac13a294fc7bc20f3e098633837fe9f799d9b";
        String txId2 = "718471262dc9f5e4f69f78a00c7e5f09df9782835f5274d85401edf901a098f3";
        wallet2.getWallet().commitTx(
                WalletUtils.findTransaction(
                        wallet2.downloadBlock(new Sha256Hash(blockId2)),
                        new Sha256Hash(txId2)));
        Address to2 = wallet1.generate();
        Trade trade2 = SimpleMix.createTrade(blockId2, txId2, 0,
                Utils.toNanoCoins("0.1"), to2, 2);
        assertNotNull(trade2);
        TradeCombinationResult result = SchemaUtils.tryAddTrade(trade1, trade2);
        assertNotNull(result);
        assertTrue(result.passedConstraints);
        assertTrue(result.complete);

        WalletHarness wallet3 = new WalletHarness(params);
        Transaction unsigned = TransactionVerifier.createTransaction(
                result.trade.getAllPartiesData(), wallet3, params);
        assertNotNull(unsigned);

        if (!TransactionVerifier.isSignRequestValid(unsigned, result.trade,
                trade1, wallet1.getWallet(), wallet1)) {
            System.err.println("sign request is invalid for trade1");
            assertTrue(false);
        }
        unsigned = PartialSigner.doSignRequest(unsigned,
                trade1.getAllPartiesData(), wallet1.getWallet());
        assertNotNull(unsigned);

        if (!TransactionVerifier.isSignRequestValid(unsigned, result.trade,
                trade2, wallet2.getWallet(), wallet2)) {
            System.err.println("sign request is invalid for trade2");
            assertTrue(false);
        }
        unsigned = PartialSigner.doSignRequest(unsigned,
                trade2.getAllPartiesData(), wallet2.getWallet());
        assertNotNull(unsigned);

        for (TransactionInput i : unsigned.getInputs()) {
            assertTrue(i.getScriptBytes().length > 0);
        }

        // Do NOT broadcast tx, else the test won't run again!
    }

}
