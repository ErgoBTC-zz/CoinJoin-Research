package org.bitprivacy;

import java.util.Arrays;

import org.bitprivacy.NetMixTest.BlindingType;
import org.bitprivacy.NetMixTest.DHTType;
import org.bitprivacy.NetMixTest.ExpectedResult;
import org.bitprivacy.SimpleMix.BlindingValues;
import org.junit.Test;

import com.dustyneuron.txmarket.TestPartyData;
import com.dustyneuron.txmarket.TestPartyData.Coin;

public class MixTwoTest {
    @Test
    public void dhtmock() throws Exception {
        NetMixTest
                .harness(TestPartyData.coinValue, Arrays.asList(new TestParty(
                        Coin.ONE), new TestParty(Coin.TWO)), DHTType.MOCK,
                        BlindingValues.NONE, BlindingType.MOCK,
                        ExpectedResult.COMPLETE);
    }

    @Test
    public void dhttom() throws Exception {
        NetMixTest
                .harness(TestPartyData.coinValue, Arrays.asList(new TestParty(
                        Coin.ONE), new TestParty(Coin.TWO)), DHTType.TOMP2P,
                        BlindingValues.NONE, BlindingType.MOCK,
                        ExpectedResult.COMPLETE);
    }

    @Test
    public void dhtmock_blindingfastout() throws Exception {
        NetMixTest
                .harness(TestPartyData.coinValue, Arrays.asList(new TestParty(
                        Coin.ONE), new TestParty(Coin.TWO)), DHTType.MOCK,
                        BlindingValues.OUTPUTS, BlindingType.FAST,
                        ExpectedResult.COMPLETE);
    }

    @Test
    public void dhttom_blindingfastout() throws Exception {
        NetMixTest
                .harness(TestPartyData.coinValue, Arrays.asList(new TestParty(
                        Coin.ONE), new TestParty(Coin.TWO)), DHTType.TOMP2P,
                        BlindingValues.OUTPUTS, BlindingType.FAST,
                        ExpectedResult.COMPLETE);
    }

    @Test
    public void perms() throws Exception {
        DHTType dhtType = DHTType.MOCK;
        BlindingValues blindingValues = BlindingValues.OUTPUTS;
        BlindingType blindingType = BlindingType.FAST;
        ExpectedResult expected = ExpectedResult.COMPLETE;

        NetMixTest
                .harness(TestPartyData.coinValue, Arrays.asList(new TestParty(
                        Coin.ONE), new TestParty(Coin.TWO)), dhtType,
                        blindingValues, blindingType, expected);

        NetMixTest.harness(TestPartyData.coinValue, Arrays.asList(
                new TestParty(Coin.ONE), new TestParty(Coin.THREE)), dhtType,
                blindingValues, blindingType, expected);

        NetMixTest
                .harness(TestPartyData.coinValue, Arrays.asList(new TestParty(
                        Coin.TWO), new TestParty(Coin.ONE)), dhtType,
                        blindingValues, blindingType, expected);

        NetMixTest.harness(TestPartyData.coinValue, Arrays.asList(
                new TestParty(Coin.TWO), new TestParty(Coin.THREE)), dhtType,
                blindingValues, blindingType, expected);

        NetMixTest.harness(TestPartyData.coinValue, Arrays.asList(
                new TestParty(Coin.THREE), new TestParty(Coin.ONE)), dhtType,
                blindingValues, blindingType, expected);

        NetMixTest.harness(TestPartyData.coinValue, Arrays.asList(
                new TestParty(Coin.THREE), new TestParty(Coin.TWO)), dhtType,
                blindingValues, blindingType, expected);
    }
}
