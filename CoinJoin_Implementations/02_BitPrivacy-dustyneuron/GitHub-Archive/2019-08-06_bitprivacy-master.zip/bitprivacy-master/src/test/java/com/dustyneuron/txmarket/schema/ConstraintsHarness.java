package com.dustyneuron.txmarket.schema;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ConstraintFormula;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SinglePartyData;
import com.dustyneuron.txmarket.schema.ConstraintsVerifier;
import com.dustyneuron.txmarket.schema.ConstraintsVerifier.TradeConstraintsStatus;
import com.dustyneuron.txmarket.schema.ConstraintsVerifier.VariableValues;

public class ConstraintsHarness {
    public static TradeConstraintsStatus evaluate(List<DataItem> items,
            List<ConstraintFormula> constraints) throws Exception {
        return _evaluate(items, constraints, false);
    }

    public static TradeConstraintsStatus evaluateForEach(List<DataItem> items,
            List<ConstraintFormula> constraints) throws Exception {
        return _evaluate(items, constraints, true);
    }

    private static TradeConstraintsStatus _evaluate(List<DataItem> items,
            List<ConstraintFormula> constraints, boolean forEach)
            throws Exception {
        SinglePartyData.Builder s = SinglePartyData.newBuilder().setPartyIdx(0);
        for (DataItem d : items) {
            s.addData(d);
        }
        List<SinglePartyData> allParties = new ArrayList<SinglePartyData>();
        allParties.add(s.build());
        VariableValues variableValues = ConstraintsVerifier.evaluateVariables(
                constraints, new ArrayList<ConstraintFormula>(), items,
                allParties);
        assertNotNull(variableValues);

        if (forEach) {
            return ConstraintsVerifier.evaluateForEachConstraints(items,
                    variableValues, constraints);
        }
        return ConstraintsVerifier.evaluateConstraints(variableValues,
                constraints);
    }

}
