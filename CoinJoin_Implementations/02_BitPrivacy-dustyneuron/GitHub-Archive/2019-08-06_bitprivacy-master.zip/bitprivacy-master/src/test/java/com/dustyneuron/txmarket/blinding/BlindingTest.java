package com.dustyneuron.txmarket.blinding;

import static org.junit.Assert.*;

import java.math.BigInteger;

import org.apache.commons.codec.binary.Hex;
import org.junit.Test;
import org.spongycastle.crypto.AsymmetricCipherKeyPair;
import org.spongycastle.crypto.params.RSAKeyParameters;
import org.spongycastle.util.Arrays;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Blinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItemContent;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItemHeader;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.IOTypeReference;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ReferenceType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedBlinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedUnblinded;
import com.dustyneuron.txmarket.blinding.Blinding;
import com.dustyneuron.txmarket.blinding.ChaumianBlinding;
import com.dustyneuron.txmarket.blinding.ChaumianBlinding.KeyGen;
import com.dustyneuron.txmarket.schema.SchemaUtils;
import com.google.protobuf.ByteString;

public class BlindingTest {

    private void simple(Blinding blinding) throws Exception {
        AsymmetricCipherKeyPair keyPair = blinding.generateKeyPair();
        RSAKeyParameters publicKey = (RSAKeyParameters) keyPair.getPublic();

        BigInteger factor = blinding.generateBlindingFactor(publicKey);

        final byte[] rawData = Hex
                .decodeHex("97639573a384bcdeff".toCharArray());

        DataItem privateData = DataItem
                .newBuilder()
                .setHeader(
                        DataItemHeader
                                .newBuilder()
                                .setReference(
                                        IOTypeReference
                                                .newBuilder()
                                                .setRefType(
                                                        ReferenceType.OUTPUT)
                                                .setRefIdx(0))
                                .setValue(
                                        SchemaUtils
                                                .writeBigInteger(new BigInteger(
                                                        "1"))).setBlinded(true)
                                .build())
                .setContent(
                        DataItemContent.newBuilder()
                                .setAddress(ByteString.copyFrom(rawData))
                                .build()).build();

        System.out.println("initial private data:\n" + privateData);
        System.out
                .println("initial raw data:\n" + Hex.encodeHexString(rawData));

        Blinded b = blinding.blind(privateData, factor, publicKey);
        byte[] blindedData = b.getData().toByteArray();

        System.out.println("blindedData:\n" + Hex.encodeHexString(blindedData));

        assertFalse(Arrays.areEqual(rawData, blindedData));

        SignedBlinded s = blinding.sign(b, keyPair);
        byte[] signedData = s.getData().toByteArray();

        System.out.println("signedData:\n" + Hex.encodeHexString(signedData));

        assertFalse(Arrays.areEqual(rawData, signedData));
        assertFalse(Arrays.areEqual(blindedData, signedData));

        SignedUnblinded u = blinding.unblind(s, privateData, factor, publicKey);
        byte[] sigBytes = u.getSignature().toByteArray();

        assertFalse(Arrays.areEqual(rawData, sigBytes));
        assertFalse(Arrays.areEqual(blindedData, sigBytes));
        assertFalse(Arrays.areEqual(signedData, sigBytes));

        assertTrue(blinding.verify(u, privateData.getContent(), publicKey));

        DataItem result = SchemaUtils.getDataItem(u);

        System.out.println("unblinded result:\n" + result);

        assertTrue(SchemaUtils.areIdentical(privateData, result));
    }

    @Test
    public void simpleMock() throws Exception {
        simple(new MockBlinding());
    }

    @Test
    public void simpleChaum() throws Exception {
        simple(new ChaumianBlinding(KeyGen.FASTINSECURE));
    }
}
