package org.bitprivacy;

import java.util.Arrays;

import org.bitprivacy.NetMixTest.AttackerType;
import org.bitprivacy.NetMixTest.BlindingType;
import org.bitprivacy.NetMixTest.DHTType;
import org.bitprivacy.NetMixTest.ExpectedResult;
import org.bitprivacy.SimpleMix.BlindingValues;
import org.junit.Test;

import com.dustyneuron.txmarket.TestPartyData;
import com.dustyneuron.txmarket.TestPartyData.Coin;

public class MixAttackerTest {
    @Test
    public void dhtmock_blindingnone_perm123() throws Exception {
        NetMixTest.harness(TestPartyData.coinValue,
                Arrays.asList(new TestParty(Coin.ONE), new TestParty(Coin.TWO),
                        new TestParty(Coin.THREE), new TestParty(
                                AttackerType.DELETER)), DHTType.MOCK,
                BlindingValues.NONE, BlindingType.MOCK,
                ExpectedResult.INCOMPLETE);
    }

    @Test
    public void dhttom_blindingnone_perm123() throws Exception {
        NetMixTest
                .harness(TestPartyData.coinValue, Arrays.asList(new TestParty(
                        Coin.ONE), new TestParty(Coin.TWO), new TestParty(
                        Coin.THREE), new TestParty(AttackerType.DELETER)),
                        DHTType.TOMP2P, BlindingValues.NONE, BlindingType.MOCK,
                        ExpectedResult.COMPLETE);
    }
}
