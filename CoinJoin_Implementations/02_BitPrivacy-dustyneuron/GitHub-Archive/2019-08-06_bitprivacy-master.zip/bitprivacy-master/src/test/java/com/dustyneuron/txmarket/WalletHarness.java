package com.dustyneuron.txmarket;

import java.io.IOException;
import java.util.Enumeration;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import org.bitprivacy.BitcoinNetwork;

import com.google.bitcoin.core.Address;
import com.google.bitcoin.core.AddressFormatException;
import com.google.bitcoin.core.Block;
import com.google.bitcoin.core.BlockChain;
import com.google.bitcoin.core.DumpedPrivateKey;
import com.google.bitcoin.core.ECKey;
import com.google.bitcoin.core.NetworkParameters;
import com.google.bitcoin.core.Peer;
import com.google.bitcoin.core.PeerGroup;
import com.google.bitcoin.core.Sha256Hash;
import com.google.bitcoin.core.StoredBlock;
import com.google.bitcoin.core.Transaction;
import com.google.bitcoin.core.Wallet;
import com.google.bitcoin.discovery.DnsDiscovery;
import com.google.bitcoin.store.BlockStore;
import com.google.bitcoin.store.BlockStoreException;
import com.google.bitcoin.store.MemoryBlockStore;
import com.google.common.base.Function;
import com.google.common.util.concurrent.ListenableFuture;

public class WalletHarness implements BitcoinNetwork {

    private Wallet wallet;
    private BlockStore blockStore;
    private BlockChain chain;
    private NetworkParameters params;
    private final int maxConnections = 1;

    private HardcodedBlocks hardcodedBlocks;

    public WalletHarness(NetworkParameters p) throws BlockStoreException {
        InsecureRandomTest.initInsecureRandom();

        LogManager logManager = LogManager.getLogManager();
        Enumeration<String> loggerNames = logManager.getLoggerNames();
        while (loggerNames.hasMoreElements()) {
            Logger logger = logManager.getLogger(loggerNames.nextElement());
            logger.setLevel(Level.WARNING);
        }

        params = p;
        wallet = new Wallet(params);
        // wallet.keychain.add(new ECKey());

        blockStore = new MemoryBlockStore(params);

        chain = new BlockChain(params, wallet, blockStore);

        hardcodedBlocks = new HardcodedBlocks();
    }

    public Wallet getWallet() {
        return wallet;
    }

    static final String[] privKeys = {
            "cS23c2Yb9gjxnynYK6iJRr62RdePTkMhFiGhDhqR486aLscJxRgc",
            "cTWzcT1Z4sjUHjNRZjNRSc9RtV6KcpFPWXE61ZZzh4xZhc3H2b6v",
            "cVuVFnwxrhEm4Er7oDzojumxMHcsiotcdqLc24dyaas4aoxoYKW4",
            "cPzJcr3totL67j5K9ZYJXP6GLXqMoRBwPdF4tZxrA3viN99zCsTj",
            "cTs6vE94VNmtigvynFaR55UYCtauVeRC6BhSCvWUKbYo1yFnfYhj",
            "cTdEX5LMFzKpCFLYaHkGgJkSFybi9awTG8GAz9pqEpHL283RYrC6" };
    static int privKeyCounter = 0;

    public Address generate() throws AddressFormatException {
        ECKey key = new DumpedPrivateKey(params, privKeys[(privKeyCounter++)
                % privKeys.length]).getKey();
        wallet.addKey(key);
        byte[] pubKeyHash = key.getPubKeyHash();
        return new Address(params, pubKeyHash);
    }

    public Address importPrivateKey(String privKey)
            throws AddressFormatException {
        ECKey key = new DumpedPrivateKey(params, privKey).getKey();
        wallet.addKey(key);
        byte[] pubKeyHash = key.getPubKeyHash();
        return new Address(params, pubKeyHash);
    }

    private synchronized <R> R doNetworkAction(Function<PeerGroup, R> action)
            throws Exception {

        PeerGroup peerGroup = new PeerGroup(params, chain);
        peerGroup.addPeerDiscovery(new DnsDiscovery(params));
        peerGroup.addWallet(wallet);

        peerGroup.setMaxConnections(maxConnections);
        peerGroup.startAndWait();
        System.out.println("Waiting for " + peerGroup.getMaxConnections()
                + " connections...");
        peerGroup.waitForPeers(peerGroup.getMaxConnections()).get();

        R result = action.apply(peerGroup);

        peerGroup.setMaxConnections(0);
        peerGroup.stopAndWait();

        return result;
    }

    @Override
    public Block downloadBlock(final Sha256Hash b) throws Exception {

        Block foundBlock = null;
        StoredBlock s = blockStore.get(b);
        if (s != null) {
            foundBlock = s.getHeader();
            if (foundBlock != null) {
                System.out.println("downloadBlock(" + b
                        + ") found block header in block store");
            }
        }
        if (foundBlock == null) {
            foundBlock = hardcodedBlocks.downloadBlock(b);
            if (foundBlock != null) {
                System.out.println("downloadBlock(" + b
                        + ") found hardcoded block data");
            }
        }
        if (foundBlock == null) {
            foundBlock = doNetworkAction(new Function<PeerGroup, Block>() {
                @Override
                public Block apply(PeerGroup peerGroup) {
                    for (Peer peer : peerGroup.getConnectedPeers()) {
                        // System.out.println("downloadBlock(" + b +
                        // ") - trying peer " + peer);
                        Block block = null;
                        try {
                            block = peer.getBlock(b).get();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        } catch (ExecutionException e) {
                            throw new RuntimeException(e);
                        }

                        if (block != null) {
                            return block;
                        }
                    }
                    return null;
                }
            });
            if (foundBlock != null) {
                System.out.println("downloadBlock(" + b
                        + ") was downloaded from network");
                /*
                 * System.out.println("block data:"); System.out.println(new
                 * String(Hex.encodeHex(foundBlock.bitcoinSerialize())));
                 * System.out.println("end block data");
                 */
            }
        }
        if (foundBlock == null) {
            throw new Exception("block not found");
        }
        foundBlock.verify();

        // This will only work if foundBlock is the next in one of our chains
        chain.add(foundBlock);

        return foundBlock;
    }

    @Override
    public Transaction broadcast(final Transaction t) throws Exception {
        return doNetworkAction(new Function<PeerGroup, Transaction>() {
            @Override
            public Transaction apply(PeerGroup peerGroup) {
                System.out.println("Syncing...");
                peerGroup.downloadBlockChain();
                ListenableFuture<Transaction> future = peerGroup
                        .broadcastTransaction(t, 1);
                System.out.print("Broadcasting...");
                Transaction result = null;
                try {
                    result = future.get(30, TimeUnit.SECONDS);
                    System.out.println("...done!");
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                } catch (ExecutionException e) {
                    throw new RuntimeException(e);
                } catch (TimeoutException e) {
                    e.printStackTrace();
                }
                return result;
            }
        });
    }
}
