package org.bitprivacy;

import java.util.Arrays;

import org.bitprivacy.NetMixTest.BlindingType;
import org.bitprivacy.NetMixTest.DHTType;
import org.bitprivacy.NetMixTest.ExpectedResult;
import org.bitprivacy.SimpleMix.BlindingValues;
import org.junit.Test;

import com.dustyneuron.txmarket.TestPartyData;
import com.dustyneuron.txmarket.TestPartyData.Coin;

public class MixMultipleTest {
    @Test
    public void dhttom_blindingnone_perm123_count4() throws Exception {
        for (int i = 0; i < 4; ++i) {
            System.out.println("\n\n\n\nMixMultiple take #" + i + "\n");

            NetMixTest.harness(TestPartyData.coinValue, Arrays.asList(
                    new TestParty(Coin.ONE), new TestParty(Coin.TWO),
                    new TestParty(Coin.THREE)), DHTType.TOMP2P,
                    BlindingValues.NONE, BlindingType.MOCK,
                    ExpectedResult.COMPLETE);
        }
    }
}
