package com.dustyneuron.txmarket;

/*
 * import static org.junit.Assert.*;
 * 
 * import java.util.concurrent.TimeUnit;
 * 
 * import org.junit.Test;
 * 
 * import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ServerMessage;
 * import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Trade; import
 * com.dustyneuron.bitprivacy.schemas.SimpleMix; import
 * com.dustyneuron.bitprivacy.schemas.WalletHarness; import
 * com.google.bitcoin.core.Address; import
 * com.google.bitcoin.core.NetworkParameters; import
 * com.google.bitcoin.core.Utils;
 * 
 * public class ProtocolTest { final NetworkParameters params =
 * NetworkParameters.testNet();
 * 
 * Trade uniqueTrade(int i) throws Exception { if (i < 0) { throw new
 * Exception("i must be >=0"); } String val = Integer.toString(i + 1); return
 * SimpleMix.createTrade(
 * "00000000a549cccaf3430859b606a327bc1c5f2a1f531aa9175f7bb1108ba191",
 * "9e2275d18c7853074fba9672db334d64d9cc3ae0428c1790f2839e7b44a6b146", 1,
 * Utils.toNanoCoins(val), new Address(params,
 * "mwfRTfPK8BaDN6vPvaT4SGgrj5fVjNBVv8"), 7);
 * 
 * }
 * 
 * @Test public void messagesOfVaryingSizes() throws Exception {
 * 
 * WalletHarness clientWH = new WalletHarness(params); MixClient client = new
 * MixClient(clientWH.getWallet(), clientWH);
 * 
 * WalletHarness serverWH = new WalletHarness(params); MixServer server = new
 * MixServer(serverWH.getWallet(), serverWH, false);
 * 
 * server.start(); client.connect("localhost", false);
 * 
 * client.listRemoteTrades(); ClientHandler.IncomingMessage incoming =
 * client.testGetMessage(10, TimeUnit.SECONDS); assertNotNull(incoming);
 * assertNotNull(incoming.msg); if (incoming.msg.getType() !=
 * ServerMessage.Type.LIST_TRADES_RESPONSE) { throw new
 * Exception("wrong reply from server"); }
 * 
 * 
 * int numTrades = 100; for (int i = 0; i < numTrades; ++i) {
 * client.tradeRequest(uniqueTrade(i), -1); incoming = client.testGetMessage(10,
 * TimeUnit.SECONDS); assertNotNull(incoming); assertNotNull(incoming.msg); if
 * (incoming.msg.getType() != ServerMessage.Type.NEW_TRADE_LISTED) { throw new
 * Exception("wrong reply from server"); } }
 * 
 * client.listRemoteTrades(); incoming = client.testGetMessage(10,
 * TimeUnit.SECONDS); assertNotNull(incoming); assertNotNull(incoming.msg); if
 * (incoming.msg.getType() != ServerMessage.Type.LIST_TRADES_RESPONSE) { throw
 * new Exception("wrong reply from server"); }
 * 
 * client.disconnect(); server.stop(); } }
 */