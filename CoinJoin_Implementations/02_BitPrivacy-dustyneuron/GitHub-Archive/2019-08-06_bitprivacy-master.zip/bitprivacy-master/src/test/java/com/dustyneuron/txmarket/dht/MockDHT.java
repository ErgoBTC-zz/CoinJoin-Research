package com.dustyneuron.txmarket.dht;

import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;


import org.spongycastle.crypto.params.RSAKeyParameters;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Blinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedBlinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.SignedUnblinded;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.TransactionSchema;
import com.dustyneuron.txmarket.dht.BlindedKey;
import com.dustyneuron.txmarket.dht.FullTradeKey;
import com.dustyneuron.txmarket.dht.SignedUnblindedKey;
import com.dustyneuron.txmarket.dht.TradeDHT;
import com.dustyneuron.txmarket.dht.TradeKey;
import com.dustyneuron.txmarket.dht.TradeListingKey;
import com.dustyneuron.txmarket.schema.FullTrade;
import com.dustyneuron.txmarket.schema.SchemaUtils;
import com.dustyneuron.txmarket.schema.TradeListing;
import com.google.bitcoin.core.Sha256Hash;
import com.google.protobuf.ByteString;
import com.google.protobuf.GeneratedMessage;

public class MockDHT implements TradeDHT {
    MockDHTStore store;
    byte[] peerId;

    public MockDHT(MockDHTStore store, int id) throws NoSuchAlgorithmException {
        this.store = store;
        peerId = Integer.toString(id).getBytes();
    }

    @Override
    public void connect(String host, boolean deterministic) throws Exception {
    }

    @Override
    public void disconnect() throws Exception {
    }

    @Override
    public byte[] getPeerId() {
        return peerId;
    }
    
    @Override
    public String peerIdToString(byte[] peerId) {
        return new String(peerId);
    }

    class SimpleTradeKey implements TradeKey {
        Sha256Hash h;

        @Override
        public int compareTo(TradeKey o) {
            return h.toBigInteger().compareTo(
                    ((SimpleTradeKey) o).h.toBigInteger());
        }

        @Override
        public byte[] toByteArray() {
            return h.getBytes();
        }

        public SimpleTradeKey(Sha256Hash h) {
            this.h = h;
        }

        public SimpleTradeKey(byte[] data) {
            h = new Sha256Hash(data);
        }

        @Override
        public String toString() {
            return h.toString();
        }

        @Override
        public int hashCode() {
            return h.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            return this.compareTo((SimpleTradeKey) obj) == 0;
        }
    }

    class SimpleTradeListingKey extends SimpleTradeKey implements
            TradeListingKey {
        public SimpleTradeListingKey(Sha256Hash h) {
            super(h);
        }

        public SimpleTradeListingKey(byte[] data) {
            super(data);
        }
    }

    class SimpleCombinedTradeKey extends SimpleTradeKey implements FullTradeKey {
        public SimpleCombinedTradeKey(Sha256Hash h) {
            super(h);
        }

        public SimpleCombinedTradeKey(byte[] data) {
            super(data);
        }
    }

    class SimpleBlindedKey extends SimpleTradeKey implements BlindedKey {
        public SimpleBlindedKey(Sha256Hash h) {
            super(h);
        }

        public SimpleBlindedKey(byte[] data) {
            super(data);
        }
    }

    class SimpleSignedUnblindedKey extends SimpleTradeKey implements
            SignedUnblindedKey {
        SignedUnblinded signed;

        public SimpleSignedUnblindedKey(FullTradeKey c) {
            this(c, null);
        }

        public SimpleSignedUnblindedKey(FullTradeKey c, SignedUnblinded signed) {
            super(Sha256Hash.create(((SimpleCombinedTradeKey) c).h.getBytes()));
            this.signed = signed;
        }

        public SimpleSignedUnblindedKey(byte[] data, SignedUnblinded signed) {
            super(data);
            this.signed = signed;
        }
    }

    private <T> void add(Sha256Hash h, T element) {
        @SuppressWarnings("unchecked")
        List<T> list = (List<T>) store.map.get(h);
        if (list == null) {
            list = new ArrayList<T>();
        }
        list.add(element);
        store.map.put(h, list);
    }

    private <T> List<T> getList(Sha256Hash h) {
        @SuppressWarnings("unchecked")
        List<T> list = (List<T>) store.map.get(h);
        if (list == null) {
            return new ArrayList<T>();
        }
        return list;
    }

    private <T extends TradeKey> boolean del(Sha256Hash h, T element) {
        @SuppressWarnings("unchecked")
        List<T> list = (List<T>) store.map.get(h);
        if (list == null) {
            list = new ArrayList<T>();
        }
        int found = -1;
        for (int i = 0; i < list.size(); ++i) {
            if (list.get(i).compareTo(element) == 0) {
                found = i;
                break;
            }
        }
        if (found == -1) {
            return false;
        }
        list.remove(found);
        store.map.put(h, list);
        return true;
    }

    private <T extends GeneratedMessage> boolean del(Sha256Hash h, T element) {
        @SuppressWarnings("unchecked")
        List<T> list = (List<T>) store.map.get(h);
        if (list == null) {
            list = new ArrayList<T>();
        }
        int found = -1;
        for (int i = 0; i < list.size(); ++i) {
            if (SchemaUtils.areIdentical(list.get(i), element)) {
                found = i;
                break;
            }
        }
        if (found == -1) {
            return false;
        }
        list.remove(found);
        store.map.put(h, list);
        return true;
    }

    @Override
    public TradeListingKey getKey(TradeListing l) {
        return new SimpleTradeListingKey(SchemaUtils.getKey(l
                .createBlindListing().getData()));
    }

    @Override
    public TradeListingKey addTradeListing(TransactionSchema schema,
            TradeListing listing) throws Exception {
        if (listing.containsPrivateData()) {
            throw new Exception("listing contains private data");
        }
        SimpleTradeListingKey k = (SimpleTradeListingKey) getKey(listing);
        store.map.put(k.h, listing);
        Sha256Hash schemaKey = SchemaUtils.getKey(schema);
        add(schemaKey, k);
        return k;
    }

    @Override
    public TradeListing getTradeListing(TradeListingKey key) throws Exception {
        return (TradeListing) store.map.get(((SimpleTradeListingKey) key).h);
    }

    @Override
    public boolean delTradeListing(TradeListingKey key) throws Exception {
        return store.map.remove(((SimpleTradeListingKey) key).h) != null;
    }

    @Override
    public List<TradeListingKey> getTradeListingKeys(TransactionSchema schema)
            throws Exception {
        Sha256Hash schemaKey = SchemaUtils.getKey(schema);
        List<SimpleTradeListingKey> list = getList(schemaKey);
        return new ArrayList<TradeListingKey>(list);
    }

    @Override
    public boolean delTradeListingKey(TransactionSchema schema,
            TradeListingKey key) throws Exception {
        SimpleTradeListingKey k = (SimpleTradeListingKey) key;
        Sha256Hash schemaKey = SchemaUtils.getKey(schema);
        return del(schemaKey, k);
    }

    @Override
    public FullTradeKey getKey(FullTrade l) {
        return new SimpleCombinedTradeKey(SchemaUtils.getKey(l
                .getRawGeneratedMessage()));
    }

    @Override
    public FullTradeKey putCombinedTrade(FullTrade combined) throws Exception {
        SimpleCombinedTradeKey k = (SimpleCombinedTradeKey) getKey(combined);
        store.map.put(k.h, combined.getRawGeneratedMessage());
        return k;
    }

    @Override
    public FullTrade getCombinedTrade(FullTradeKey key) throws Exception {
        byte[] bytes = ((GeneratedMessage) store.map
                .get(((SimpleCombinedTradeKey) key).h)).toByteArray();

        List<TradeListingKey> results = new ArrayList<TradeListingKey>();
        TransactionSchemaProtos.FullTradeData c = TransactionSchemaProtos.FullTradeData
                .parseFrom(bytes);
        for (ByteString b : c.getTradeListingKeyList()) {
            results.add(new SimpleTradeListingKey(b.toByteArray()));
        }
        return new FullTrade(this, results);
    }

    @Override
    public boolean delCombinedTrade(FullTradeKey key) throws Exception {
        SimpleCombinedTradeKey k = (SimpleCombinedTradeKey) key;
        return store.map.remove(k.h) != null;
    }

    @Override
    public List<FullTradeKey> getCombinedTradeKeys(TransactionSchema schema)
            throws Exception {
        List<SimpleCombinedTradeKey> list = getList(SchemaUtils
                .getDoubleSchemaKey(schema));
        return new ArrayList<FullTradeKey>(list);
    }

    @Override
    public FullTradeKey addCombinedTradeKey(TransactionSchema schema,
            FullTradeKey key) throws Exception {
        Sha256Hash doubleSchemaKey = SchemaUtils.getDoubleSchemaKey(schema);
        add(doubleSchemaKey, (SimpleCombinedTradeKey) key);
        return key;
    }

    @Override
    public boolean delCombinedTradeKey(TransactionSchema schema,
            FullTradeKey key) throws Exception {
        SimpleCombinedTradeKey k = (SimpleCombinedTradeKey) key;
        Sha256Hash doubleSchemaKey = SchemaUtils.getDoubleSchemaKey(schema);
        return del(doubleSchemaKey, k);
    }

    @Override
    public void putBlindingPubKey(FullTradeKey combinedKey,
            TradeListingKey individualKey, RSAKeyParameters pubKey)
            throws Exception {
        Sha256Hash h = Sha256Hash.create(getSignedTxKey(combinedKey,
                individualKey).getBytes());
        store.map.put(h, pubKey);
    }

    @Override
    public RSAKeyParameters getBlindingPubKey(FullTradeKey combinedKey,
            TradeListingKey individualKey) throws Exception {
        Sha256Hash h = Sha256Hash.create(getSignedTxKey(combinedKey,
                individualKey).getBytes());
        return (RSAKeyParameters) store.map.get(h);
    }

    @Override
    public BlindedKey getKey(DataItem data, FullTradeKey combinedKey,
            TradeListingKey individualKey, int dataIdx) throws Exception {
        BigInteger a = SchemaUtils.getKey(SchemaUtils.createBlindData(data))
                .toBigInteger();
        BigInteger b = ((SimpleCombinedTradeKey) combinedKey).h.toBigInteger();
        BigInteger c = ((SimpleTradeListingKey) individualKey).h.toBigInteger();
        BigInteger d = new BigInteger(Integer.toString(dataIdx));

        Sha256Hash h = Sha256Hash.create(a.add(b).add(c).add(d).toByteArray());
        return new SimpleBlindedKey(h);
    }

    @Override
    public void putBlinded(BlindedKey key, Blinded blinded) throws Exception {
        store.map.put(((SimpleBlindedKey) key).h, blinded);
    }

    @Override
    public Blinded getBlinded(BlindedKey key) throws Exception {
        return (Blinded) store.map.get(((SimpleBlindedKey) key).h);
    }

    @Override
    public boolean delBlinded(BlindedKey key) throws Exception {
        return store.map.remove(((SimpleBlindedKey) key).h) != null;
    }

    @Override
    public void putSignedBlinded(BlindedKey key, SignedBlinded signed)
            throws Exception {
        Sha256Hash h = Sha256Hash.create(((SimpleBlindedKey) key).h.getBytes());
        store.map.put(h, signed);
    }

    @Override
    public SignedBlinded getSignedBlinded(BlindedKey key) throws Exception {
        Sha256Hash h = Sha256Hash.create(((SimpleBlindedKey) key).h.getBytes());
        return (SignedBlinded) store.map.get(h);
    }

    @Override
    public boolean delSignedBlinded(BlindedKey key) throws Exception {
        Sha256Hash h = Sha256Hash.create(((SimpleBlindedKey) key).h.getBytes());
        return store.map.remove(h) != null;
    }

    @Override
    public SignedUnblindedKey addSignedUnblinded(SignedUnblinded signed,
            FullTradeKey combined) throws Exception {
        SimpleSignedUnblindedKey k = new SimpleSignedUnblindedKey(combined,
                signed);
        add(k.h, signed);
        return k;
    }

    @Override
    public List<SignedUnblinded> getSignedUnblindeds(FullTradeKey combined)
            throws Exception {
        SimpleSignedUnblindedKey k = new SimpleSignedUnblindedKey(combined);
        return getList(k.h);
    }

    @Override
    public boolean delSignedUnblinded(SignedUnblindedKey key) throws Exception {
        SimpleSignedUnblindedKey k = (SimpleSignedUnblindedKey) key;
        return del(k.h, k.signed);
    }

    private Sha256Hash getSignedTxKey(FullTradeKey combinedKey,
            TradeListingKey individualKey) {
        BigInteger a = ((SimpleCombinedTradeKey) combinedKey).h.toBigInteger();
        BigInteger b = ((SimpleTradeListingKey) individualKey).h.toBigInteger();
        return Sha256Hash.create(a.add(b).toByteArray());
    }

    @Override
    public void putSignedTx(FullTradeKey combinedKey,
            TradeListingKey individualKey, byte[] txData) throws Exception {
        Sha256Hash k = getSignedTxKey(combinedKey, individualKey);
        store.map.put(k, txData);
    }

    @Override
    public byte[] getSignedTx(FullTradeKey combinedKey,
            TradeListingKey individualKey) throws Exception {
        Sha256Hash k = getSignedTxKey(combinedKey, individualKey);
        return (byte[]) store.map.get(k);
    }

    @Override
    public boolean delSignedTx(FullTradeKey combinedKey,
            TradeListingKey individualKey) throws Exception {
        Sha256Hash k = getSignedTxKey(combinedKey, individualKey);
        store.map.remove(k);
        return true;
    }
}
