package org.bitprivacy;

import static org.junit.Assert.*;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.List;

import org.bitprivacy.SimpleMix.BlindingValues;

import com.dustyneuron.txmarket.InsecureRandomTest;
import com.dustyneuron.txmarket.blinding.Blinding;
import com.dustyneuron.txmarket.blinding.ChaumianBlinding;
import com.dustyneuron.txmarket.blinding.MockBlinding;
import com.dustyneuron.txmarket.blinding.ChaumianBlinding.KeyGen;
import com.dustyneuron.txmarket.dht.MockDHT;
import com.dustyneuron.txmarket.dht.MockDHTStore;
import com.dustyneuron.txmarket.dht.TomP2PDHT;
import com.dustyneuron.txmarket.dht.TradeDHT;
import com.google.bitcoin.core.Utils;

public class NetMixTest {
    public enum BlindingType {
        MOCK, FAST, REAL
    };

    public enum DHTType {
        MOCK, TOMP2P
    };

    public enum AttackerType {
        NONE, DELETER
    };

    public enum ExpectedResult {
        COMPLETE, INCOMPLETE
    };

    public static void harness(String btcValue, List<TestParty> parties,
            DHTType dhtType, BlindingValues blindingValues,
            BlindingType blindingType, ExpectedResult expected)
            throws Exception {
        InsecureRandomTest.initInsecureRandom();
        SecureRandom random = SecureRandom.getInstance("InsecureRandom");
        random.setSeed(1);

        String debugTestCode = dhtType.toString() + "/"
                + blindingValues.toString() + "/" + blindingType.toString()
                + "/" + expected.toString();
        for (TestParty p : parties) {
            debugTestCode += " " + p.toString();
        }

        BigInteger mixAmount = Utils.toNanoCoins(btcValue);

        MockDHTStore mockStore = null;
        if (dhtType == DHTType.MOCK) {
            mockStore = new MockDHTStore();
        }

        Blinding blinding = null;
        switch (blindingType) {
        case MOCK:
            blinding = new MockBlinding();
            break;
        case REAL:
            blinding = new ChaumianBlinding(KeyGen.SECURE);
            break;
        case FAST:
            blinding = new ChaumianBlinding(KeyGen.FASTINSECURE);
            break;
        default:
            throw new Exception(debugTestCode + ": Unhandled blinding type "
                    + blindingType);
        }

        int numTradingParties = parties.size();
        for (int i = 0; i < parties.size(); ++i) {
            if (!parties.get(i).hasTradeData()) {
                --numTradingParties;
            }
        }

        for (int i = 0; i < parties.size(); ++i) {
            TestParty p = parties.get(i);
            TradeDHT dht = null;
            if (dhtType == DHTType.MOCK) {
                dht = new MockDHT(mockStore, i);
            } else {
                dht = new TomP2PDHT();
            }
            p.init(dht, blinding);
            p.createSchema(mixAmount, numTradingParties, blindingValues);
            p.createTrade(mixAmount, numTradingParties, blindingValues);
        }

        Exception exception = null;
        try {
            for (int i = 0; i < parties.size(); ++i) {
                TestParty p = parties.get(i);
                if (i == 0) {
                    p.client.connect();
                } else {
                    p.client.connect("localhost");
                }
                if (p.hasTradeData()) {
                    p.client.putTradeRequest(p.trade);
                }
            }

            int numLoops = 4;
            if (blindingValues != BlindingValues.NONE) {
                numLoops = 8;
            }

            for (int j = 0; j < numLoops; ++j) {
                for (int i = 0; i < parties.size(); ++i) {
                    TestParty p = parties.get(i);
                    if (p.hasTradeData()) {
                        if (!p.client.areAllTradesComplete()) {

                            for (int attackIdx = 0; attackIdx < parties.size(); ++attackIdx) {
                                TestParty a = parties.get(i);
                                if (a.attackerType != AttackerType.NONE) {
                                    a.attack();
                                }
                            }

                            p.client.pollTrades();
                        }
                    }
                }
            }
        } catch (Exception e) {
            exception = e;
        }

        for (int i = 0; i < parties.size(); ++i) {
            TestParty p = parties.get(i);
            p.client.disconnect();
        }

        if (exception != null) {
            throw exception;
        }

        boolean allComplete = true;
        for (int i = 0; i < parties.size(); ++i) {
            TestParty p = parties.get(i);
            boolean complete = true;
            if (p.hasTradeData() && !p.client.areAllTradesComplete()) {
                complete = false;
                allComplete = false;
            }
            if (expected == ExpectedResult.COMPLETE) {
                assertTrue(debugTestCode + ": Peer idx " + i + " peerId "
                        + p.client.peerIdToString()
                        + " has incomplete trade(s)", complete);
            }
        }

        if (expected == ExpectedResult.INCOMPLETE) {
            assertFalse(debugTestCode
                    + ": Expected incomplete but all trades are complete",
                    allComplete);
        }
    }
}
