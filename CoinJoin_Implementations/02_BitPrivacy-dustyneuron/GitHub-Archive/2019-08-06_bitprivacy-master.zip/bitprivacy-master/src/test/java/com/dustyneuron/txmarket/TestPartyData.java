package com.dustyneuron.txmarket;

public class TestPartyData {

    public enum Address {
        ONE, TWO, THREE
    };

    // These addresses were pulled at random from blockexplorer
    public static String getAddress(Address a) {
        switch (a) {
        case ONE:
            return "mx9VnbvbHB6NoQznnRCPCpHb8jXa77pci7";
        case TWO:
            return "mk1139ZXSJtKshr4WkaxqSRsoHbS9JBzAa";
        case THREE:
            return "mgiCdXpSSwR8KBXwdBGo2AmpH28DQWGGJL";
        default:
            return null;
        }
    }

    public enum Coin {
        ONE, TWO, THREE
    };

    static public class CoinData {
        public String privKey;
        public String blockId;
        public String txId;
        public int txOutput;

        public CoinData(String privKey, String blockId, String txId,
                int txOutput) {
            this.privKey = privKey;
            this.blockId = blockId;
            this.txId = txId;
            this.txOutput = txOutput;
        }
    }

    public static final String coinValue = "0.1";

    public static CoinData getCoinData(Coin coin) {
        switch (coin) {
        case ONE:
            return new CoinData(
                    "cVWQR3kHXhfD7FX9ELAwzzjvwsihwekLTxKDH3VbDg7E883v99dD",
                    "0000000071762d682cbe381ce20203303dacc370126bc25b5abb025b47c34a2a",
                    "2fdf5e1d94ae9e7d651938ff3902f2d917954a004a949398a8ef270300da64c4",
                    0);
        case TWO:
            return new CoinData(
                    "cVPw8hYiYg3Kb5duYYNK7oEjT1SFB9J7nAC5fBo8hifHZCKQfEn2",
                    "0000000000a1317058ae8c8730fac13a294fc7bc20f3e098633837fe9f799d9b",
                    "718471262dc9f5e4f69f78a00c7e5f09df9782835f5274d85401edf901a098f3",
                    0);
        case THREE:
            return new CoinData(
                    "cVdahi99xh86rxFPBdQW2zcsAzKxxknd3k2RGKCioj119QqUDLX7",
                    "00000000014475f074027aeacd94e37df59a2e9f27854913b2bca82a3a0bd14f",
                    "9a646db92123ebe8e45456b76b1ad18870f3f0b2b3aaffc2192501f83f016a2c",
                    0);
        default:
            return null;
        }
    }
}
