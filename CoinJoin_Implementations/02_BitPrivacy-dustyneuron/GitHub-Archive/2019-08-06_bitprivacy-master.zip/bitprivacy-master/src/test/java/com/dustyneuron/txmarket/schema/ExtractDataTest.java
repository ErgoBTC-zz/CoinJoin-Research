package com.dustyneuron.txmarket.schema;

import static org.junit.Assert.*;

import org.junit.Test;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItemHeader;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.IOTypeReference;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ReferenceType;
import com.dustyneuron.txmarket.TestPartyData;
import com.dustyneuron.txmarket.TestPartyData.Coin;
import com.dustyneuron.txmarket.TestPartyData.CoinData;
import com.dustyneuron.txmarket.schema.SchemaUtils;
import com.google.bitcoin.core.Address;
import com.google.bitcoin.core.NetworkParameters;
import com.google.bitcoin.core.Sha256Hash;
import com.google.bitcoin.core.Utils;

public class ExtractDataTest {
    @Test
    public void simple() {
        CoinData coinData = TestPartyData.getCoinData(Coin.ONE);

        DataItem d = DataItem
                .newBuilder()
                .setHeader(
                        DataItemHeader
                                .newBuilder()
                                .setReference(
                                        IOTypeReference
                                                .newBuilder()
                                                .setRefType(ReferenceType.INPUT)
                                                .setRefIdx(0).build())
                                .setValue(
                                        SchemaUtils.writeBigInteger(Utils
                                                .toNanoCoins(TestPartyData.coinValue)))
                                .build())
                .setContent(
                        SchemaUtils.createDataItemContent(coinData.blockId,
                                coinData.txId, coinData.txOutput)).build();

        assertTrue(SchemaUtils.extractBlockId(d).equals(
                new Sha256Hash(coinData.blockId)));
        assertTrue(SchemaUtils.extractTxId(d).equals(
                new Sha256Hash(coinData.txId)));
    }

    @Test
    public void simple2() throws Exception {
        String address = TestPartyData.getAddress(TestPartyData.Address.ONE);

        DataItem d = DataItem
                .newBuilder()
                .setHeader(
                        DataItemHeader
                                .newBuilder()
                                .setReference(
                                        IOTypeReference
                                                .newBuilder()
                                                .setRefType(ReferenceType.INPUT)
                                                .setRefIdx(0).build())
                                .setValue(
                                        SchemaUtils.writeBigInteger(Utils
                                                .toNanoCoins(TestPartyData.coinValue)))
                                .build())
                .setContent(
                        SchemaUtils.createDataItemContent(new Address(
                                NetworkParameters.testNet(), address))).build();

        assertTrue(SchemaUtils.extractAddress(d, NetworkParameters.testNet())
                .toString().equals(address));
    }
}
