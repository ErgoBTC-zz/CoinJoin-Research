package com.dustyneuron.txmarket;

import java.security.SecureRandomSpi;

public final class InsecureRandom extends SecureRandomSpi {

    private static final long serialVersionUID = 10101;

    private static byte inc = 1;
    private static Object lock = new Object();

    protected void engineSetSeed(byte[] seed) {
        synchronized (lock) {
            inc = 1;
        }
    }

    protected void engineNextBytes(byte[] bytes) {
        synchronized (lock) {
            for (int i = 0; i < bytes.length; ++i) {
                bytes[i] = ++inc;
            }
        }
    }

    protected byte[] engineGenerateSeed(int numBytes) {
        byte[] bytes = new byte[numBytes];
        engineNextBytes(bytes);
        return bytes;
    }

    public InsecureRandom() {
    }
}
