package com.dustyneuron.txmarket.dht;

import java.util.HashMap;
import java.util.Map;

import com.google.bitcoin.core.Sha256Hash;

public class MockDHTStore {
    public Map<Sha256Hash, Object> map;

    public MockDHTStore() {
        map = new HashMap<Sha256Hash, Object>();
    }

}
