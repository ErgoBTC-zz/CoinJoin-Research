package com.dustyneuron.txmarket.schema;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;

import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ConstraintFormula;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ConstraintFormula.Comparator;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ConstraintFormula.ForEach;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItem;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Element;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Element.ElementType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.DataItemHeader;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Expression;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.IOTypeReference;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.ReferenceType;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Variable;
import com.dustyneuron.bitprivacy.TransactionSchemaProtos.Variable.VariableType;
import com.dustyneuron.txmarket.TestPartyData;
import com.dustyneuron.txmarket.TestPartyData.Coin;
import com.dustyneuron.txmarket.TestPartyData.CoinData;
import com.dustyneuron.txmarket.schema.SchemaUtils;
import com.dustyneuron.txmarket.schema.ConstraintsVerifier.TradeConstraintsStatus;
import com.google.bitcoin.core.Utils;

public class ConstraintsTest {

    @Test
    public void equals1() throws Exception {
        TradeConstraintsStatus status = ConstraintsHarness
                .evaluate(
                        new ArrayList<DataItem>(),
                        Arrays.asList(ConstraintFormula
                                .newBuilder()
                                .setComparator(Comparator.EQ)
                                .addLhs(Expression
                                        .newBuilder()
                                        .setElement(
                                                Element.newBuilder()
                                                        .setElementType(
                                                                ElementType.VALUE)
                                                        .setValue(
                                                                SchemaUtils
                                                                        .writeBigInteger(Utils
                                                                                .toNanoCoins("1.5")))
                                                        .build()).build())
                                .build()));

        assertTrue(status == TradeConstraintsStatus.CONSTRAINTS_BROKEN);
    }

    @Test
    public void equals2() throws Exception {
        TradeConstraintsStatus status = ConstraintsHarness
                .evaluate(
                        new ArrayList<DataItem>(),
                        Arrays.asList(ConstraintFormula
                                .newBuilder()
                                .setComparator(Comparator.EQ)
                                .addLhs(Expression
                                        .newBuilder()
                                        .setElement(
                                                Element.newBuilder()
                                                        .setElementType(
                                                                ElementType.VALUE)
                                                        .setValue(
                                                                SchemaUtils
                                                                        .writeBigInteger(Utils
                                                                                .toNanoCoins("0.00")))
                                                        .build()).build())
                                .build()));

        assertTrue(status == TradeConstraintsStatus.CONSTRAINTS_OK);
    }

    @Test
    public void foreach1() throws Exception {
        CoinData coinData = TestPartyData.getCoinData(Coin.ONE);

        TradeConstraintsStatus status = ConstraintsHarness
                .evaluateForEach(
                        Arrays.asList(DataItem
                                .newBuilder()
                                .setHeader(
                                        DataItemHeader
                                                .newBuilder()
                                                .setReference(
                                                        IOTypeReference
                                                                .newBuilder()
                                                                .setRefType(
                                                                        ReferenceType.INPUT)
                                                                .setRefIdx(0)
                                                                .build())
                                                .setValue(
                                                        SchemaUtils
                                                                .writeBigInteger(Utils
                                                                        .toNanoCoins("1.5")))
                                                .build())
                                .setContent(
                                        SchemaUtils.createDataItemContent(
                                                coinData.blockId,
                                                coinData.txId,
                                                coinData.txOutput)).build()),
                        Arrays.asList(ConstraintFormula
                                .newBuilder()
                                .setForEach(ForEach.TYPEREF)
                                .setForEachRef(
                                        IOTypeReference
                                                .newBuilder()
                                                .setRefType(ReferenceType.INPUT)
                                                .setRefIdx(0).build())
                                .setComparator(Comparator.EQ)
                                .addLhs(Expression
                                        .newBuilder()
                                        .setElement(
                                                Element.newBuilder()
                                                        .setElementType(
                                                                ElementType.VARIABLE)
                                                        .setVariable(
                                                                Variable.newBuilder()
                                                                        .setVariableType(
                                                                                VariableType.FOREACH_BTCVALUE)
                                                                        .build())
                                                        .build()).build())
                                .addRhs(Expression
                                        .newBuilder()
                                        .setElement(
                                                Element.newBuilder()
                                                        .setElementType(
                                                                ElementType.VALUE)
                                                        .setValue(
                                                                SchemaUtils
                                                                        .writeBigInteger(Utils
                                                                                .toNanoCoins("1.5")))
                                                        .build()).build())
                                .build()));

        assertTrue(status == TradeConstraintsStatus.CONSTRAINTS_OK);
    }

    @Test
    public void foreach2() throws Exception {
        CoinData coinData = TestPartyData.getCoinData(Coin.ONE);

        TradeConstraintsStatus status = ConstraintsHarness
                .evaluateForEach(
                        Arrays.asList(DataItem
                                .newBuilder()
                                .setHeader(
                                        DataItemHeader
                                                .newBuilder()
                                                .setReference(
                                                        IOTypeReference
                                                                .newBuilder()
                                                                .setRefType(
                                                                        ReferenceType.INPUT)
                                                                .setRefIdx(0)
                                                                .build())
                                                .setValue(
                                                        SchemaUtils
                                                                .writeBigInteger(Utils
                                                                        .toNanoCoins("2.5")))
                                                .build())
                                .setContent(
                                        SchemaUtils.createDataItemContent(
                                                coinData.blockId,
                                                coinData.txId,
                                                coinData.txOutput)).build()),

                        Arrays.asList(ConstraintFormula
                                .newBuilder()
                                .setForEach(ForEach.TYPEREF)
                                .setForEachRef(
                                        IOTypeReference
                                                .newBuilder()
                                                .setRefType(ReferenceType.INPUT)
                                                .setRefIdx(0).build())
                                .setComparator(Comparator.EQ)
                                .addLhs(Expression
                                        .newBuilder()
                                        .setElement(
                                                Element.newBuilder()
                                                        .setElementType(
                                                                ElementType.VARIABLE)
                                                        .setVariable(
                                                                Variable.newBuilder()
                                                                        .setVariableType(
                                                                                VariableType.FOREACH_BTCVALUE)
                                                                        .build())
                                                        .build()).build())
                                .addRhs(Expression
                                        .newBuilder()
                                        .setElement(
                                                Element.newBuilder()
                                                        .setElementType(
                                                                ElementType.VALUE)
                                                        .setValue(
                                                                SchemaUtils
                                                                        .writeBigInteger(Utils
                                                                                .toNanoCoins("1.5")))
                                                        .build()).build())
                                .build()));

        assertTrue(status == TradeConstraintsStatus.CONSTRAINTS_BROKEN);
    }

    @Test
    public void foreach3() throws Exception {
        CoinData coinData = TestPartyData.getCoinData(Coin.ONE);

        // Tricky: we are using evaluate rather than evaluateForEach
        // which should ignore FOREACH formula
        TradeConstraintsStatus status = ConstraintsHarness
                .evaluate(
                        Arrays.asList(DataItem
                                .newBuilder()
                                .setHeader(
                                        DataItemHeader
                                                .newBuilder()
                                                .setReference(
                                                        IOTypeReference
                                                                .newBuilder()
                                                                .setRefType(
                                                                        ReferenceType.INPUT)
                                                                .setRefIdx(0)
                                                                .build())
                                                .setValue(
                                                        SchemaUtils
                                                                .writeBigInteger(Utils
                                                                        .toNanoCoins("1.5")))
                                                .build())
                                .setContent(
                                        SchemaUtils.createDataItemContent(
                                                coinData.blockId,
                                                coinData.txId,
                                                coinData.txOutput)).build()),

                        Arrays.asList(ConstraintFormula
                                .newBuilder()
                                .setForEach(ForEach.TYPEREF)
                                .setForEachRef(
                                        IOTypeReference
                                                .newBuilder()
                                                .setRefType(ReferenceType.INPUT)
                                                .setRefIdx(0).build())
                                .setComparator(Comparator.EQ)
                                .addLhs(Expression
                                        .newBuilder()
                                        .setElement(
                                                Element.newBuilder()
                                                        .setElementType(
                                                                ElementType.VALUE)
                                                        .setValue(
                                                                SchemaUtils
                                                                        .writeBigInteger(Utils
                                                                                .toNanoCoins("5.5")))
                                                        .build()).build())
                                .addRhs(Expression
                                        .newBuilder()
                                        .setElement(
                                                Element.newBuilder()
                                                        .setElementType(
                                                                ElementType.VALUE)
                                                        .setValue(
                                                                SchemaUtils
                                                                        .writeBigInteger(Utils
                                                                                .toNanoCoins("9.5")))
                                                        .build()).build())
                                .build()));

        assertTrue(status == TradeConstraintsStatus.CONSTRAINTS_OK);
    }
}
