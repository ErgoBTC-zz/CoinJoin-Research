/**
 * @fileOverview Mapping coordinating with the app's database.
 */
'use strict';

define(['model/pockets'], function(Pockets) {
  
});
