'use strict';

define(['backend/services/lobby'], function(LobbyService) {
});
