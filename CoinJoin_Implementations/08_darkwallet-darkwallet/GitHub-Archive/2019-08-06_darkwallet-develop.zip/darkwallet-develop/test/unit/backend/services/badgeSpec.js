'use strict';

define(['backend/services/badge'], function(BadgeService) {
});
