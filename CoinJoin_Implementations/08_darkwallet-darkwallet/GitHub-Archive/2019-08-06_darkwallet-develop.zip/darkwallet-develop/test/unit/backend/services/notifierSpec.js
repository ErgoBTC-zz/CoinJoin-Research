/*
 * @fileOverview Background service running for the wallet
 */
'use strict';

define(['backend/services/notifier'], function(NotifierService) {
});

