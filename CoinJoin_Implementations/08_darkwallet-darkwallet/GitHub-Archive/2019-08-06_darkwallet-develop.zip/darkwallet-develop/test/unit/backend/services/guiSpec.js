'use strict';

define(['backend/services/gui'], function(GuiService) {
});
