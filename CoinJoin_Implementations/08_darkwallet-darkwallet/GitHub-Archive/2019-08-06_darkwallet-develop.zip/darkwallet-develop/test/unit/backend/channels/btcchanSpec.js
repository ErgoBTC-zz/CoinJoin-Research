'use strict';

define(['backend/channels/btcchan'], function (Channel) {
});
