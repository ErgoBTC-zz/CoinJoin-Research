'use strict';

define(['backend/services/obelisk'], function(ObeliskService) {
});