'use strict';

define(['backend/services/ctxmenus'], function(CtxMenusService) {
});
