'use strict';

define(['backend/channels/catchan'], function (Channel) {
});
