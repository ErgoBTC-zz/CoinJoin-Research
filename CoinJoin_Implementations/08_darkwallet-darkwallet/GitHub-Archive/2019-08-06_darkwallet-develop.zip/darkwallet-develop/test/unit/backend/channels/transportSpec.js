'use strict';

define(['backend/channels/transport'], function (Transport) {
});
