'use strict';

define(['frontend/controllers/new_fund'], function (NewFundCtrl) {
});
