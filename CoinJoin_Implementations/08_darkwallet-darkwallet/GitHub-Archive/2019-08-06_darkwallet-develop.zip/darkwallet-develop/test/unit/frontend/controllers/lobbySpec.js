'use strict';

define(['frontend/controllers/lobby'], function (LobbyCtrl) {
});
