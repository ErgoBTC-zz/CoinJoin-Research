'use strict';

define(['frontend/controllers/settings'], function (Settings) {
});
