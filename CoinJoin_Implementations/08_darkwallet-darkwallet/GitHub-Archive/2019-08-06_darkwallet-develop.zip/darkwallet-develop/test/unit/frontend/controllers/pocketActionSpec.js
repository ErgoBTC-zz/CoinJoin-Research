'use strict';

define(['frontend/controllers/pocketaction'], function (PocketActionCtrl) {
});
