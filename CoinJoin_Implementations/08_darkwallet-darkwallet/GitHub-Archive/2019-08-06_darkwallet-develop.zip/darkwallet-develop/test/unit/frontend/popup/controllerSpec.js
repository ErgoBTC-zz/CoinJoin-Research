/**
 * @fileOverview Popup classes.
 */
'use strict';

define(['frontend/popup/controller'], function (PopupCtrl) {
});
