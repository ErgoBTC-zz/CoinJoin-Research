'use strict';

define(['frontend/directives/identicon'], function (Identicon) {
});
