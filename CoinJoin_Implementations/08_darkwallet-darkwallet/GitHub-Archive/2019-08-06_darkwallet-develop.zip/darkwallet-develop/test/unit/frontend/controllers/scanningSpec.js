/**
 * @fileOverview ScanningCtrl angular controller
 */
'use strict';

define(['frontend/controllers/scanning'], function (ScanningCtrl) {
});
