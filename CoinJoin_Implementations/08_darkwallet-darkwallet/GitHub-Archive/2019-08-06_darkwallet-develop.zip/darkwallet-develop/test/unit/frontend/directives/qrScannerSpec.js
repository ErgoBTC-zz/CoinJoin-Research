'use strict';

define(['frontend/directives/qr-scanner'], function (QrScanner) {
});
