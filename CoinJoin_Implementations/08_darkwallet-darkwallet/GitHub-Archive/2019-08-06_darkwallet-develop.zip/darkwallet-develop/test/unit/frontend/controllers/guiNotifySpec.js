'use strict';

define(['frontend/controllers/gui_notify'], function (GuiNotifyCtrl) {
});
