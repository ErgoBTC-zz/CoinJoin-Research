'use strict';

define(['frontend/providers/wallet'], function(WalletService) {
});
