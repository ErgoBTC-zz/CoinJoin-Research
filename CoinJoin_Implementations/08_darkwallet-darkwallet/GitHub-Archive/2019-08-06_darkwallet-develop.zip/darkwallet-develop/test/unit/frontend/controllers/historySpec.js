/**
 * @fileOverview HistoryCtrl angular controller
 */
'use strict';

define(['frontend/controllers/history'], function (HistoryCtrl) {
});
