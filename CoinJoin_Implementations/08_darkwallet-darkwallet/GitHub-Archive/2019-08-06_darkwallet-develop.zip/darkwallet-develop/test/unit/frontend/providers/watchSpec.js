'use strict';

define(['frontend/providers/watch'], function(WatchService) {
});
