'use strict';

define(['frontend/controllers/rcv_stealth'], function (StealthCtrl) {
});
