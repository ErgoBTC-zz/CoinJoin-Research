'use strict';

define(['frontend/controllers/notifications'], function (NotificationsCtrl) {
});
