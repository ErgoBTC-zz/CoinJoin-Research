'use strict';

define(['frontend/directives/slider'], function (Slider) {
});
