'use strict';

define(['frontend/controllers/exporting'], function (Exporting) {
});
