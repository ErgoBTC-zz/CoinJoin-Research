'use strict';

define(['frontend/filters/currency'], function (Currency) {
});
