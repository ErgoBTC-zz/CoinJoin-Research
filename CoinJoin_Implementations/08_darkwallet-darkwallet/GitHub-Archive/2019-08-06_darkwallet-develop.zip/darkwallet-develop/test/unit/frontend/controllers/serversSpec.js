/**
 * @fileOverview ServersCtrl angular controller
 */
'use strict';

define(['frontend/controllers/servers'], function (ServersCtrl) {
});
