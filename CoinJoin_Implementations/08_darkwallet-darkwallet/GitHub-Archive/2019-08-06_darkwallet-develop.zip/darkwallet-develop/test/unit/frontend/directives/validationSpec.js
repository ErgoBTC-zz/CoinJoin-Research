'use strict';

define(['frontend/directives/validation'], function (Validation) {
});
