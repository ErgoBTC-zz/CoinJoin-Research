'use strict';

define(['frontend/directives/face'], function (Face) {
});
