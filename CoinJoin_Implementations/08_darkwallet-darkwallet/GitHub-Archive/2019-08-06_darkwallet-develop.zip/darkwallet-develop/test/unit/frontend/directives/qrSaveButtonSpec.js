'use strict';

define(['frontend/directives/qr-save-button'], function (QrSaveButton) {
});
