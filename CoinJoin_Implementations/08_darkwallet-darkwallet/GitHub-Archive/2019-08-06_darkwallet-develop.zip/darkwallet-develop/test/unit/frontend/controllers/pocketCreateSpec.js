'use strict';

define(['frontend/controllers/pocketcreate'], function (PocketCreateCtrl) {
});
