/**
 * @fileOverview Wallet classes.
 */
'use strict';

define(['frontend/controllers/wallet'], function (WalletCtrl) {
});
