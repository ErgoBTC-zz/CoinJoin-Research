'use strict';

define(['frontend/controllers/identities'], function (IdentitiesCtrl) {
});
