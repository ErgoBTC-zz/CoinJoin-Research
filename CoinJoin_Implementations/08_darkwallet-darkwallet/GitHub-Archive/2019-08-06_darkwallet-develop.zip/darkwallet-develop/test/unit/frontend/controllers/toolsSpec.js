'use strict';

define(['frontend/controllers/tools'], function (ToolsCtrl) {
});
