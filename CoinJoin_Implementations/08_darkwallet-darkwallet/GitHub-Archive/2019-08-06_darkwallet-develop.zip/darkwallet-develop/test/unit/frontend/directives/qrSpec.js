'use strict';

define(['frontend/directives/qr'], function (Qr) {
});
