/**
 * @fileOverview ContactsCtrl angular controller
 */
'use strict';

define(['frontend/controllers/fund'], function (FundCtrl) {
});
