'use strict';

define(['frontend/filters/formats'], function (Formats) {
});
