'use strict';

define(['frontend/providers/broadcast'], function(BroadcastService) {
});
