'use strict';

define(['frontend/directives/safebrowser'], function (SafeBrowser) {
});
