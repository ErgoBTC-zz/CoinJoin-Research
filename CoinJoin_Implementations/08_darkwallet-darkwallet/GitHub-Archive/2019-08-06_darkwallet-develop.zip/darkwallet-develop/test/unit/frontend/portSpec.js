'use strict';

define(['frontend/port'], function (Port) {
});
