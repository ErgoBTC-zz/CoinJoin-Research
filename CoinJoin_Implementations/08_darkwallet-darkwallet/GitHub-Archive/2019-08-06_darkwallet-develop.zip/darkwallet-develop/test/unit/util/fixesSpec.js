/*
 * @fileOverview Fixes for frightening things in other libraries
 */
'use strict';

define(['sjcl'], function(sjcl) {
});
