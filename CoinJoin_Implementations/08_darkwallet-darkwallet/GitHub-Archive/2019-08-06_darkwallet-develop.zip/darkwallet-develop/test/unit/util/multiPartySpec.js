'use strict';

define(['util/multiParty'], function(MultiParty) {
});
