'use strict';

define(function() {
  return {
    config: function() {
      
    }
  };
});