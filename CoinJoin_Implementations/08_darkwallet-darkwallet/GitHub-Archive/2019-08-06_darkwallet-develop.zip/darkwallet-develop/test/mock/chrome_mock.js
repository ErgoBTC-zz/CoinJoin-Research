'use strict';

define(function() {
  return {};
});
