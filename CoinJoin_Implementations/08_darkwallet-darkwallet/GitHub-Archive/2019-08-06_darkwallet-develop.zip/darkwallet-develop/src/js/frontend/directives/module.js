/** attach directives to this module 
 **/
'use strict';

define(['angular'], function (ng) {
    'use strict';
    return ng.module('DarkWallet.directives', []);
});
