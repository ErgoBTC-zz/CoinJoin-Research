/** attach filters to this module 
 **/
'use strict';

define(['angular'], function (ng) {
    return ng.module('DarkWallet.filters', []);
});
