/** attach filters to this module 
 **/
'use strict';

define([
    './currency',
    './formats',
    './i18n'
], function () {});
