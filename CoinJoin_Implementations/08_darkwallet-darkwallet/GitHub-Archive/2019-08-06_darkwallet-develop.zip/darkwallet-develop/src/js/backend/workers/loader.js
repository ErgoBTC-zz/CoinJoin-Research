
importScripts('/src/vendors/requirejs/require.js');
importScripts('/src/js/backend/loader.js');

requirejs.config({
  baseUrl: '/src/js'
});
 
