package cmd

import (
	"fmt"
	"os"

	homedir "github.com/mitchellh/go-homedir"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

var cfgFile string

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "bustapay",
	Short: "A reference implementation of bustapay",
	Long:  `This functions as a wrapper around bitcoin core using rpc commands`,
}

// Execute adds all child commands to the root command and sets flags appropriately.
// This is called by main.main(). It only needs to happen once to the rootCmd.
func Execute() {
	if err := rootCmd.Execute(); err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
}

func init() {
	cobra.OnInitialize(initConfig)

	rootCmd.PersistentFlags().StringVar(&cfgFile, "config", "", "config file (default is $HOME/.bustapay/config.yaml)")

	rootCmd.PersistentFlags().BoolP("verbose", "v", false, "Enable verbose printing")
	viper.BindPFlag("verbose", rootCmd.PersistentFlags().Lookup("verbose"))


	rootCmd.PersistentFlags().String("bitcoind_host", "localhost", "bitcoind host to connect to")
	viper.BindPFlag("bitcoind_host", rootCmd.PersistentFlags().Lookup("bitcoind_host"))

	rootCmd.PersistentFlags().String("bitcoind_port", "8332", "bitcoind port to connect to")
	viper.BindPFlag("bitcoind_port", rootCmd.PersistentFlags().Lookup("bitcoind_port"))

	rootCmd.PersistentFlags().String("bitcoind_user", "", "bitcoind user to connect to")
	viper.BindPFlag("bitcoind_user", rootCmd.PersistentFlags().Lookup("bitcoind_user"))

	rootCmd.PersistentFlags().String("bitcoind_pass", "", "bitcoind pass to connect to")
	viper.BindPFlag("bitcoind_pass", rootCmd.PersistentFlags().Lookup("bitcoind_pass"))
}

// initConfig reads in config file and ENV variables if set.
func initConfig() {
	if cfgFile != "" {
		// Use config file from the flag.
		viper.SetConfigFile(cfgFile)
	} else {
		// Find home directory.
		home, err := homedir.Dir()
		if err != nil {
			fmt.Println(err)
			os.Exit(1)
		}

		viper.AddConfigPath(home + "/.bustapay")
		viper.SetConfigName("config")
	}

	viper.AutomaticEnv() // read in environment variables that match

	// If a config file is found, read it in.
	if err := viper.ReadInConfig(); err == nil {
		if viper.GetBool("verbose") {
			fmt.Println("Using config file:", viper.ConfigFileUsed())
		}
	}

	if viper.GetBool("verbose") {
		fmt.Println("Verbose mode enabled!")
	}
}
