package main

import "github.com/rhavar/bustapay/cmd"

func main() {
	cmd.Execute()
}
