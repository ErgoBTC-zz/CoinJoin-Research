The dojo can be found in the [documentation](https://docs.wasabiwallet.io/building-wasabi/Dojo.html).
