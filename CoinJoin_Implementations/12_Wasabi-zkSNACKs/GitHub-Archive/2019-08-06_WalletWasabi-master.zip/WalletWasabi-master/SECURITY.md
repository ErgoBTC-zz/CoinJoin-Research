# Security Policy

Feel free to report a vulnerability as a GitHub issue only if the vulnerability you found does not compromise users' privacy or security.  
If it does, then pay great care to responsible disclosure. Send an email to adam.ficsor73@gmail.com, preferably using PGP encryption: https://github.com/zkSNACKs/WalletWasabi/blob/master/PGP.txt
