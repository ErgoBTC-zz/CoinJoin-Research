namespace WalletWasabi.Models
{
	public enum TorStatus
	{
		NotRunning,
		TurnedOff,
		Running
	}
}
