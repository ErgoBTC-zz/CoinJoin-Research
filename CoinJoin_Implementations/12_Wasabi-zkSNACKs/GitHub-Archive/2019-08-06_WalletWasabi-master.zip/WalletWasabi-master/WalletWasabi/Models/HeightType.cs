using System;
using System.Collections.Generic;
using System.Text;

namespace WalletWasabi.Models
{
	public enum HeightType
	{
		Chain,
		Mempool,
		Unknown
	}
}
