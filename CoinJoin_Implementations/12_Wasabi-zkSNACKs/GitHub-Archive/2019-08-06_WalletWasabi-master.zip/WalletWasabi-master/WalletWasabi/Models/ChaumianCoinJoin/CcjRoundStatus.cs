namespace WalletWasabi.Models.ChaumianCoinJoin
{
	public enum CcjRoundStatus
	{
		NotStarted,
		Running,
		Succeded,
		Aborted
	}
}
