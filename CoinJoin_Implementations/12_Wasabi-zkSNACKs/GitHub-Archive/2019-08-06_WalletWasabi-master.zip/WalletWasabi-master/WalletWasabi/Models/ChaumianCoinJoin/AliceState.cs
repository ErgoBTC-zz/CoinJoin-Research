namespace WalletWasabi.Models.ChaumianCoinJoin
{
	public enum AliceState
	{
		InputsRegistered,
		ConnectionConfirmed,
		SignedCoinJoin
	}
}
