namespace WalletWasabi.Models.ChaumianCoinJoin
{
	public enum CcjRoundPhase
	{
		InputRegistration,
		ConnectionConfirmation,
		OutputRegistration,
		Signing
	}
}
