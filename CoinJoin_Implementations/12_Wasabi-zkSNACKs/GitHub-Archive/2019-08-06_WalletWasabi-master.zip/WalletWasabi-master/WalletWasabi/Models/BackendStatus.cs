namespace WalletWasabi.Models
{
	public enum BackendStatus
	{
		NotConnected,
		Connected
	}
}
