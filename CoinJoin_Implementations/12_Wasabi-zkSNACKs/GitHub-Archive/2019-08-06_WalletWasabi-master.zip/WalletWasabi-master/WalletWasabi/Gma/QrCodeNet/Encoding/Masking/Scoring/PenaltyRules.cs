namespace Gma.QrCodeNet.Encoding.Masking.Scoring
{
	public enum PenaltyRules
	{
		Rule01 = 1,
		Rule02 = 2,
		Rule03 = 3,
		Rule04 = 4
	}
}
