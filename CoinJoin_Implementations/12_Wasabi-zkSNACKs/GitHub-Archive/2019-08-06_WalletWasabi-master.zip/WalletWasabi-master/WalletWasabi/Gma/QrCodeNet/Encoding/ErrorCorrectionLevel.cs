namespace Gma.QrCodeNet.Encoding
{
	public enum ErrorCorrectionLevel
	{
		L,
		M,
		Q,
		H
	}
}
