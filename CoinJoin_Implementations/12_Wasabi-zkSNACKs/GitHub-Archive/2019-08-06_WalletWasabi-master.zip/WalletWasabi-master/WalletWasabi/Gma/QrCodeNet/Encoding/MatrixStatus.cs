namespace Gma.QrCodeNet.Encoding
{
	public enum MatrixStatus
	{
		None,
		NoMask,
		Data
	}
}
