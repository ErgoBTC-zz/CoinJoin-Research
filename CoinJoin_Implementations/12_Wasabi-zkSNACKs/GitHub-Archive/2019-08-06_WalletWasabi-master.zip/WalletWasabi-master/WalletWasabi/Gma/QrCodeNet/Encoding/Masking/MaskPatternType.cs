namespace Gma.QrCodeNet.Encoding.Masking
{
	public enum MaskPatternType
	{
		Type0 = 0,
		Type1 = 1,
		Type2 = 2,
		Type3 = 3,
		Type4 = 4,
		Type5 = 5,
		Type6 = 6,
		Type7 = 7
	}
}
