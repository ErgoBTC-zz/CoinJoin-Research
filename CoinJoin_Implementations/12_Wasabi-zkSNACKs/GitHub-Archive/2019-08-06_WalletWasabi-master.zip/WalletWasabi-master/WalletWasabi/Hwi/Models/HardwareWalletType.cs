using System;
using System.Collections.Generic;
using System.Text;

namespace WalletWasabi.Hwi.Models
{
	public enum HardwareWalletType
	{
		Trezor,
		Ledger,
		KeepKey,
		DigitalBitBox,
		Coldcard
	}
}
