using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("WalletWasabi.Tests")]
