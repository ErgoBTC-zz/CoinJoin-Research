namespace WalletWasabi.Http
{
	public static class Constants
	{
		public const string SP = " ";
		public const string HTAB = "\t";
		public const string CR = "\r";
		public const string LF = "\n";
		public const string CRLF = "\r\n";
	}
}
