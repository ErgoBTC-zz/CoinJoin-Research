namespace WalletWasabi.KeyManagement
{
	public enum KeyState
	{
		Clean,
		Locked,
		Used
	}
}
