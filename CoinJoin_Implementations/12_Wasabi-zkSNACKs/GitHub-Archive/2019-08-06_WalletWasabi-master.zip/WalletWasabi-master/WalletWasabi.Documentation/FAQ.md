The frequently asked questions can be found in the [documentation](https://docs.wasabiwallet.io/FAQ).
