The step-by-step guide of the password finder is in the [documentation](https://docs.wasabiwallet.io/using-wasabi/PasswordFinder.html).
