The contribution game can be found in the [documenation](https://docs.wasabiwallet.io/building-wasabi/ContributionGame.html).
