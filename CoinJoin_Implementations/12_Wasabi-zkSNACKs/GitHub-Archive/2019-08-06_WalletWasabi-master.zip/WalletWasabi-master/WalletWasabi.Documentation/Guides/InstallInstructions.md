The step-by-step PGP verification and package installation guide can be found in the [documentation](https://docs.wasabiwallet.io/using-wasabi/InstallPackage.html).
