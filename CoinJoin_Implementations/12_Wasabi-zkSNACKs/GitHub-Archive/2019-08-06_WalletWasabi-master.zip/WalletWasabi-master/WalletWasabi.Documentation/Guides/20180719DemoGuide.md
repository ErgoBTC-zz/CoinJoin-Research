The demo guide can be found in the [documentation](https://docs.wasabiwallet.io/building-wasabi/DemoGuide.html).
