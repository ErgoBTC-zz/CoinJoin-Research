The debug guide can be found in the [documentation](https://docs.wasabiwallet.io/building-wasabi/HowToDebug.html).
