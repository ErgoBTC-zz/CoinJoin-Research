The guide for the deterministic builds can be found in the [documentation](https://docs.wasabiwallet.io/using-wasabi/DeterministicBuild.html).
