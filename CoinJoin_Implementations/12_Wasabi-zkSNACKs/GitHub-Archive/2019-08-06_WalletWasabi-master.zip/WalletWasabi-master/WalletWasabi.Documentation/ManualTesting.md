The workflow for manual testing can be found in the [documentation](https://docs.wasabiwallet.io/building-wasabi/ManualTesting.html).
