A reference of common local ports can be found in the [documentation](https://docs.wasabiwallet.io/building-wasabi/Ports.html).
