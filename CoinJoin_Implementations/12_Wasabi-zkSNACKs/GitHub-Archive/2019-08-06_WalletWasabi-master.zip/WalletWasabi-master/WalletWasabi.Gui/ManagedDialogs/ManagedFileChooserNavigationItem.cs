﻿namespace WalletWasabi.Gui.ManagedDialogs
{
	public class ManagedFileChooserNavigationItem
	{
		public string DisplayName { get; set; }
		public string Path { get; set; }
	}
}
