using System;
using System.Collections.Generic;
using System.Text;

namespace WalletWasabi.Gui.Models
{
	public enum LockScreenType
	{
		SlideLock,
		PinLock,
	}
}
