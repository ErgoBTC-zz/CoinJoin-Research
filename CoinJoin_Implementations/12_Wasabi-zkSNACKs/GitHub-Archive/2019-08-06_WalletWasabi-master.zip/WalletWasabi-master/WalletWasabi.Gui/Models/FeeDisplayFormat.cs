using System;
using System.Collections.Generic;
using System.Text;

namespace WalletWasabi.Gui.Models
{
	public enum FeeDisplayFormat
	{
		USD,
		BTC,
		SatoshiPerByte,
		Percentage
	}
}
