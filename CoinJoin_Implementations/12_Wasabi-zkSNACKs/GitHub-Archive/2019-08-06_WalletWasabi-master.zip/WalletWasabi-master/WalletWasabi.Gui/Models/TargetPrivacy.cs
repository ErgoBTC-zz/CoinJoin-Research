using System;
using System.Collections.Generic;
using System.Text;

namespace WalletWasabi.Gui.Models
{
	public enum TargetPrivacy
	{
		None,
		Some,
		Fine,
		Strong
	}
}
