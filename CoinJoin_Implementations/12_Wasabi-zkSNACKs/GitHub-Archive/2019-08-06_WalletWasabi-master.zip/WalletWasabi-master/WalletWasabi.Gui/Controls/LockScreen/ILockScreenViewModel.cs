using System;

namespace WalletWasabi.Gui.Controls.LockScreen
{
	public interface ILockScreenViewModel : IDisposable
	{
	}
}
