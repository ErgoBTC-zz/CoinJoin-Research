using System;
using System.Collections.Generic;
using System.Text;

namespace WalletWasabi.Gui.Tabs.WalletManager
{
	public enum LoadWalletType
	{
		Desktop,
		Password,
		Hardware
	}
}
