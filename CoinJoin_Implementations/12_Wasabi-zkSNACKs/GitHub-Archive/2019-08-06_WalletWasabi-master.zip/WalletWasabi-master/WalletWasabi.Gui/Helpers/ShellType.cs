using System;
using System.Collections.Generic;
using System.Text;

namespace WalletWasabi.Gui.Helpers
{
	public enum ShellType
	{
		Generic,
		Windows,
		Unix
	}
}
