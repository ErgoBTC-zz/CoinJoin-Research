namespace WalletWasabi.Tests.NodeBuilding
{
	public enum CoreNodeState
	{
		Stopped,
		Starting,
		Running,
		Killed
	}
}
